/** Adapted from fonteditor-core 2.6.3, MIT, kekee000.
 * Urania: Promise factory, shared initialization, bounded inputs and vector disposal.
 */
const load = require('./woff2');
const maximum = 30 * 1024 * 1024;
let pending;
function copyVector(vector) {
    try {
        const size = vector.size();
        if (!size || size > maximum) throw new Error('Invalid or oversized WOFF2 font');
        const bytes = new Uint8Array(size);
        for (let i = 0; i < size; i++) bytes[i] = vector.get(i);
        return bytes;
    } finally { vector.delete(); }
}
function input(value) {
    const bytes = value instanceof Uint8Array ? value : new Uint8Array(value);
    if (!bytes.length || bytes.length > maximum) throw new Error('Font exceeds WOFF2 input budget');
    return bytes;
}
const codec = {
    woff2Module: null,
    isInited() { return !!this.woff2Module; },
    init(wasmUrl) {
        if (this.woff2Module) return Promise.resolve(this);
        if (!pending) {
            const config = {};
            if (typeof wasmUrl === 'string') config.locateFile = name => name.endsWith('.wasm') ? wasmUrl : name;
            else if (wasmUrl) config.wasmBinary = input(wasmUrl);
            pending = Promise.resolve().then(() => load(config)).then(module => {
                this.woff2Module = module;
                return this;
            }).catch(error => { pending = undefined; throw error; });
        }
        return pending;
    },
    encode(value) {
        if (!this.isInited()) throw new Error('WOFF2 codec is not initialized');
        const bytes = input(value);
        return copyVector(this.woff2Module.woff2Enc(bytes, bytes.byteLength));
    },
    decode(value) {
        if (!this.isInited()) throw new Error('WOFF2 codec is not initialized');
        const bytes = input(value);
        return copyVector(this.woff2Module.woff2Dec(bytes, bytes.byteLength));
    }
};
module.exports = codec;
