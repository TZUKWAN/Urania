// Adapted from fonteditor-core 04c47400895f11d857ca83f5725c0c3c0dd552a5,
// woff2src/woff2.cpp (MIT). Urania: bounded input/output and RAII encoder storage.
#include <cstdint>
#include <string>
#include <vector>
#include <woff2/decode.h>
#include <woff2/encode.h>
#include <emscripten/bind.h>

static constexpr size_t kFontLimit = 30 * 1024 * 1024;
std::vector<uint8_t> woff2_dec(std::string bytes, size_t size) {
    if (size != bytes.size() || size < 48 || size > kFontLimit) return {};
    const auto* input = reinterpret_cast<const uint8_t*>(bytes.data());
    const auto expected = woff2::ComputeWOFF2FinalSize(input, size);
    if (!expected || expected > kFontLimit) return {};
    std::string output(expected, 0);
    woff2::WOFF2StringOut writer(&output);
    writer.SetMaxSize(kFontLimit);
    if (!woff2::ConvertWOFF2ToTTF(input, size, &writer)) return {};
    return {output.begin(), output.begin() + writer.Size()};
}
std::vector<uint8_t> woff2_enc(std::string bytes, size_t size) {
    if (size != bytes.size() || size < 12 || size > kFontLimit) return {};
    const auto* input = reinterpret_cast<const uint8_t*>(bytes.data());
    size_t outputSize = woff2::MaxWOFF2CompressedSize(input, size);
    if (!outputSize || outputSize > kFontLimit) return {};
    std::vector<uint8_t> output(outputSize);
    if (!woff2::ConvertTTFToWOFF2(input, size, output.data(), &outputSize)) return {};
    output.resize(outputSize);
    return output;
}
EMSCRIPTEN_BINDINGS(woff2) {
    emscripten::register_vector<uint8_t>("vector<uint8_t>");
    emscripten::function("woff2Dec", &woff2_dec);
    emscripten::function("woff2Enc", &woff2_enc);
}
