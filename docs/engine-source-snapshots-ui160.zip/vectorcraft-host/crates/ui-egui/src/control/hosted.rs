//! Host operations execute inside the displayed App's control drain, without a JS read/write race.
use serde_json::{Value, json};
use std::sync::atomic::{AtomicU64, Ordering};

use super::{Outcome, err, ok};
use crate::VectorcraftApp;

static NEXT_CONTEXT_SEQUENCE: AtomicU64 = AtomicU64::new(1);

/// A single control-drain snapshot of native content, selection and page/tool
/// context. No synthetic common-object projection owns the native selection.
fn context_document(app: &mut VectorcraftApp, params: &Value) -> Result<Value, String> {
    let mut document = app.run("document.inspect", params.clone()).map_err(|error| error.to_string())?;
    let state = app.session.active().ok_or("no document open")?;
    let mut selection = serde_json::to_value(&state.selection).map_err(|error| error.to_string())?;
    let mut new_art: Vec<u64> = state.selection.new_art.iter().map(|id| id.0).collect();
    new_art.sort_unstable();
    if let Some(fields) = selection.as_object_mut() {
        fields.insert("new_art".into(), json!(new_art));
    }
    let page_index = app.view().map(|view| view.artboard);
    let page = page_index
        .and_then(|index| {
            document
                .get("artboards")
                .and_then(Value::as_array)
                .and_then(|boards| boards.get(index))
                .map(|artboard| json!({"kind": "artboard", "index": index, "artboard": artboard}))
        })
        .unwrap_or(Value::Null);
    let tool = json!({"tool": app.session.tool_id(), "options": app.session.tool_options()});
    // Objects are already fenced by base.selection. Keep the exact additional
    // selection state as a canonical string, without a lossy JS numeric pass.
    let mut detail = selection.clone();
    if let Some(fields) = detail.as_object_mut() {
        fields.remove("objects");
    }
    let stamp = serde_json::to_string(&json!({"selection": detail, "page": page_index, "tool": tool})).map_err(|error| error.to_string())?;
    let fields = document.as_object_mut().ok_or("native inspect did not return an object")?;
    let sequence = NEXT_CONTEXT_SEQUENCE
        .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |value| value.checked_add(1))
        .map_err(|_| "native context sequence exhausted")?;
    fields.insert("engine".into(), json!("vectorcraft"));
    fields.insert("contextProtocol".into(), json!(2));
    fields.insert("contextSequence".into(), json!(sequence));
    fields.insert("nativeSelection".into(), json!({"kind": "vectorcraft", "data": selection}));
    fields.insert("selectionStamp".into(), json!(stamp));
    fields.insert("toolContext".into(), tool);
    fields.insert("page".into(), page);
    fields.insert("coordinateSpace".into(), json!("document"));
    Ok(document)
}

pub(super) fn context(app: &mut VectorcraftApp, params: &Value) -> Outcome {
    match context_document(app, params) {
        Ok(value) => ok(value),
        Err(error) => err(error),
    }
}

/// Validate transient embedding options before changing any UI state. Neither
/// the native document nor the person's standalone preferences is changed.
pub(super) fn configure(app: &mut VectorcraftApp, ctx: &egui::Context, p: &Value) -> Outcome {
    let Some(embedded) = p.get("embedded").and_then(Value::as_bool) else {
        return err("host.configure requires embedded: boolean");
    };
    let brightness = match p.get("brightness") {
        None | Some(Value::Null) => None,
        Some(Value::String(value)) => match crate::theme::Brightness::parse(value) {
            Some(value) => Some(value),
            None => return err("unknown host brightness"),
        },
        _ => return err("host brightness must be a string"),
    };
    let file_routing = match p.get("fileRouting") {
        None => app.host_files.enabled && embedded,
        Some(Value::Bool(value)) => *value && embedded,
        _ => return err("host fileRouting must be a boolean"),
    };
    if !file_routing && app.host_files.pending.is_some() {
        return err("Finish the pending hosted file action before disabling routing");
    }
    let ai_canvas = match p.get("aiCanvas") {
        None => app.host_ai_canvas && embedded,
        Some(Value::Bool(value)) => *value && embedded,
        _ => return err("host aiCanvas must be a boolean"),
    };
    if ai_canvas && !app.host_ai_canvas && app.session.active().is_some() {
        if let Err(error) = app.run("tool.select", json!({"tool":"selection"})) { return err(error); }
    }
    app.hosted = embedded;
    app.host_ai_canvas = ai_canvas;
    app.host_files.enabled = file_routing;
    app.host_brightness = if embedded { brightness } else { None };
    app.styled = false;
    app.canvas.key = None;
    if let Some(value) = app.host_brightness {
        crate::theme::apply_with(ctx, value, crate::theme::Accent::Green, crate::theme::Scheme::Modern);
    } else {
        crate::theme::apply(ctx, app.ui.brightness);
    }
    ctx.request_repaint();
    ok(json!({"embedded": app.hosted, "aiCanvas":app.host_ai_canvas, "brightness": app.host_brightness.map(|value| value.id())}))
}

pub(super) fn create(app: &mut VectorcraftApp, p: &Value) -> Outcome {
    if app.session.active().is_some() || app.host_files.pending.is_some() {
        return err("host.create requires an empty surface");
    }
    if let Err(error) = crate::menus::check_params(&app.session, "file.new", p) {
        return err(error);
    }
    let routed = app.host_files.enabled;
    app.host_files.enabled = false;
    let result = app.run("file.new", p.clone());
    app.host_files.enabled = routed;
    match result {
        Ok(value) => ok(json!({"value": value, "document": app.run("document.inspect", json!({})).ok()})),
        Err(error) => err(error),
    }
}

pub(super) fn execute(app: &mut VectorcraftApp, p: &Value) -> Outcome {
    let before = match context_document(app, &json!({"depth": 2, "childLimit": 50})) {
        Ok(state) => state,
        Err(error) => return err(error),
    };
    let Some(base) = p.get("base").filter(|v| v.is_object()) else {
        return err("host.execute requires base {uid, revision, selection}");
    };
    if base.get("uid").and_then(Value::as_u64).is_none()
        || base.get("revision").and_then(Value::as_u64).is_none()
        || base.get("selection").and_then(Value::as_array).is_none()
    {
        return err("invalid host.execute base identity");
    }
    for key in ["uid", "revision", "selection"] {
        if before.get(key) != base.get(key) {
            return err(format!("host conflict: {key} changed; read the current design before editing"));
        }
    }
    if p.get("contextProtocol").and_then(Value::as_u64) == Some(2) {
        if base.get("engine").and_then(Value::as_str) != Some("vectorcraft") {
            return err("host conflict: native engine changed");
        }
        if base.get("selectionStamp").and_then(Value::as_str).is_none() || base.get("selectionStamp") != before.get("selectionStamp") {
            return err("host conflict: native selection/page/tool context changed; read the current design");
        }
    }
    let Some(command) = p.get("command").and_then(Value::as_str) else {
        return err("missing host.execute command");
    };
    let params = p.get("params").filter(|v| !v.is_null()).cloned().unwrap_or(json!({}));
    if let Err(error) = crate::menus::check_params(&app.session, command, &params) {
        return err(error);
    }
    let value = match app.run(command, params) {
        Ok(value) => value,
        Err(error) => return err(error),
    };
    // Some UI commands close/switch documents; report that explicitly rather than inventing state.
    let document = if p.get("contextProtocol").and_then(Value::as_u64) == Some(2) {
        context_document(app, &json!({"depth": 2, "childLimit": 50})).ok()
    } else {
        app.run("document.inspect", json!({})).ok()
    };
    ok(json!({"value": value, "document": document}))
}

pub(super) fn snapshot(app: &mut VectorcraftApp, p: &Value) -> Outcome {
    let state = if p.get("contextProtocol").and_then(Value::as_u64) == Some(2) {
        context_document(app, &json!({"depth": 2, "childLimit": 50}))
    } else {
        app.run("document.inspect", json!({})).map_err(|error| error.to_string())
    };
    let document = match state {
        Ok(state) => state,
        Err(error) => return err(error),
    };
    let format = p.get("format").and_then(Value::as_str).unwrap_or("vectorcraft");
    if !matches!(format, "vectorcraft" | "svg" | "png" | "pdf") {
        return err("host.snapshot supports vectorcraft, svg, png and pdf");
    }
    match app.run("document.serialize", json!({"format": format})) {
        Ok(encoded) => ok(json!({"document": document, "encoded": encoded, "format": format})),
        Err(error) => err(error),
    }
}

/// The authoritative native bytes and one derivative are read in the same
/// control drain. Separate browser export/save requests can straddle an edit.
pub(super) fn bundle(app: &mut VectorcraftApp, p: &Value) -> Outcome {
    let format = p.get("format").and_then(Value::as_str).unwrap_or("svg");
    if !matches!(format, "svg" | "png") {
        return err("host.bundle supports svg and png derivatives");
    }
    let document = match context_document(app, &json!({"depth": 2, "childLimit": 50})) {
        Ok(document) => document,
        Err(error) => return err(error),
    };
    let Some(base) = p.get("base").filter(|base| base.is_object()) else {
        return err("host.bundle requires the current complete native base");
    };
    for key in ["uid", "revision", "selection", "engine", "selectionStamp"] {
        if base.get(key).is_none() || base.get(key) != document.get(key) {
            return err(format!("host conflict: {key} changed before material snapshot"));
        }
    }
    let source = match app.run("document.serialize", json!({"format": "vectorcraft"})) {
        Ok(source) => source,
        Err(error) => return err(error),
    };
    let derivative = match app.run("document.serialize", json!({"format": format})) {
        Ok(derivative) => derivative,
        Err(error) => return err(error),
    };
    let unchanged = app.session.active().is_some_and(|state| {
        document.get("uid").and_then(Value::as_u64) == Some(state.uid) && document.get("revision").and_then(Value::as_u64) == Some(state.revision)
    });
    if !unchanged {
        return err("native content changed during material snapshot; no pair was published");
    }
    ok(json!({"document": document, "source": source, "derivative": derivative, "format": format}))
}

/// A durable host checkpoint only clears the matching revision's dirty indicator.
/// A newer manual edit must stay dirty even if an older save acknowledgement arrives.
pub(super) fn saved(app: &mut VectorcraftApp, p: &Value) -> Outcome {
    let Some(checkpoint) = p.get("checkpoint").and_then(Value::as_str) else {
        return err("missing durable checkpoint identity");
    };
    if checkpoint.len() != 64 || !checkpoint.bytes().all(|b| b.is_ascii_hexdigit()) {
        return err("invalid durable checkpoint identity");
    }
    let Some(state) = app.session.active_mut() else {
        return err("no document open");
    };
    if p.get("uid").and_then(Value::as_u64) != Some(state.uid) || p.get("revision").and_then(Value::as_u64) != Some(state.revision) {
        return ok(json!({"acknowledged": false, "newerEdits": true}));
    }
    state.mark_saved();
    app.status(if app.hosted { tl!("Saved").to_string() } else { "Design workspace checkpoint saved".to_string() });
    ok(json!({"acknowledged": true, "checkpoint": checkpoint}))
}
