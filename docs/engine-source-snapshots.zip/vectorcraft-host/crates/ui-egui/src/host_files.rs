//! Hosted file commands are intents until the owning workspace confirms real I/O.
use serde_json::{Value, json};

use crate::VectorcraftApp;

#[derive(Default)]
pub(crate) struct HostFiles {
    pub enabled: bool,
    pub pending: Option<Value>,
    next_id: u32,
}

pub(crate) fn intercept(app: &mut VectorcraftApp, command: &str, params: &Value) -> Option<Result<Value, String>> {
    if !app.hosted || !app.host_files.enabled {
        return None;
    }
    let action = match command {
        "file.new" => "new",
        "file.open" => "open",
        "file.save" => "save",
        "file.saveAs" => "save_as",
        "file.saveCopy" => "save_copy",
        "file.close" | "file.closeAll" | "app.quit" => "close",
        "file.revert" => "revert",
        "app.home" => "works",
        id if id.starts_with("file.openRecent") => "works",
        // The workspace owns the new document and its original template bytes.
        "file.newFromTemplate" => {
            if !params.is_null() && !params.as_object().is_some_and(|object| object.is_empty()) {
                return Some(Err("Select a template in the workspace; direct paths and file data are not accepted here".into()));
            }
            "open"
        }
        _ => return None,
    };
    if app.host_files.pending.is_some() {
        return Some(Err("A workspace file action is already pending; finish or cancel it first".into()));
    }
    if params.to_string().len() > 32 * 1024 {
        return Some(Err("Hosted file parameters exceed the budget".into()));
    }
    let Some(id) = app.host_files.next_id.checked_add(1) else {
        return Some(Err("Hosted file request limit reached; save and reopen the workspace".into()));
    };
    app.host_files.next_id = id;
    app.host_files.pending = Some(json!({
        "id": id, "action": action, "command": command, "params": params,
        "uid": app.session.active().map(|document| document.uid),
        "revision": app.session.active().map(|document| document.revision),
    }));
    app.status("Waiting for the design workspace file action");
    Some(Ok(json!({"queued": true, "hostFileRequest": id})))
}

pub(crate) fn finish(app: &mut VectorcraftApp, params: &Value) -> Result<Value, String> {
    let pending = app.host_files.pending.as_ref().ok_or("No hosted file action is pending")?;
    if params.get("id") != pending.get("id") || params.get("ok").and_then(Value::as_bool).is_none() {
        return Err("Stale or invalid hosted file receipt".into());
    }
    let ok = params.get("ok").and_then(Value::as_bool) == Some(true);
    let cancelled = params.get("cancelled").and_then(Value::as_bool) == Some(true);
    app.host_files.pending = None;
    if !ok && !cancelled {
        app.status(
            params
                .get("error")
                .and_then(Value::as_str)
                .unwrap_or("The workspace did not complete the file action")
                .chars()
                .take(512)
                .collect::<String>(),
        );
    } else if cancelled {
        app.status("");
    }
    Ok(json!({"acknowledged": true}))
}
