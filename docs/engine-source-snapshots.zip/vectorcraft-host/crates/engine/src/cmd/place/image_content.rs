//! Embedded raster content replacement, without replacing a scene node.
use std::{collections::BTreeSet, io::Cursor};

use serde_json::{Value, json};
use vectorcraft_doc::NodeKind;
use vectorcraft_geom::Affine;

use crate::cmd::{bad, checked_ids_param, fileio, links, str_param};
use crate::{EngineError, Result, Session};

const COMMAND: &str = "image.replaceContent";
const MAX_BYTES: usize = 4 * 1024 * 1024;

pub(super) fn replace(s: &mut Session, p: &Value) -> Result<Value> {
    let data = str_param(p, "dataBase64").ok_or_else(|| bad(COMMAND, "give PNG dataBase64"))?;
    if p.get("path").is_some() || data.len() > 6 * 1024 * 1024 {
        return Err(bad(COMMAND, "use embedded PNG bytes within 4 MiB; paths are not followed"));
    }
    let input = p
        .get("ids")
        .and_then(Value::as_array)
        .filter(|a| !a.is_empty() && a.len() <= 100)
        .ok_or_else(|| bad(COMMAND, "give 1..100 explicit image ids"))?;
    let ids = checked_ids_param(s, p, "ids", COMMAND)?;
    let material = crate::cmd::host_material::request(p, COMMAND)?;
    if ids.iter().copied().collect::<BTreeSet<_>>().len() != input.len() {
        return Err(bad(COMMAND, "image ids must be unique"));
    }
    {
        let st = s.doc()?;
        if st.global_edit.is_some() || st.doc.mask_edit.is_some() || st.interaction.is_some() || st.undo_group.is_some() {
            return Err(bad(COMMAND, "finish Global Edit, mask editing and pending interactions first"));
        }
        let editable = st.doc.editable();
        for id in &ids {
            let node = st.doc.node(*id).ok_or(EngineError::NoNode(*id))?;
            if let Some(material) = &material {
                crate::cmd::host_material::check(node, material, COMMAND)?;
            }
            let NodeKind::Image(image) = &node.kind else { return Err(bad(COMMAND, "every target must be an embedded image")) };
            if !editable(*id) || image.link.is_some() || image.width == 0 || image.height == 0 {
                return Err(bad(COMMAND, "target or ancestor is locked/hidden, linked, or has an invalid pixel frame"));
            }
        }
    }
    let bytes = vectorcraft_format::base64_decode(data).ok_or_else(|| bad(COMMAND, "bad base64"))?;
    if bytes.is_empty() || bytes.len() > MAX_BYTES || !bytes.starts_with(b"\x89PNG\r\n\x1a\n") {
        return Err(bad(COMMAND, "give actual PNG bytes within 4 MiB"));
    }
    // Admission precedes the native decoder, including a PNG with EXIF orientation.
    let (width, height) = image::ImageReader::new(Cursor::new(&bytes))
        .with_guessed_format()
        .map_err(|e| bad(COMMAND, e.to_string()))?
        .into_dimensions()
        .map_err(|e| bad(COMMAND, e.to_string()))?;
    if width == 0 || height == 0 || width > 16384 || height > 16384 || u64::from(width) * u64::from(height) > 24_000_000 {
        return Err(bad(COMMAND, "PNG dimensions exceed the 24 MP budget"));
    }
    let incoming = fileio::raster_image(&bytes)?;
    let blob = links::readable_and_kept(incoming.blob, true, false)?;
    let (key, width, height) = (incoming.key, incoming.width, incoming.height);
    s.edit("Replace Image Contents", |document, _| {
        document.images.insert(key.clone(), blob);
        for id in &ids {
            let node = document.node_mut(*id).ok_or(EngineError::NoNode(*id))?;
            let NodeKind::Image(image) = &mut node.kind else { return Err(bad(COMMAND, "target ceased to be an image")) };
            // Pixel coordinates change; the four document-space corners stay put.
            image.xf *= Affine::scale_non_uniform(f64::from(image.width) / f64::from(width), f64::from(image.height) / f64::from(height));
            image.key.clone_from(&key);
            image.width = width;
            image.height = height;
            if let Some(material) = &material {
                crate::cmd::host_material::apply(node, material, true, COMMAND)?;
            }
        }
        Ok(())
    })?;
    Ok(json!({"ids": ids.iter().map(|id| id.0).collect::<Vec<_>>(), "pixelWidth": width, "pixelHeight": height}))
}

#[cfg(test)]
mod tests;
