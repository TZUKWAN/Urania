use std::io::Cursor;

use serde_json::{Value, json};
use vectorcraft_color::BlendMode;
use vectorcraft_doc::{NodeId, NodeKind};
use vectorcraft_geom::{Affine, Point};

use crate::Session;

fn png(width: u32, height: u32, color: [u8; 4]) -> Vec<u8> {
    let mut bytes = Vec::new();
    image::RgbaImage::from_pixel(width, height, image::Rgba(color)).write_to(&mut Cursor::new(&mut bytes), image::ImageFormat::Png).unwrap();
    bytes
}
fn placed(session: &mut Session, bytes: &[u8], x: f64) -> NodeId {
    let result = session
        .execute("file.place", &json!({"name":"fixture.png","dataBase64":vectorcraft_format::base64_encode(bytes),"link":false,"rect":[x,40,80,40]}))
        .unwrap();
    NodeId(result["ids"][0].as_u64().unwrap())
}
fn fixture() -> (Session, NodeId, NodeId, NodeId) {
    let mut s = Session::new();
    s.execute("file.new", &json!({"width":500,"height":400})).unwrap();
    let bytes = png(20, 10, [70, 110, 210, 255]);
    let first = placed(&mut s, &bytes, 20.0);
    let other = placed(&mut s, &bytes, 260.0);
    let mask = s.execute("shape.rectangle", &json!({"x":20,"y":40,"width":70,"height":32})).unwrap()["id"].as_u64().unwrap();
    s.execute("object.group", &json!({"ids":[first.0,mask]})).unwrap();
    let parent = s.doc().unwrap().doc.position(first).unwrap().0.unwrap();
    s.edit("original fixture clipping and appearance", |doc, _| {
        let node = doc.node_mut(first).unwrap();
        node.opacity = 0.37;
        node.blend = BlendMode::Multiply;
        node.bbox_angle = 21.0;
        let NodeKind::Image(image) = &mut node.kind else { panic!() };
        image.xf = Affine::translate((110.0, 80.0)) * Affine::rotate(0.37) * Affine::scale_non_uniform(-3.0, 2.0);
        let group = doc.node_mut(parent).unwrap();
        group.opacity = 0.81;
        let NodeKind::Group { children, clip } = &mut group.kind else { panic!() };
        let index = children.iter().position(|n| n.id == NodeId(mask)).unwrap();
        children.swap(0, index);
        *clip = true;
        Ok(())
    })
    .unwrap();
    (s, first, other, parent)
}
#[test]
fn changed_pixel_ratio_keeps_entire_native_scene_except_contents_and_one_undo_restores_it() {
    let (mut s, id, other, _) = fixture();
    let before = s.doc().unwrap().doc.clone();
    let undo = s.doc().unwrap().history.undo.len();
    let NodeKind::Image(original) = &before.node(id).unwrap().kind else { panic!() };
    let incoming = png(9, 31, [210, 80, 50, 255]);
    let result = s.execute("image.replaceContent", &json!({"ids":[id.0],"dataBase64":vectorcraft_format::base64_encode(&incoming)})).unwrap();
    assert_eq!(result["ids"], json!([id.0]));
    let after = s.doc().unwrap().doc.clone();
    let NodeKind::Image(next) = &after.node(id).unwrap().kind else { panic!() };
    assert_ne!(next.key, original.key);
    assert_eq!((next.width, next.height), (9, 31));
    assert_eq!(after.images[&next.key].bytes.as_slice(), incoming);
    assert_eq!(after.node(other), before.node(other));
    assert!(after.images.contains_key(&original.key));
    for (x, y) in [(0.0, 0.0), (1.0, 0.0), (0.0, 1.0), (1.0, 1.0)] {
        let old = original.xf * Point::new(x * f64::from(original.width), y * f64::from(original.height));
        let new = next.xf * Point::new(x * f64::from(next.width), y * f64::from(next.height));
        assert!((old - new).hypot() < 1e-9);
    }
    let mut normalized = (*after).clone();
    normalized.images = before.images.clone();
    let NodeKind::Image(image) = &mut normalized.node_mut(id).unwrap().kind else { panic!() };
    image.key = original.key.clone();
    image.width = original.width;
    image.height = original.height;
    image.xf = original.xf;
    assert_eq!(normalized, *before, "group clip, stacking, node id/name, opacity, blend, appearance, frame and all other content stay exact");
    let bytes = vectorcraft_format::save(&after, false);
    assert_eq!(vectorcraft_format::load(&bytes).unwrap(), *after, "actual v4 native source reopens with exact pixels and scene");
    assert_eq!(s.doc().unwrap().history.undo.len(), undo + 1);
    s.execute("edit.undo", &json!({})).unwrap();
    assert_eq!(*s.doc().unwrap().doc, *before);
}
#[test]
fn invalid_input_wrong_identity_locked_ancestor_and_partially_locked_targets_are_atomic_refusals() {
    let (mut s, id, other, parent) = fixture();
    let valid = vectorcraft_format::base64_encode(&png(12, 8, [1, 2, 3, 255]));
    let mut cases: Vec<Value> = vec![
        json!({"ids":[id.0],"dataBase64":"bad"}),
        json!({"ids":[999999],"dataBase64":valid}),
        json!({"ids":[id.0,id.0],"dataBase64":valid}),
        json!({"ids":[parent.0],"dataBase64":valid}),
        json!({"ids":[],"dataBase64":valid}),
        json!({"ids":[id.0],"path":"must-not-read.png","dataBase64":valid}),
    ];
    cases.push(json!({"ids":[id.0],"dataBase64":"A".repeat(6*1024*1024+1)}));
    for params in cases {
        let before = s.doc().unwrap().doc.clone();
        let undo = s.doc().unwrap().history.undo.len();
        let journal = s.journal.len();
        assert!(s.execute("image.replaceContent", &params).is_err());
        assert_eq!(*s.doc().unwrap().doc, *before);
        assert_eq!((s.doc().unwrap().history.undo.len(), s.journal.len()), (undo, journal));
    }
    for locked in [parent, other] {
        s.edit("fixture lock", |doc, _| {
            doc.node_mut(locked).unwrap().locked = true;
            Ok(())
        })
        .unwrap();
        let before = s.doc().unwrap().doc.clone();
        let undo = s.doc().unwrap().history.undo.len();
        assert!(s.execute("image.replaceContent", &json!({"ids":[id.0,other.0],"dataBase64":valid})).is_err());
        assert_eq!(*s.doc().unwrap().doc, *before);
        assert_eq!(s.doc().unwrap().history.undo.len(), undo);
        s.execute("edit.undo", &json!({})).unwrap();
    }
}
