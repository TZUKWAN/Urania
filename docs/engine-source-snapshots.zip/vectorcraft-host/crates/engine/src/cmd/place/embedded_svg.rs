//! A self-contained native Vector source as one source-editable vector use.
use crate::cmd::{bad, checked_ids_param, host_material, str_param};
use crate::{EngineError, Result, Session};
use serde_json::{Value, json};
use std::collections::BTreeSet;
use vectorcraft_doc::{LinkInfo, NodeKind};
use vectorcraft_geom::{Affine, Point};

fn source(p: &Value, command: &str) -> Result<super::document::Source> {
    let encoded = str_param(p, "sourceBase64").ok_or_else(|| bad(command, "give embedded native sourceBase64"))?;
    if p.get("path").is_some() || encoded.len() > (4usize * 1024 * 1024).div_ceil(3) * 4 {
        return Err(bad(command, "only embedded source bytes up to 4 MiB are admitted"));
    }
    let bytes = vectorcraft_format::base64_decode(encoded).ok_or_else(|| bad(command, "invalid source base64"))?;
    super::document::embedded_source(&bytes, command)
}
fn no_collision(doc: &vectorcraft_doc::Document, source: &super::document::Source, command: &str) -> Result<()> {
    if doc.images.get(&source.key).is_some_and(|old| old.bytes != source.blob.bytes || old.mime != source.blob.mime || old.is_proxy()) {
        return Err(bad(command, "embedded source key conflicts with existing media"));
    }
    Ok(())
}
pub(super) fn place(s: &mut Session, p: &Value) -> Result<Value> {
    const CMD: &str = "svg.placeSource";
    let at = super::at_param(p)?;
    let rect = super::rect_param(p)?;
    let corners = [at, rect.map(|r| r.origin()), rect.map(|r| Point::new(r.x1, r.y1))];
    if corners.iter().flatten().any(|c| !(c.x.abs() <= super::MAX_COORD && c.y.abs() <= super::MAX_COORD)) {
        return Err(bad(CMD, "placement is outside the canvas"));
    }
    let material = host_material::request(p, CMD)?;
    let source = source(p, CMD)?;
    let state = s.doc()?;
    if state.global_edit.is_some() || state.doc.mask_edit.is_some() || state.interaction.is_some() || state.undo_group.is_some() {
        return Err(bad(CMD, "finish the native interaction first"));
    }
    no_collision(&state.doc, &source, CMD)?;
    let transform = if let Some(rect) = rect {
        super::fit(source.frame, rect)
    } else {
        let center = at.or_else(|| state.doc.artboards.first().map(|a| a.rect.center())).unwrap_or_default();
        Affine::translate(center - source.frame.center())
    };
    let parent = state.insertion_parent();
    let id = s.edit("Place Embedded Vector Source", |doc, selection| {
        let mut node = super::transformed(super::document::node(doc, &source, LinkInfo::default(), false), transform);
        if let Some(material) = &material {
            host_material::apply(&mut node, material, false, CMD)?;
        }
        let id = doc.insert(parent, usize::MAX, node)?;
        selection.set([id]);
        Ok(id)
    })?;
    Ok(json!({"ids":[id.0], "sourceKey":source.key}))
}
pub(super) fn replace(s: &mut Session, p: &Value) -> Result<Value> {
    const CMD: &str = "svg.replaceSource";
    let input = p
        .get("ids")
        .and_then(Value::as_array)
        .filter(|a| !a.is_empty() && a.len() <= 100)
        .ok_or_else(|| bad(CMD, "give 1..100 explicit vector ids"))?;
    let ids = checked_ids_param(s, p, "ids", CMD)?;
    if ids.iter().copied().collect::<BTreeSet<_>>().len() != input.len() {
        return Err(bad(CMD, "vector ids must be unique"));
    }
    let material = host_material::request(p, CMD)?;
    let source = source(p, CMD)?;
    {
        let state = s.doc()?;
        if state.global_edit.is_some() || state.doc.mask_edit.is_some() || state.interaction.is_some() || state.undo_group.is_some() {
            return Err(bad(CMD, "finish the native interaction first"));
        }
        no_collision(&state.doc, &source, CMD)?;
        let editable = state.doc.editable();
        for id in &ids {
            let node = state.doc.node(*id).ok_or(EngineError::NoNode(*id))?;
            let NodeKind::PlacedDocument(placed) = &node.kind else { return Err(bad(CMD, "target is not an embedded vector source")) };
            let valid_frame = placed.width.is_finite()
                && placed.height.is_finite()
                && placed.width > 0.0
                && placed.height > 0.0
                && placed.xf.as_coeffs().iter().all(|v| v.is_finite())
                && placed.xf.determinant().abs() > 1e-12;
            let valid_blob = state.doc.images.get(&placed.key).is_some_and(|b| !b.is_proxy() && b.mime == "application/json");
            if !editable(*id) || !placed.is_embedded() || !placed.link.path.is_empty() || !valid_frame || !valid_blob {
                return Err(bad(CMD, "target or ancestor is locked/hidden, linked, or lacks a valid embedded source/frame"));
            }
            if let Some(material) = &material {
                host_material::check(node, material, CMD)?;
            }
        }
    }
    s.edit("Replace Embedded Vector Source", |doc, _| {
        super::document::store(doc, &source);
        for id in &ids {
            let node = doc.node_mut(*id).ok_or(EngineError::NoNode(*id))?;
            let NodeKind::PlacedDocument(placed) = &mut node.kind else { return Err(bad(CMD, "target changed kind")) };
            placed.key.clone_from(&source.key);
            if let Some(material) = &material {
                host_material::apply(node, material, true, CMD)?;
            }
        }
        Ok(())
    })?;
    Ok(json!({"ids":ids.iter().map(|id|id.0).collect::<Vec<_>>(), "sourceKey":source.key}))
}
