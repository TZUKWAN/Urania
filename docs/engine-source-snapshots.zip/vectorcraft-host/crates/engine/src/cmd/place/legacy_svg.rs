//! Fail-closed conversion of a narrowly supported unchanged SVG group.
//! The host must separately authenticate the original placement receipt and
//! immutable source. A visual check alone never establishes that relationship.
use crate::cmd::{bad, checked_id, host_material, str_param};
use crate::{EngineError, Result, Session};
use serde_json::{Value, json};
use std::sync::Arc;
use vectorcraft_color::BlendMode;
use vectorcraft_doc::{Document, LayerColor, LinkInfo, Node, NodeId, NodeKind};
use vectorcraft_geom::{Affine, Rect};

const CMD: &str = "svg.replaceLegacyGroup";
const MAX_BYTES: usize = 4 * 1024 * 1024;

fn bytes(p: &Value, field: &str) -> Result<Vec<u8>> {
    let encoded = str_param(p, field).ok_or_else(|| bad(CMD, format!("missing {field}")))?;
    if encoded.len() > MAX_BYTES.div_ceil(3) * 4 {
        return Err(bad(CMD, "source exceeds 4 MiB"));
    }
    let value = vectorcraft_format::base64_decode(encoded).ok_or_else(|| bad(CMD, "invalid source base64"))?;
    if value.is_empty() || value.len() > MAX_BYTES {
        return Err(bad(CMD, "source is empty or exceeds 4 MiB"));
    }
    Ok(value)
}

/// Only a self-contained basic SVG subset may reach the ordinary importer.
/// In particular no href, CSS, external resources, entities, filters or images.
fn simple_svg(bytes: &[u8]) -> Result<()> {
    let text = std::str::from_utf8(bytes).map_err(|_| bad(CMD, "SVG is not UTF-8"))?;
    if text.to_ascii_uppercase().contains("<!DOCTYPE") || text.to_ascii_uppercase().contains("<!ENTITY") {
        return Err(bad(CMD, "SVG document types and entities are unsupported"));
    }
    let xml = roxmltree::Document::parse(text).map_err(|_| bad(CMD, "invalid SVG"))?;
    if xml.root_element().tag_name().name() != "svg" {
        return Err(bad(CMD, "not SVG"));
    }
    for (index, node) in xml.descendants().enumerate() {
        if index >= 100_000 {
            return Err(bad(CMD, "SVG tree exceeds budget"));
        }
        if !node.is_element() {
            continue;
        }
        if !matches!(
            node.tag_name().name(),
            "svg" | "g" | "path" | "rect" | "circle" | "ellipse" | "line" | "polyline" | "polygon" | "text" | "tspan" | "title" | "desc"
        ) {
            return Err(bad(CMD, "SVG contains an unsupported element"));
        }
        for attr in node.attributes() {
            let name = attr.name().to_ascii_lowercase();
            let value = attr.value().to_ascii_lowercase();
            if matches!(name.as_str(), "href" | "src" | "style" | "filter" | "mask" | "clip-path")
                || name.starts_with("on")
                || value.contains("url")
                || value.contains('\\')
            {
                return Err(bad(CMD, "SVG contains an unsupported reference or style"));
            }
        }
    }
    Ok(())
}

fn simple_group(node: &Node, depth: usize, count: &mut usize) -> bool {
    *count += 1;
    if *count > 100_000 || depth > 64 || !node.visible || node.locked || node.blend != BlendMode::Normal || node.opacity != 1.0 || node.isolate {
        return false;
    }
    if node.extras().attrs.as_ref().is_some_and(|a| a.data.iter().any(|(key, _)| key == "dsh-material-v1")) {
        return false;
    }
    match &node.kind {
        NodeKind::Group { children, clip: false } => children.iter().all(|child| simple_group(child, depth + 1, count)),
        NodeKind::Path { guide: false, clipping: false, .. } | NodeKind::Text(_) => true,
        _ => false,
    }
}

fn normalize_ids(node: &mut Node) {
    node.id = NodeId(0);
    if let Some(children) = node.children_mut() {
        for child in children {
            normalize_ids(Arc::make_mut(child));
        }
    }
}

fn isolated(doc: &Document, node: Node) -> Document {
    let mut out = doc.clone();
    let mut layer = Node::layer(NodeId(0), "legacy verification", LayerColor::Preset(0));
    if let NodeKind::Layer { children, .. } = &mut layer.kind {
        children.push(Arc::new(node));
    }
    out.layers = vec![Arc::new(layer)];
    out
}

fn same_render(before: &Document, after: &Document, region: Rect) -> Result<()> {
    let side = region.width().max(region.height());
    if !side.is_finite() || side <= 0.0 || side > 4096.0 {
        return Err(bad(CMD, "legacy visual bounds exceed verification budget"));
    }
    for scale in [512.0 / side, 1024.0 / side] {
        for white in [false, true] {
            let a = vectorcraft_render::Renderer::new().render_region(before, region, scale, white);
            let b = vectorcraft_render::Renderer::new().render_region(after, region, scale, white);
            // Transparent premultiplied pixels must be exact. Compositing the
            // same edges against white can round a channel by one 8-bit unit.
            let differs = a.width != b.width
                || a.height != b.height
                || a.pixels.len() != b.pixels.len()
                || a.pixels.iter().zip(&b.pixels).any(|(x, y)| x.abs_diff(*y) > u8::from(white));
            if differs {
                return Err(bad(CMD, "legacy source renders differently; original group was kept"));
            }
            if !white && !a.pixels.chunks_exact(4).any(|pixel| pixel[3] != 0) {
                return Err(bad(CMD, "legacy group rendered no visible pixels"));
            }
        }
    }
    Ok(())
}

pub(super) fn replace(s: &mut Session, p: &Value) -> Result<Value> {
    let id = checked_id(s, p.get("id").ok_or_else(|| bad(CMD, "missing id"))?, CMD)?;
    let material = host_material::request(p, CMD)?.ok_or_else(|| bad(CMD, "hostMaterial is required"))?;
    let svg = bytes(p, "originalSvgBase64")?;
    simple_svg(&svg)?;
    let original_bytes = bytes(p, "originalSourceBase64")?;
    let replacement_bytes = bytes(p, "sourceBase64")?;
    let original = super::document::embedded_source(&original_bytes, CMD)?;
    let replacement = super::document::embedded_source(&replacement_bytes, CMD)?;
    let art = super::document::embedded_art(&original_bytes, CMD)?;
    let source_bounds =
        super::shown_bounds(&art.doc.symbol_boxes(), &art.nodes).ok_or_else(|| bad(CMD, "original vector source has no visible art"))?;
    let state = s.doc()?;
    if state.global_edit.is_some() || state.doc.mask_edit.is_some() || state.interaction.is_some() || state.undo_group.is_some() {
        return Err(bad(CMD, "finish the native interaction first"));
    }
    let old = state.doc.node(id).cloned().ok_or(EngineError::NoNode(id))?;
    if !matches!(old.kind, NodeKind::Group { .. }) || !state.doc.editable()(id) || !simple_group(&old, 0, &mut 0) {
        return Err(bad(CMD, "legacy group has unsupported or hidden content"));
    }
    host_material::check(&old, &material, CMD)?;
    for item in [&original, &replacement] {
        if state.doc.images.get(&item.key).is_some_and(|old| old.bytes != item.blob.bytes || old.mime != item.blob.mime || old.is_proxy()) {
            return Err(bad(CMD, "source key conflicts with existing media"));
        }
    }
    // Re-import original SVG into a clone; only freshly allocated node IDs are
    // normalized. A changed path, text, attributes, layout or appearance fails.
    let params = json!({"name":"legacy.svg","dataBase64":vectorcraft_format::base64_encode(&svg),"link":false});
    let loaded = super::load(&params, CMD, None, false)?;
    if loaded.format.id != "svg" || !loaded.warnings.is_empty() {
        return Err(bad(CMD, "SVG could not be imported without warnings"));
    }
    let mut scratch = (*state.doc).clone();
    let mut imported = super::build(&mut scratch, loaded, None);
    imported.name.clone_from(&old.name);
    let symbols = state.doc.symbol_boxes();
    let old_bounds = vectorcraft_render::encode::drawn_bounds(&symbols, &old).ok_or_else(|| bad(CMD, "legacy group has no visible bounds"))?;
    let fresh_bounds =
        vectorcraft_render::encode::drawn_bounds(&scratch.symbol_boxes(), &imported).ok_or_else(|| bad(CMD, "original SVG has no visible bounds"))?;
    imported = super::transformed(imported, Affine::translate(old_bounds.origin() - fresh_bounds.origin()));
    let mut left = old.clone();
    let mut right = imported;
    normalize_ids(&mut left);
    normalize_ids(&mut right);
    // Compare the actual persisted model. Text and other nodes also contain
    // transient caches that are intentionally not part of a saved document.
    let left = serde_json::to_value(&left).map_err(|_| bad(CMD, "cannot compare legacy group"))?;
    let right = serde_json::to_value(&right).map_err(|_| bad(CMD, "cannot compare original SVG"))?;
    if left != right {
        return Err(bad(CMD, "legacy group differs from original SVG; original group was kept"));
    }
    let delta = old_bounds.origin() - source_bounds.origin();
    let mut candidate_doc = (*state.doc).clone();
    let candidate_node =
        super::transformed(super::document::node(&mut candidate_doc, &original, LinkInfo::default(), false), Affine::translate(delta));
    let mut candidate = old.clone();
    candidate.kind = candidate_node.kind;
    let frame = original.frame;
    let source_frame = Rect::new(frame.x0 + delta.x, frame.y0 + delta.y, frame.x1 + delta.x, frame.y1 + delta.y);
    let area = old_bounds.union(source_frame);
    let region = Rect::new(area.x0 - 2.0, area.y0 - 2.0, area.x1 + 2.0, area.y1 + 2.0);
    same_render(&isolated(&state.doc, old), &isolated(&candidate_doc, candidate.clone()), region)?;
    let NodeKind::PlacedDocument(placed) = &mut candidate.kind else {
        return Err(bad(CMD, "candidate vector source invalid"));
    };
    placed.key.clone_from(&replacement.key);
    let native_kind = serde_json::to_value(&candidate.kind).map_err(|_| bad(CMD, "cannot record verified source frame"))?;
    s.edit("Replace Verified Legacy SVG Group", |doc, _| {
        super::document::store(doc, &replacement);
        let node = doc.node_mut(id).ok_or(EngineError::NoNode(id))?;
        node.kind = candidate.kind;
        host_material::apply(node, &material, false, CMD)?;
        Ok(())
    })?;
    Ok(json!({"ids":[id.0],"sourceKey":replacement.key,"nativeKind":native_kind}))
}
