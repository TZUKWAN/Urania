//! Explicit host material provenance, carried by native data-* attributes.
//! Contains no service credential and never implies live linked membership.
use std::sync::Arc;

use serde::{Deserialize, Serialize};
use serde_json::Value;
use vectorcraft_doc::Node;

use super::bad;
use crate::Result;

pub(crate) const KEY: &str = "dsh-material-v1";
const MAX_VALUE: usize = 1024;

#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields, rename_all = "camelCase")]
pub(crate) struct Request {
    pub schema: u8,
    pub project_id: String,
    pub asset_id: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields, rename_all = "camelCase")]
struct Origin {
    schema: u8,
    project_id: String,
    asset_id: String,
    instance_id: String,
}

fn identity(value: &str, prefix: &str) -> bool {
    value.starts_with(prefix)
        && value.len() <= 81
        && value.len() > prefix.len()
        && value.bytes().all(|c| c.is_ascii_alphanumeric() || matches!(c, b'-' | b'_'))
}
fn valid(origin: &Origin) -> bool {
    origin.schema == 1
        && identity(&origin.project_id, "project-")
        && identity(&origin.asset_id, "asset-")
        && origin.instance_id.len() == 32
        && origin.instance_id.bytes().all(|c| c.is_ascii_digit() || (b'a'..=b'f').contains(&c))
}
fn raw(node: &Node) -> Option<&str> {
    let data = &node.extras().attrs.as_ref()?.data;
    let mut found = data.iter().filter(|(key, _)| key == KEY);
    let (_, value) = found.next()?;
    if found.next().is_some() {
        return None;
    }
    Some(value)
}
fn read(node: &Node) -> Option<Origin> {
    let value = raw(node).filter(|s| s.len() <= MAX_VALUE)?;
    serde_json::from_str(value).ok().filter(valid)
}
fn fresh(cmd: &str) -> Result<String> {
    let mut bytes = [0u8; 16];
    getrandom::fill(&mut bytes).map_err(|error| bad(cmd, format!("material instance randomness unavailable: {error}")))?;
    Ok(bytes.iter().map(|byte| format!("{byte:02x}")).collect())
}
fn write(node: &mut Node, origin: &Origin, cmd: &str) -> Result<()> {
    let text = serde_json::to_string(origin).map_err(|error| bad(cmd, error.to_string()))?;
    node.edit_attrs(|attrs| {
        if let Some((_, value)) = attrs.data.iter_mut().find(|(key, _)| key == KEY) {
            *value = text;
        } else {
            attrs.data.push((KEY.into(), text));
        }
    });
    Ok(())
}
pub(crate) fn request(params: &Value, cmd: &str) -> Result<Option<Request>> {
    let Some(value) = params.get("hostMaterial").filter(|v| !v.is_null()) else { return Ok(None) };
    if value.to_string().len() > MAX_VALUE {
        return Err(bad(cmd, "material origin exceeds budget"));
    }
    let request: Request = serde_json::from_value(value.clone()).map_err(|_| bad(cmd, "invalid hostMaterial"))?;
    if request.schema != 1 || !identity(&request.project_id, "project-") || !identity(&request.asset_id, "asset-") {
        return Err(bad(cmd, "invalid material project/asset identity"));
    }
    Ok(Some(request))
}
pub(crate) fn check(node: &Node, request: &Request, cmd: &str) -> Result<()> {
    let count = node.extras().attrs.as_ref().map_or(0, |a| a.data.iter().filter(|(key, _)| key == KEY).count());
    if count > 0 && read(node).is_none_or(|old| old.project_id != request.project_id) {
        return Err(bad(cmd, "reserved material origin conflicts with this project"));
    }
    Ok(())
}
pub(crate) fn apply(node: &mut Node, request: &Request, preserve_instance: bool, cmd: &str) -> Result<()> {
    check(node, request, cmd)?;
    let instance_id = match read(node).filter(|_| preserve_instance) {
        Some(old) => old.instance_id,
        None => fresh(cmd)?,
    };
    write(node, &Origin { schema: 1, project_id: request.project_id.clone(), asset_id: request.asset_id.clone(), instance_id }, cmd)
}
/// Only new native copies get a fresh identity. Undo/redo restores their recorded
/// identities with the document, distinguishing a redo from a later reused id.
pub(crate) fn refresh_copy(node: &mut Node, cmd: &str) -> Result<()> {
    fn walk(node: &mut Node, cmd: &str, depth: usize, left: &mut usize) -> Result<()> {
        if depth > 64 || *left == 0 {
            return Err(bad(cmd, "copied material tree exceeds budget"));
        }
        *left -= 1;
        if let Some(mut origin) = read(node) {
            origin.instance_id = fresh(cmd)?;
            write(node, &origin, cmd)?;
        }
        // An ordinary duplicate is independent, not an implicit brand member.
        if node.extras().attrs.as_ref().is_some_and(|attrs| attrs.data.iter().any(|(key, _)| key.eq_ignore_ascii_case("dsh-brand-color-v1"))) {
            node.edit_attrs(|attrs| attrs.data.retain(|(key, _)| !key.eq_ignore_ascii_case("dsh-brand-color-v1")));
        }
        if node.extras().attrs.as_ref().is_some_and(|attrs| attrs.data.iter().any(|(key, _)| key.eq_ignore_ascii_case("dsh-brand-font-v1"))) {
            node.edit_attrs(|attrs| attrs.data.retain(|(key, _)| !key.eq_ignore_ascii_case("dsh-brand-font-v1")));
        }
        if let Some(children) = node.children_mut() {
            for child in children {
                walk(Arc::make_mut(child), cmd, depth + 1, left)?;
            }
        }
        Ok(())
    }
    walk(node, cmd, 0, &mut 100000)
}

/// Attach already-verified host references to legacy embedded images. This
/// changes no visible property and stays a real, reversible native edit.
pub(crate) fn assign(s: &mut super::Session, params: &Value) -> Result<Value> {
    const CMD: &str = "image.assignMaterialOrigins";
    let rows = params
        .get("origins")
        .and_then(Value::as_array)
        .filter(|v| !v.is_empty() && v.len() <= 100)
        .ok_or_else(|| bad(CMD, "give 1..100 explicit origins"))?;
    let mut work = Vec::new();
    let mut ids = std::collections::BTreeSet::new();
    let state = s.doc()?;
    if state.global_edit.is_some() || state.doc.mask_edit.is_some() || state.interaction.is_some() {
        return Err(bad(CMD, "finish the native interaction first"));
    }
    for row in rows {
        let id = super::checked_id(s, row.get("id").ok_or_else(|| bad(CMD, "origin needs id"))?, CMD)?;
        if !ids.insert(id) {
            return Err(bad(CMD, "origin ids must be unique"));
        }
        let material = request(row, CMD)?.ok_or_else(|| bad(CMD, "origin needs hostMaterial"))?;
        let node = state.doc.node(id).ok_or(crate::EngineError::NoNode(id))?;
        let vectorcraft_doc::NodeKind::Image(image) = &node.kind else { return Err(bad(CMD, "origin target is not an image")) };
        if image.link.is_some() {
            return Err(bad(CMD, "origin target must be embedded"));
        }
        check(node, &material, CMD)?;
        work.push((id, material));
    }
    s.edit("Attach Material Sources", |document, _| {
        for (id, material) in &work {
            apply(document.node_mut(*id).ok_or(crate::EngineError::NoNode(*id))?, material, true, CMD)?;
        }
        Ok(())
    })?;
    Ok(serde_json::json!({"ids":work.iter().map(|(id,_)|id.0).collect::<Vec<_>>()}))
}
