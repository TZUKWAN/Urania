#![allow(clippy::unwrap_used, clippy::panic, clippy::expect_used)]
// Real engine commands and in-memory native clipboard; never OS clipboard/UI.
use serde_json::{Value, json};
use std::io::Cursor;
use vectorcraft_doc::NodeId;
use vectorcraft_engine::Session;

fn png(color: [u8; 4]) -> Vec<u8> {
    let mut out = Vec::new();
    image::RgbaImage::from_pixel(12, 8, image::Rgba(color)).write_to(&mut Cursor::new(&mut out), image::ImageFormat::Png).unwrap();
    out
}
fn material(asset: &str) -> Value {
    json!({"schema":1,"projectId":"project-fixture","assetId":asset})
}
fn origin(s: &Session, id: u64) -> Value {
    let node = s.doc().unwrap().doc.node(NodeId(id)).unwrap();
    let value = &node.extras().attrs.as_ref().unwrap().data.iter().find(|(k, _)| k == "dsh-material-v1").unwrap().1;
    serde_json::from_str(value).unwrap()
}
fn session() -> Session {
    let mut s = Session::new();
    s.execute("file.new", &json!({"width":500,"height":300})).unwrap();
    s
}
fn place(s: &mut Session, marker: bool) -> u64 {
    let mut p = json!({"name":"original.png","dataBase64":vectorcraft_format::base64_encode(&png([0,0,0,255])),"link":false});
    if marker {
        p["hostMaterial"] = material("asset-original");
    }
    s.execute("file.place", &p).unwrap()["ids"][0].as_u64().unwrap()
}
#[test]
fn origin_is_atomic_with_native_place_replace_and_undo_redo() {
    let mut s = session();
    let before = s.doc().unwrap().history.undo.len();
    let id = place(&mut s, true);
    let old = origin(&s, id);
    assert_eq!(s.doc().unwrap().history.undo.len(), before + 1);
    assert_eq!(old["assetId"], "asset-original");
    assert_eq!(old["instanceId"].as_str().unwrap().len(), 32);
    let document = s.doc().unwrap().doc.clone();
    let undo = s.doc().unwrap().history.undo.len();
    s.execute(
        "image.replaceContent",
        &json!({"ids":[id],"dataBase64":vectorcraft_format::base64_encode(&png([0,180,80,255])),"hostMaterial":material("asset-edited")}),
    )
    .unwrap();
    let updated = origin(&s, id);
    assert_eq!(updated["instanceId"], old["instanceId"]);
    assert_eq!(updated["assetId"], "asset-edited");
    assert_eq!(s.doc().unwrap().history.undo.len(), undo + 1);
    s.execute("edit.undo", &json!({})).unwrap();
    assert_eq!(origin(&s, id), old);
    assert_eq!(*s.doc().unwrap().doc, *document);
    s.execute("edit.redo", &json!({})).unwrap();
    assert_eq!(origin(&s, id), updated);
    let native = vectorcraft_format::save(&s.doc().unwrap().doc, false);
    let loaded = vectorcraft_format::load(&native).unwrap();
    assert_eq!(
        serde_json::to_value(loaded.node(NodeId(id)).unwrap()).unwrap(),
        serde_json::to_value(s.doc().unwrap().doc.node(NodeId(id)).unwrap()).unwrap()
    );
}
#[test]
fn native_duplicates_and_internal_pastes_get_independent_stable_identities() {
    let mut s = session();
    let id = place(&mut s, true);
    s.execute("object.setProps", &json!({"ids":[id],"data":{"customer":"keep-me"}})).unwrap();
    let original = origin(&s, id);
    let copy = s.execute("edit.duplicate", &json!({"ids":[id]})).unwrap()["ids"][0].as_u64().unwrap();
    let copied = origin(&s, copy);
    assert_ne!(copied["instanceId"], original["instanceId"]);
    assert_eq!(copied["assetId"], original["assetId"]);
    assert!(
        s.doc().unwrap().doc.node(NodeId(copy)).unwrap().extras().attrs.as_ref().unwrap().data.iter().any(|(k, v)| k == "customer" && v == "keep-me")
    );
    s.execute("edit.undo", &json!({})).unwrap();
    s.execute("edit.redo", &json!({})).unwrap();
    assert_eq!(origin(&s, copy), copied);
    s.execute("select.set", &json!({"ids":[copy]})).unwrap();
    s.execute("edit.copy", &json!({})).unwrap();
    let pasted = s.execute("edit.paste", &json!({})).unwrap()["ids"][0].as_u64().unwrap();
    let pasted_origin = origin(&s, pasted);
    assert_ne!(pasted_origin["instanceId"], copied["instanceId"]);
    assert_ne!(pasted_origin["instanceId"], original["instanceId"]);
    assert_eq!(pasted_origin["assetId"], original["assetId"]);
}
#[test]
fn legacy_annotation_and_conflicting_reserved_data_are_real_atomic_edits() {
    let mut s = session();
    let id = place(&mut s, false);
    let original = s.doc().unwrap().doc.clone();
    let before = s.doc().unwrap().history.undo.len();
    s.execute("image.assignMaterialOrigins", &json!({"origins":[{"id":id,"hostMaterial":material("asset-original")}]})).unwrap();
    assert_eq!(origin(&s, id)["assetId"], "asset-original");
    assert_eq!(s.doc().unwrap().history.undo.len(), before + 1);
    s.execute("edit.undo", &json!({})).unwrap();
    assert_eq!(*s.doc().unwrap().doc, *original);
    s.execute("object.setProps", &json!({"ids":[id],"data":{"dsh-material-v1":"customer data"}})).unwrap();
    let conflict = s.doc().unwrap().doc.clone();
    let undo = s.doc().unwrap().history.undo.len();
    assert!(
        s.execute(
            "image.replaceContent",
            &json!({"ids":[id],"dataBase64":vectorcraft_format::base64_encode(&png([255,0,0,255])),"hostMaterial":material("asset-edited")})
        )
        .is_err()
    );
    assert_eq!(*s.doc().unwrap().doc, *conflict);
    assert_eq!(s.doc().unwrap().history.undo.len(), undo);
}

#[test]
fn external_host_parameter_contract_accepts_origin_without_accepting_typos() {
    let params = json!({"ids":[2],"dataBase64":"actual content is validated by command","hostMaterial":material("asset-original")});
    vectorcraft_engine::cmd::params::check_params("image.replaceContent", &params).unwrap();
    assert!(vectorcraft_engine::cmd::params::check_params("image.replaceContent", &json!({"hostMaterail":material("asset-original")})).is_err());
}
