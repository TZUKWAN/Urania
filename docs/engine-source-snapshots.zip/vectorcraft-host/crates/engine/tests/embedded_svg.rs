#![allow(clippy::unwrap_used, clippy::panic, clippy::expect_used)]
// Real source/edited source were exported by an owned Vector app after a
// physical path move. These are native commands, not mocked renderer results.
use serde_json::{Value, json};
use vectorcraft_color::BlendMode;
use vectorcraft_doc::{NodeId, NodeKind};
use vectorcraft_engine::Session;
use vectorcraft_geom::Affine;
const ORIGINAL: &[u8] = include_bytes!("fixtures/dsh-svg-source/source.vectorcraft");
const EDITED: &[u8] = include_bytes!("fixtures/dsh-svg-source/edited-source.vectorcraft");
fn material(id: &str) -> Value {
    json!({"schema":1,"projectId":"project-fixture","assetId":id})
}
fn params(bytes: &[u8], asset: &str) -> Value {
    json!({"sourceBase64":vectorcraft_format::base64_encode(bytes),"hostMaterial":material(asset)})
}
fn session() -> Session {
    let mut s = Session::new();
    s.execute("file.new", &json!({"width":640,"height":480})).unwrap();
    s
}
fn place(s: &mut Session, x: f64) -> NodeId {
    let mut p = params(ORIGINAL, "asset-original");
    p["rect"] = json!([x, 60, 240, 180]);
    NodeId(s.execute("svg.placeSource", &p).unwrap()["ids"][0].as_u64().unwrap())
}
fn origin(s: &Session, id: NodeId) -> Value {
    let n = s.doc().unwrap().doc.node(id).unwrap();
    serde_json::from_str(&n.extras().attrs.as_ref().unwrap().data.iter().find(|(k, _)| k == "dsh-material-v1").unwrap().1).unwrap()
}
fn source<'a>(doc: &'a vectorcraft_doc::Document, id: NodeId) -> &'a [u8] {
    let NodeKind::PlacedDocument(p) = &doc.node(id).unwrap().kind else { panic!("expected embedded vector") };
    assert!(p.is_embedded());
    doc.images[&p.key].bytes.as_slice()
}

#[test]
fn actual_vector_source_replacement_keeps_the_full_scene_frame_and_undo() {
    let mut s = session();
    let id = place(&mut s, 20.0);
    let other = place(&mut s, 350.0);
    let mask = NodeId(s.execute("shape.rectangle", &json!({"x":20,"y":60,"width":200,"height":150})).unwrap()["id"].as_u64().unwrap());
    s.execute("object.group", &json!({"ids":[id.0,mask.0]})).unwrap();
    let parent = s.doc().unwrap().doc.position(id).unwrap().0.unwrap();
    s.edit("fixture appearance", |doc, _| {
        let n = doc.node_mut(id).unwrap();
        n.opacity = 0.63;
        n.blend = BlendMode::Multiply;
        n.bbox_angle = 21.0;
        let NodeKind::PlacedDocument(p) = &mut n.kind else { panic!("vector") };
        p.xf = Affine::translate((300.0, 95.0)) * Affine::rotate(0.37) * Affine::scale_non_uniform(-0.8, 1.3);
        let g = doc.node_mut(parent).unwrap();
        let NodeKind::Group { children, clip } = &mut g.kind else { panic!("group") };
        let index = children.iter().position(|n| n.id == mask).unwrap();
        children.swap(0, index);
        *clip = true;
        Ok(())
    })
    .unwrap();
    let before = s.doc().unwrap().doc.clone();
    let old = origin(&s, id);
    let undo = s.doc().unwrap().history.undo.len();
    let mut p = params(EDITED, "asset-edited");
    p["ids"] = json!([id.0]);
    s.execute("svg.replaceSource", &p).unwrap();
    let after = s.doc().unwrap().doc.clone();
    let new = origin(&s, id);
    assert_eq!(s.doc().unwrap().history.undo.len(), undo + 1);
    assert_eq!(new["instanceId"], old["instanceId"]);
    assert_eq!(new["assetId"], "asset-edited");
    assert_eq!(source(&after, id), EDITED);
    assert_eq!(source(&after, other), ORIGINAL);
    assert_eq!(after.node(other), before.node(other));
    let mut normalized = (*after).clone();
    normalized.images = before.images.clone();
    let old_node = before.node(id).unwrap();
    let node = normalized.node_mut(id).unwrap();
    let NodeKind::PlacedDocument(old_p) = &old_node.kind else { panic!("old vector") };
    let NodeKind::PlacedDocument(new_p) = &mut node.kind else { panic!("new vector") };
    new_p.key.clone_from(&old_p.key);
    node.extras_mut().attrs.as_mut().unwrap().data.iter_mut().find(|(k, _)| k == "dsh-material-v1").unwrap().1 =
        old_node.extras().attrs.as_ref().unwrap().data.iter().find(|(k, _)| k == "dsh-material-v1").unwrap().1.clone();
    assert_eq!(normalized, *before);
    let mut renderer = vectorcraft_render::Renderer::new();
    let area = vectorcraft_geom::Rect::new(0.0, 0.0, 640.0, 480.0);
    let old_pixels = image::load_from_memory(&renderer.render_region(&before, area, 1.0, false).to_png().unwrap()).unwrap().to_rgba8();
    let new_pixels = image::load_from_memory(&renderer.render_region(&after, area, 1.0, false).to_png().unwrap()).unwrap().to_rgba8();
    assert!(old_pixels.pixels().zip(new_pixels.pixels()).any(|(a, b)| a != b), "the actual native render must change");
    let native = vectorcraft_format::save(&after, false);
    let reopened = vectorcraft_format::load(&native).unwrap();
    assert_eq!(source(&reopened, id), EDITED);
    assert_eq!(source(&reopened, other), ORIGINAL);
    assert_eq!(reopened.node(id), after.node(id));
    s.execute("edit.undo", &json!({})).unwrap();
    assert_eq!(*s.doc().unwrap().doc, *before);
    s.execute("edit.redo", &json!({})).unwrap();
    assert_eq!(*s.doc().unwrap().doc, *after);
    let links = s.execute("links.list", &json!({"show":"embedded"})).unwrap();
    let row = links["links"].as_array().unwrap().iter().find(|r| r["id"] == id.0).unwrap();
    assert_eq!(row["linked"], false);
    assert!(row.get("path").is_none());
    let svg = s.execute("document.serialize", &json!({"format":"svg"})).unwrap();
    let text = svg["text"].as_str().unwrap();
    assert!(text.contains("<path"));
    assert!(!text.contains("data:image/png"));
    if let Some(path) = std::env::var_os("DSH_DESIGNCRAFT_TEST_VECTOR_SVG_OUT") {
        let out = std::path::PathBuf::from(path);
        assert!(out.is_absolute());
        std::fs::create_dir_all(&out).unwrap();
        std::fs::write(out.join("before.vectorcraft"), vectorcraft_format::save(&before, false)).unwrap();
        std::fs::write(out.join("after.vectorcraft"), &native).unwrap();
        std::fs::write(out.join("after.svg"), text).unwrap();
        std::fs::write(out.join("metadata.json"),serde_json::to_vec_pretty(&json!({"targetId":id.0,"otherId":other.0,"originBefore":old,"originAfter":new,"producer":"actual svg.placeSource/svg.replaceSource integration test"})).unwrap()).unwrap();
    }
}
#[test]
fn duplicate_is_independent_and_invalid_or_locked_updates_are_atomic() {
    let mut s = session();
    let id = place(&mut s, 20.0);
    let copy = NodeId(s.execute("edit.duplicate", &json!({"ids":[id.0]})).unwrap()["ids"][0].as_u64().unwrap());
    assert_ne!(origin(&s, id)["instanceId"], origin(&s, copy)["instanceId"]);
    let cases = [
        json!({"ids":[id.0],"sourceBase64":"bad"}),
        json!({"ids":[id.0,id.0],"sourceBase64":vectorcraft_format::base64_encode(EDITED)}),
        json!({"ids":[999999],"sourceBase64":vectorcraft_format::base64_encode(EDITED)}),
        json!({"ids":[id.0],"path":"must-not-be-read","sourceBase64":vectorcraft_format::base64_encode(EDITED)}),
    ];
    for p in cases {
        let before = s.doc().unwrap().doc.clone();
        let n = s.doc().unwrap().history.undo.len();
        assert!(s.execute("svg.replaceSource", &p).is_err());
        assert_eq!(*s.doc().unwrap().doc, *before);
        assert_eq!(s.doc().unwrap().history.undo.len(), n);
    }
    s.execute("object.setProps", &json!({"ids":[id.0],"locked":true})).unwrap();
    let before = s.doc().unwrap().doc.clone();
    let mut p = params(EDITED, "asset-edited");
    p["ids"] = json!([copy.0, id.0]);
    assert!(s.execute("svg.replaceSource", &p).is_err());
    assert_eq!(*s.doc().unwrap().doc, *before);
}
#[test]
fn host_parameter_contract_allows_source_and_rejects_typos() {
    let mut p = params(ORIGINAL, "asset-original");
    p["at"] = json!([200, 160]);
    vectorcraft_engine::cmd::params::check_params("svg.placeSource", &p).unwrap();
    let mut replace = params(EDITED, "asset-edited");
    replace["ids"] = json!([2]);
    vectorcraft_engine::cmd::params::check_params("svg.replaceSource", &replace).unwrap();
    assert!(vectorcraft_engine::cmd::params::check_params("svg.placeSource", &json!({"sorceBase64":"bad"})).is_err());
}

#[test]
fn legacy_empty_absolute_link_is_not_reclassified_as_embedded() {
    let mut s = session();
    let id = place(&mut s, 20.0);
    let NodeKind::PlacedDocument(p) = &s.doc().unwrap().doc.node(id).unwrap().kind else { panic!("vector") };
    let mut legacy = (**p).clone();
    legacy.embedded = false;
    legacy.link.relative = Some("art/source.vectorcraft".into());
    let value = serde_json::to_value(&legacy).unwrap();
    assert!(value.get("embedded").is_none());
    let reopened: vectorcraft_doc::PlacedDocument = serde_json::from_value(value).unwrap();
    assert!(!reopened.is_embedded());
    assert_eq!(reopened.link.relative.as_deref(), Some("art/source.vectorcraft"));
}

#[test]
fn linked_nested_and_compressed_sources_are_refused_without_mutation() {
    use std::io::Write;
    use vectorcraft_doc::{ImageBlob, ImageObject, LinkInfo, Node};
    let mut source = vectorcraft_format::load(ORIGINAL).unwrap();
    let layer = source.layers[0].id;
    let key = "external-fixture".to_string();
    let mut png = Vec::new();
    image::RgbaImage::from_pixel(1, 1, image::Rgba([8, 30, 50, 255])).write_to(&mut std::io::Cursor::new(&mut png), image::ImageFormat::Png).unwrap();
    source.images.insert(key.clone(), ImageBlob::new("image/png", png));
    let image = ImageObject {
        key,
        width: 1,
        height: 1,
        xf: Affine::IDENTITY,
        link: Some(LinkInfo::new("C:/no-such-file.png")),
        placement: Default::default(),
        pixels: None,
    };
    let id = source.alloc_id();
    source.insert(Some(layer), usize::MAX, Node::new(id, NodeKind::Image(Box::new(image)))).unwrap();
    let external = vectorcraft_format::save(&source, false);
    let mut nested = session();
    place(&mut nested, 20.0);
    let nested = vectorcraft_format::save(&nested.doc().unwrap().doc, false);
    let mut gzip = flate2::write::GzEncoder::new(Vec::new(), flate2::Compression::default());
    gzip.write_all(ORIGINAL).unwrap();
    let compressed = gzip.finish().unwrap();
    let mut target = session();
    let before = target.doc().unwrap().doc.clone();
    let undo = target.doc().unwrap().history.undo.len();
    for bytes in [&external, &nested, &compressed] {
        assert!(target.execute("svg.placeSource", &params(bytes, "asset-original")).is_err());
        assert_eq!(*target.doc().unwrap().doc, *before);
        assert_eq!(target.doc().unwrap().history.undo.len(), undo);
    }
}
