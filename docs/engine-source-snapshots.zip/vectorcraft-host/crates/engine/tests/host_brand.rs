#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]
use serde_json::json;
use vectorcraft_doc::NodeId;
use vectorcraft_engine::Session;

const KEY: &str = "dsh-brand-color-v1";
fn has_brand(s: &Session, id: u64) -> bool {
    s.doc()
        .unwrap()
        .doc
        .node(NodeId(id))
        .unwrap()
        .extras()
        .attrs
        .as_ref()
        .is_some_and(|attrs| attrs.data.iter().any(|(key, _)| key.eq_ignore_ascii_case(KEY)))
}
#[test]
fn native_marker_is_reversible_and_ordinary_copies_are_independent() {
    let mut s = Session::new();
    s.execute("file.new", &json!({"width":500,"height":300})).unwrap();
    let id = s.execute("shape.rectangle", &json!({"x":30,"y":40,"width":100,"height":80})).unwrap()["id"].as_u64().unwrap();
    s.execute("paint.setFill", &json!({"ids":[id],"color":"#287D6C"})).unwrap();
    s.execute("object.setProps", &json!({"ids":[id],"data":{"customer":"keep"}})).unwrap();
    let before = s.doc().unwrap().doc.clone();
    let mut token = [0u8; 16];
    getrandom::fill(&mut token).unwrap();
    let token: String = token.iter().map(|b| format!("{b:02x}")).collect();
    let marker = json!({"schema":1,"projectId":"project-fixture","bindingId":"brandcolor-00000000-0000-4000-8000-000000000001","instanceId":token});
    s.execute("object.setProps", &json!({"ids":[id],"data":{"dsh-brand-color-v1":marker.to_string()}})).unwrap();
    assert!(has_brand(&s, id));
    if let Some(dir) = std::env::var_os("DSH_BRAND_VECTOR_CAPTURE") {
        let dir = std::path::PathBuf::from(dir);
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join("brand-vector-marker-before.vectorcraft"), vectorcraft_format::save(&before, false)).unwrap();
        std::fs::write(dir.join("brand-vector-marker-after.vectorcraft"), vectorcraft_format::save(&s.doc().unwrap().doc, false)).unwrap();
        std::fs::write(dir.join("brand-vector-marker.json"), serde_json::to_vec_pretty(&json!({"nativeId":id,"marker":marker})).unwrap()).unwrap();
    }
    s.execute("edit.undo", &json!({})).unwrap();
    assert_eq!(*s.doc().unwrap().doc, *before);
    s.execute("edit.redo", &json!({})).unwrap();
    assert!(has_brand(&s, id));
    let loaded = vectorcraft_format::load(&vectorcraft_format::save(&s.doc().unwrap().doc, false)).unwrap();
    assert_eq!(
        serde_json::to_value(loaded.node(NodeId(id)).unwrap()).unwrap(),
        serde_json::to_value(s.doc().unwrap().doc.node(NodeId(id)).unwrap()).unwrap()
    );
    let copy = s.execute("edit.duplicate", &json!({"ids":[id]})).unwrap()["ids"][0].as_u64().unwrap();
    assert!(!has_brand(&s, copy));
    assert!(has_brand(&s, id));
    assert!(
        s.doc()
            .unwrap()
            .doc
            .node(NodeId(copy))
            .unwrap()
            .extras()
            .attrs
            .as_ref()
            .unwrap()
            .data
            .iter()
            .any(|(key, value)| key == "customer" && value == "keep")
    );
    s.execute("select.set", &json!({"ids":[id]})).unwrap();
    s.execute("edit.copy", &json!({})).unwrap();
    let pasted = s.execute("edit.paste", &json!({})).unwrap()["ids"][0].as_u64().unwrap();
    assert!(!has_brand(&s, pasted));
    assert!(has_brand(&s, id));
}
