#![allow(clippy::unwrap_used, clippy::panic, clippy::expect_used)]
// Original owned QA files: native source, old poster and derivative SVG.
use serde_json::{Value, json};
use vectorcraft_doc::{NodeId, NodeKind};
use vectorcraft_engine::Session;

const POSTER: &[u8] = include_bytes!("fixtures/dsh-legacy-svg/current.vectorcraft");
const SOURCE: &[u8] = include_bytes!("fixtures/dsh-legacy-svg/source.vectorcraft");
const SVG: &[u8] = include_bytes!("fixtures/dsh-legacy-svg/source.svg");
fn original_session() -> Session {
    let mut session = Session::new();
    session.add_document(vectorcraft_format::load(POSTER).unwrap(), None);
    session
}
fn edited_source() -> Vec<u8> {
    let mut session = Session::new();
    session.add_document(vectorcraft_format::load(SOURCE).unwrap(), None);
    session.execute("object.move", &json!({"ids":[2],"dx":10,"dy":0})).unwrap();
    vectorcraft_format::save(&session.doc().unwrap().doc, false)
}
fn params(original: &[u8], edited: &[u8], svg: &[u8]) -> Value {
    json!({"id":6,"originalSvgBase64":vectorcraft_format::base64_encode(svg),"originalSourceBase64":vectorcraft_format::base64_encode(original),"sourceBase64":vectorcraft_format::base64_encode(edited),"hostMaterial":{"schema":1,"projectId":"project-fixture","assetId":"asset-edited"}})
}

#[test]
fn actual_unchanged_group_replaces_source_in_one_undo_and_retains_other_data() {
    let mut session = original_session();
    let edited = edited_source();
    let before = session.doc().unwrap().doc.clone();
    let history = session.doc().unwrap().history.undo.len();
    let result = session.execute("svg.replaceLegacyGroup", &params(SOURCE, &edited, SVG)).unwrap();
    let after = session.doc().unwrap().doc.clone();
    assert_eq!(session.doc().unwrap().history.undo.len(), history + 1);
    let old = before.node(NodeId(6)).unwrap();
    let new = after.node(NodeId(6)).unwrap();
    let NodeKind::PlacedDocument(placed) = &new.kind else { panic!("expected embedded vector") };
    assert!(placed.is_embedded());
    assert_eq!(&after.images[&placed.key].bytes[..], &edited);
    assert_eq!(result["nativeKind"], serde_json::to_value(&new.kind).unwrap());
    let mut normalized = (*after).clone();
    normalized.images = before.images.clone();
    *normalized.node_mut(NodeId(6)).unwrap() = old.clone();
    assert_eq!(normalized, *before);
    assert_eq!(after.node(NodeId(12)), before.node(NodeId(12)));
    let save = vectorcraft_format::save(&after, false);
    let reopened = vectorcraft_format::load(&save).unwrap();
    let NodeKind::PlacedDocument(p) = &reopened.node(NodeId(6)).unwrap().kind else { panic!("reopen lost source") };
    assert_eq!(&reopened.images[&p.key].bytes[..], &edited);
    let region = vectorcraft_geom::Rect::new(0.0, 0.0, 1280.0, 720.0);
    let old = vectorcraft_render::Renderer::new().render_region(&before, region, 1.0, false);
    let new = vectorcraft_render::Renderer::new().render_region(&after, region, 1.0, false);
    assert_ne!(old.pixels, new.pixels, "actual poster pixels must change after editing");
    if let Some(path) = std::env::var_os("DESIGNCRAFT_LEGACY_TEST_CAPTURE") {
        let path = std::path::Path::new(&path);
        std::fs::create_dir_all(path).unwrap();
        std::fs::write(path.join("before.vectorcraft"), vectorcraft_format::save(&before, false)).unwrap();
        std::fs::write(path.join("after.vectorcraft"), &save).unwrap();
        std::fs::write(path.join("edited-source.vectorcraft"), &edited).unwrap();
        std::fs::write(path.join("native-kind.json"), serde_json::to_vec(&result["nativeKind"]).unwrap()).unwrap();
        let mut source_session = Session::new();
        source_session.add_document(vectorcraft_format::load(&edited).unwrap(), None);
        let svg = source_session.execute("document.serialize", &json!({"format":"svg"})).unwrap();
        std::fs::write(path.join("edited.svg"), svg["text"].as_str().unwrap()).unwrap();
        let source_doc = &source_session.doc().unwrap().doc;
        let preview = vectorcraft_render::Renderer::new().render_region(source_doc, source_doc.artboards[0].rect, 1.0, false).to_png().unwrap();
        std::fs::write(path.join("edited-preview.png"), preview).unwrap();
    }
    session.execute("edit.undo", &json!({})).unwrap();
    assert_eq!(*session.doc().unwrap().doc, *before);
    session.execute("edit.redo", &json!({})).unwrap();
    assert_eq!(*session.doc().unwrap().doc, *after);
}

#[test]
fn modified_group_mismatched_original_and_external_svg_are_refused_atomically() {
    let edited = edited_source();
    for case in 0..3 {
        let mut session = original_session();
        if case == 0 {
            session.execute("object.move", &json!({"ids":[2],"dx":5,"dy":0})).unwrap();
        }
        let before = session.doc().unwrap().doc.clone();
        let count = session.doc().unwrap().history.undo.len();
        let bad_svg = br#"<svg xmlns="http://www.w3.org/2000/svg"><image href="file:///C:/private.png"/></svg>"#;
        let input = if case == 1 {
            params(&edited, &edited, SVG)
        } else if case == 2 {
            params(SOURCE, &edited, bad_svg)
        } else {
            params(SOURCE, &edited, SVG)
        };
        assert!(session.execute("svg.replaceLegacyGroup", &input).is_err());
        assert_eq!(*session.doc().unwrap().doc, *before);
        assert_eq!(session.doc().unwrap().history.undo.len(), count);
    }
}

#[test]
fn legacy_command_parameter_contract_rejects_misspellings() {
    let p = params(SOURCE, SOURCE, SVG);
    vectorcraft_engine::cmd::params::check_params("svg.replaceLegacyGroup", &p).unwrap();
    assert!(vectorcraft_engine::cmd::params::check_params("svg.replaceLegacyGroup", &json!({"orignalSvgBase64":"bad"})).is_err());
}
