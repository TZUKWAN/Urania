//! A source-owning embedding of the genuine Photo App. No common-canvas pixel projection.
use super::params::{err, ok};
use super::{ControlRequest, Outcome};
use crate::PhotocraftApp;

#[cfg(test)]
#[path = "hosted_tests.rs"]
mod tests;
use base64::Engine as _;
use photocraft_doc::{Layer, LayerContent, LayerId};
use serde_json::{Value, json};
use std::sync::mpsc::{Receiver, Sender, TryRecvError};

struct Pending {
    uid: u64,
    receiver: Receiver<Value>,
    reply: Sender<Value>,
}

#[derive(Default)]
pub(crate) struct HostState {
    pub embedded: bool,
    pub theme_override: Option<crate::theme::ThemeKind>,
    pub file_routing: bool,
    pub pending_file: Option<Value>,
    next_file: u64,
    next_context: u64,
    original_theme: Option<crate::theme::ThemeKind>,
    pending: Vec<Pending>,
    pub open_warnings: Vec<String>,
    pub open_error: Option<String>,
    pub opening: bool,
    summaries: Option<(u64, u64, Vec<Value>, bool)>,
}

fn pending_interaction(app: &PhotocraftApp) -> bool {
    app.live_stroke.is_some()
        || app.live_adjust.is_some()
        || app.ui.transform.is_some()
        || app.ui.cam_transform.is_some()
        || app.ui.type_transform.is_some()
        || app.ui.symmetry_transform.is_some()
        || (app.ui.crop_rect.is_some() && !app.crop.default_frame)
        || app.crop.drag.is_some()
        || app.ui.perspective_crop.is_some()
        || app.ui.text_edit.as_ref().is_some_and(|edit| edit.preedit.is_some() || edit.dragging || edit.resize.is_some() || edit.mask)
        || !app.ui.dialogs.is_empty()
}

fn coverage(surface: &photocraft_raster::Surface, role: &str, uid: u64, revision: u64) -> Value {
    let bounds = surface.content_bounds();
    json!({"kind":"native-coverage-surface", "nativeRole":role, "uid":uid, "revision":revision,
        "format":format!("{:?}", surface.format()), "channels":surface.channels(),
        "defaultPixel":surface.default_pixel(), "tiles":surface.tile_count(),
        "bounds":[bounds.x0,bounds.y0,bounds.width(),bounds.height()],
        "storage":"full native surface in the pcraft source; bounds are not alpha data"})
}

fn layers(items: &[Layer], depth: usize, left: &mut usize, limited: &mut bool) -> Vec<Value> {
    let count = 50.min(*left).min(items.len());
    if items.len() > count {
        *limited = true;
    }
    let mut results = Vec::new();
    for layer in items.iter().rev().take(count) {
        if *left == 0 {
            *limited = true;
            break;
        }
        *left -= 1;
        let bounds = layer.surface().map(|surface| {
            let r = surface.content_bounds();
            json!([r.x0, r.y0, r.width(), r.height()])
        });
        let mut value = json!({"id":layer.id.0,"name":layer.name.chars().take(200).collect::<String>(),"kind":layer.content.kind_name(),
            "visible":layer.visible,"opacity":layer.opacity,"fill":layer.fill_opacity,"blend":layer.blend.label(),
            "clipped":layer.clipped,"hasMask":layer.mask.is_some(),"hasVectorMask":layer.vector_mask.is_some(),"bounds":bounds});
        if layer.name.chars().count() > 200 {
            *limited = true;
            value["nameTruncated"] = json!(true);
        }
        match &layer.content {
            LayerContent::Group(group) => {
                let children = if depth < 2 {
                    layers(&group.children, depth + 1, left, limited)
                } else {
                    if !group.children.is_empty() {
                        *limited = true;
                    }
                    Vec::new()
                };
                value["children"] = json!(children);
                value["childCount"] = json!(group.children.len());
            }
            LayerContent::Text(text) => {
                let length = text.text.chars().count();
                value["textPreview"] = json!(text.text.chars().take(512).collect::<String>());
                value["textLength"] = json!(length);
                if length > 512 {
                    *limited = true;
                    value["textTruncated"] = json!(true);
                }
            }
            _ => {}
        }
        results.push(value);
    }
    results
}

fn document(app: &mut PhotocraftApp) -> Result<Value, String> {
    let uid = app.session.active_generation();
    let state = app.session.active().ok_or("no native image open")?;
    let doc = &state.doc;
    let (summaries, limited) = match &app.hosted.summaries {
        Some((cached_uid, revision, items, limited)) if *cached_uid == uid && *revision == state.revision => (items.clone(), *limited),
        _ => {
            let mut limited = false;
            let items = layers(&doc.layers, 0, &mut 200, &mut limited);
            app.hosted.summaries = Some((uid, state.revision, items.clone(), limited));
            (items, limited)
        }
    };
    let selected: Vec<u64> = state.selected_layers().iter().map(|id| id.0).collect();
    let selection = json!({"documentId":doc.id.0,"activeGeneration":uid,"activeLayer":state.active_layer.map(|id|id.0),
        "selectedLayers":selected,"layerAnchor":state.layer_anchor.map(|id|id.0),"isolatedLayers":state.isolated_layers.iter().map(|id|id.0).collect::<Vec<_>>(),
        "rasterSelection":doc.selection.as_ref().map(|surface|coverage(surface,"document.selection",uid,state.revision)),
        "quickMask":doc.quick_mask.is_some(),"quickMaskUnselected":doc.quick_mask_unselected,
        "maskTarget":app.ui.mask_target,"vectorMaskTarget":app.ui.vector_mask_target,"filterMaskTarget":app.ui.filter_mask_target,
        "channels":photocraft_engine::channel_cmds::channels_json(state)});
    // The native brush counter covers complete tip/dynamics/current-preset changes
    // without reserializing brush pixels on every inspection.
    let tool = json!({"tool":app.ui.tool,"options":app.ui.tool_options,"brushRevision":app.session.tools.brush_rev,
        "presetRevision":app.session.tools.presets_rev,"foreground":app.session.tools.foreground,"background":app.session.tools.background,
        "textEdit":app.ui.text_edit,"maskTargeted":app.session.tools.mask_targeted});
    let page = json!({"kind":"image","nativeDocumentId":doc.id.0,"width":doc.size.width,"height":doc.size.height});
    let stamp = serde_json::to_string(&json!({"selection":selection,"tool":tool,"page":page})).map_err(|error| error.to_string())?;
    if stamp.len() > 512 * 1024 {
        return Err("native selection/tool context exceeds budget".into());
    }
    let next = app.hosted.next_context.checked_add(1).ok_or("native context sequence exhausted")?;
    let result = json!({"engine":"photocraft","contextProtocol":2,"contextSequence":next,
        "uid":uid,"identityKind":"native-active-document-generation","nativeDocumentId":doc.id.0,"revision":state.revision,
        "title":doc.name,"width":doc.size.width,"height":doc.size.height,"mode":format!("{:?}",doc.mode),"depth":doc.depth.bits(),
        "dirty":state.is_dirty(),"nativeSelection":{"kind":"photocraft","data":selection},"selectionStamp":stamp,
        "toolContext":tool,"page":page,"coordinateSpace":"image-pixels","layers":summaries,
        "history":state.history.entries(),"redo":state.history.redo_labels().collect::<Vec<_>>(),"summaryLimited":limited,
        "pendingInteraction":pending_interaction(app),"openWarnings":app.hosted.open_warnings});
    app.hosted.next_context = next;
    Ok(result)
}
fn base(app: &mut PhotocraftApp, p: &Value) -> Result<Value, String> {
    if pending_interaction(app) {
        return Err("finish the native stroke, composition, transform or dialog before this action".into());
    }
    let current = document(app)?;
    let before = p.get("base").ok_or("host action requires the complete current native base")?;
    for key in ["uid", "revision", "engine", "selectionStamp"] {
        if before.get(key).is_none() || before.get(key) != current.get(key) {
            return Err(format!("host conflict: native {key} changed"));
        }
    }
    Ok(current)
}
fn encoded(app: &PhotocraftApp, format: &str) -> Result<Value, String> {
    if pending_interaction(app) {
        return Err("native input is still in progress; no intermediate source was saved".into());
    }
    if !matches!(format, "pcraft" | "png") {
        return Err("this Photo host currently exports pcraft or PNG".into());
    }
    let state = app.session.active().ok_or("no native image open")?;
    if state.doc.size.width > 16384 || state.doc.size.height > 16384 || u64::from(state.doc.size.width) * u64::from(state.doc.size.height) > 24_000_000 {
        return Err("native image exceeds embedded canvas budget".into());
    }
    if format == "pcraft" {
        let bytes = state.pcraft_cache.encode(&state.doc, &Default::default()).map_err(|error| error.to_string())?;
        if bytes.len() > 256 * 1024 * 1024 {
            return Err("native image source exceeds 256 MiB".into());
        }
        return Ok(json!({"dataBase64":base64::engine::general_purpose::STANDARD.encode(bytes),"warnings":Vec::<String>::new()}));
    }
    let options =
        photocraft_io::ExportOptions { read_linked_files: false, document_path: None, pcraft_cache: Some(state.pcraft_cache.clone()), ..Default::default() };
    let output = photocraft_io::export(&state.doc, &format!("{}.{}", state.doc.name, format), &options).map_err(|error| error.to_string())?;
    if output.bytes.len() > 256 * 1024 * 1024 {
        return Err("native image source exceeds 256 MiB".into());
    }
    Ok(json!({"dataBase64":base64::engine::general_purpose::STANDARD.encode(output.bytes),"warnings":output.warnings}))
}

pub(crate) fn intercept(app: &mut PhotocraftApp, id: &str, params: &Value) -> Option<Result<Value, String>> {
    if !app.hosted.file_routing {
        return None;
    }
    let action = match id {
        "file.new" => "new",
        "file.open" | "file.openAs" => "open",
        "file.save" => "save",
        "file.saveAs" => "save_as",
        "file.saveACopy" => "save_copy",
        "file.close" | "file.closeAll" | "file.closeOthers" => "close",
        "file.revert" => "revert",
        _ => return None,
    };
    if app.hosted.pending_file.is_some() {
        return Some(Err("finish the pending workspace file action first".into()));
    }
    let next = match app.hosted.next_file.checked_add(1) {
        Some(value) => value,
        None => return Some(Err("native file request sequence exhausted".into())),
    };
    app.hosted.next_file = next;
    let state = app.session.active();
    app.hosted.pending_file = Some(
        json!({"id":next,"action":action,"uid":state.map(|_|app.session.active_generation()),"revision":state.map(|state|state.revision),"title":state.map(|state|state.doc.name.clone()),"params":params}),
    );
    Some(Ok(json!({"queued":true,"id":next})))
}

pub(crate) fn poll(app: &mut PhotocraftApp) {
    for pending in std::mem::take(&mut app.hosted.pending) {
        match pending.receiver.try_recv() {
            Err(TryRecvError::Empty) => app.hosted.pending.push(pending),
            Err(TryRecvError::Disconnected) => {
                let _ = pending.reply.send(json!({"ok":false,"error":"native job result was dropped; read current source before retrying"}));
            }
            Ok(reply) => {
                let result = if reply.get("ok").and_then(Value::as_bool) != Some(true) {
                    reply
                } else if app.session.active_generation() != pending.uid {
                    json!({"ok":false,"error":"native source changed while the job ran; it may have applied to the earlier image"})
                } else {
                    match document(app) {
                        Ok(document) => json!({"ok":true,"result":{"value":reply.get("result"),"document":document}}),
                        Err(error) => json!({"ok":false,"error":error}),
                    }
                };
                let _ = pending.reply.send(result);
            }
        }
    }
}

pub(super) fn handle(app: &mut PhotocraftApp, ctx: &egui::Context, request: &ControlRequest) -> Option<Outcome> {
    let p = &request.params;
    Some(match request.method.as_str() {
        "host.protocol" => ok(
            json!({"protocol":1,"nativeContext":2,"contextOrdering":true,"losslessJson":true,"engine":"photocraft","selectionKind":"photocraft","identityKind":"native-active-document-generation","guardedExecute":true,"atomicSnapshot":true,"atomicBundle":true,"saveAcknowledgement":true,"hostPresentation":true,"hostFileRouting":true}),
        ),
        "host.context" => match document(app) {
            Ok(document) => ok(document),
            Err(error) => err(error),
        },
        "host.configure" => {
            let Some(embedded) = p.get("embedded").and_then(Value::as_bool) else {
                return Some(err("embedded must be a boolean"));
            };
            let kind = match p.get("brightness") {
                Some(Value::String(value)) if value == "light" => crate::theme::ThemeKind::ProLight,
                Some(Value::String(value)) if value == "mediumDark" => crate::theme::ThemeKind::ProMedium,
                None => crate::theme::ThemeKind::ProMedium,
                _ => return Some(err("unknown hosted brightness")),
            };
            let routing = match p.get("fileRouting") {
                Some(Value::Bool(value)) => *value && embedded,
                None => embedded,
                _ => return Some(err("fileRouting must be a boolean")),
            };
            if app.hosted.pending_file.is_some() && !routing {
                return Some(err("finish the pending file request first"));
            }
            if embedded && app.hosted.original_theme.is_none() {
                app.hosted.original_theme = Some(app.ui.theme);
            }
            app.hosted.embedded = embedded;
            app.hosted.theme_override = if embedded { Some(kind) } else { None };
            app.hosted.file_routing = routing;
            let applied = if embedded { kind } else { app.hosted.original_theme.take().unwrap_or(app.ui.theme) };
            app.apply_theme(ctx, applied);
            ok(json!({"embedded":embedded,"fileRouting":app.hosted.file_routing}))
        }
        "host.create" => {
            if !app.session.documents().is_empty() {
                return Some(err("host.create requires an empty native App"));
            }
            let valid = |key: &str| p.get(key).and_then(Value::as_f64).filter(|value| value.is_finite() && *value >= 1.0 && *value <= 16384.0);
            let Some((width, height)) = valid("width").zip(valid("height")).filter(|(width, height)| width * height <= 24_000_000.0) else {
                return Some(err("image canvas exceeds the embedded budget"));
            };
            let mut params = p.clone();
            params["width"] = json!(width);
            params["height"] = json!(height);
            let routing = app.hosted.file_routing;
            app.hosted.file_routing = false;
            let result = app.run("file.new", params);
            app.hosted.file_routing = routing;
            match result {
                Ok(value) => {
                    app.ui.chrome.home = None;
                    app.sync_views();
                    if let Some(view) = app.session.active_index().and_then(|index| app.ui.views.get_mut(index)) {
                        view.fit_pending = true;
                    }
                    match document(app) {
                        Ok(document) => ok(json!({"value":value,"document":document})),
                        Err(error) => err(error),
                    }
                }
                Err(error) => err(error),
            }
        }
        "host.execute" => {
            if let Err(error) = base(app, p) {
                return Some(err(error));
            }
            let Some(command) = p.get("command").and_then(Value::as_str).filter(|command| !command.is_empty() && command.len() <= 256) else {
                return Some(err("missing or excessive native command"));
            };
            if command.starts_with("file.") || matches!(command, "document.activate" | "document.move") {
                return Some(err("document lifecycle belongs to the workspace"));
            }
            if app.hosted.pending.len() >= 16 {
                return Some(err("host job wait queue is full"));
            }
            let events = app.session.prefs().script_events.enabled;
            if events {
                app.session.edit_prefs(|prefs| prefs.script_events.enabled = false);
            }
            app.jobs.last_started = None;
            let result = app.run(command, p.get("params").cloned().unwrap_or_else(|| json!({})));
            if events {
                app.session.edit_prefs(|prefs| prefs.script_events.enabled = true);
            }
            match (result, app.jobs.last_started.take()) {
                (Err(error), _) => err(error),
                (Ok(_), Some(job)) => {
                    let (tx, rx) = std::sync::mpsc::channel();
                    app.jobs.waiters.push((job, tx));
                    app.hosted.pending.push(Pending { uid: app.session.active_generation(), receiver: rx, reply: request.reply.clone() });
                    Outcome::HostedPending
                }
                (Ok(value), None) => match document(app) {
                    Ok(document) => ok(json!({"value":value,"document":document})),
                    Err(error) => err(error),
                },
            }
        }
        "host.node" => {
            if let Err(error) = base(app, p) {
                return Some(err(error));
            }
            let Some(id) = p.get("id").and_then(Value::as_u64) else {
                return Some(err("layer id must be uint64"));
            };
            match app.session.active().and_then(|state| state.doc.layer(LayerId(id))) {
                Some(layer) => {
                    let value = photocraft_engine::inspect::layer(layer);
                    if value.to_string().len() > 1024 * 1024 { err("native layer details exceed 1 MiB; inspect a child layer instead") } else { ok(value) }
                }
                None => err("native layer does not exist"),
            }
        }
        "host.snapshot" | "host.bundle" => {
            if request.method == "host.bundle" {
                if let Err(error) = base(app, p) {
                    return Some(err(error));
                }
            }
            let format = p.get("format").and_then(Value::as_str).unwrap_or("pcraft");
            let before = match document(app) {
                Ok(document) => document,
                Err(error) => return Some(err(error)),
            };
            if request.method == "host.bundle" {
                if format != "png" {
                    return Some(err("Photo material derivatives currently use PNG"));
                }
                match encoded(app, "pcraft").and_then(|source| {
                    encoded(app, format).map(|derivative| json!({"document":before,"source":source,"derivative":derivative,"format":format}))
                }) {
                    Ok(value) => ok(value),
                    Err(error) => err(error),
                }
            } else {
                match encoded(app, format) {
                    Ok(encoded) => ok(json!({"document":before,"encoded":encoded,"format":format})),
                    Err(error) => err(error),
                }
            }
        }
        "host.saved" => {
            if pending_interaction(app) {
                return Some(ok(json!({"acknowledged":false,"pendingInteraction":true})));
            }
            let uid = app.session.active_generation();
            let Some(state) = app.session.active_mut() else {
                return Some(err("no native image open"));
            };
            if p.get("uid").and_then(Value::as_u64) != Some(uid)
                || p.get("revision").and_then(Value::as_u64) != Some(state.revision)
                || p.get("nativeDocumentId").is_some_and(|id| id.as_u64() != Some(state.doc.id.0))
            {
                ok(json!({"acknowledged":false,"newerEdits":true}))
            } else if !p.get("checkpoint").and_then(Value::as_str).is_some_and(|value| value.len() == 64 && value.bytes().all(|byte| byte.is_ascii_hexdigit()))
            {
                err("invalid durable checkpoint")
            } else {
                state.saved_revision = state.revision;
                ok(json!({"acknowledged":true}))
            }
        }
        "host.file.pending" => ok(json!({"request":app.hosted.pending_file})),
        "host.file.finish" => {
            let matches = app.hosted.pending_file.as_ref().is_some_and(|file| file.get("id") == p.get("id"));
            if !matches {
                err("native file receipt identity changed")
            } else {
                app.hosted.pending_file = None;
                ok(json!({"completed":true}))
            }
        }
        _ => return None,
    })
}

impl PhotocraftApp {
    pub fn is_hosted(&self) -> bool {
        self.hosted.embedded
    }
    /// Reopen the exact host-provided bytes without interactive profile prompts.
    /// The bounded native readers preserve their original profile/depth and warnings.
    pub fn open_hosted_bytes(&mut self, name: &str, bytes: &[u8]) -> Result<(), String> {
        if !self.hosted.embedded {
            return Err("source-owned open requires hosted mode".into());
        }
        if !self.session.documents().is_empty() {
            return Err("this native App already owns an image; use the workspace import entry".into());
        }
        self.hosted.open_error = None;
        self.hosted.opening = true;
        let result = photocraft_io::embedded_import::import(name, bytes, Default::default()).map_err(|error| error.to_string());
        self.hosted.opening = false;
        let result = match result {
            Ok(result) => result,
            Err(error) => {
                self.hosted.open_error = Some(error.clone());
                self.ui.status = error.clone();
                self.ui.status_error = true;
                return Err(error);
            }
        };
        self.hosted.open_warnings = result.warnings;
        let index = self.session.add_document(result.document, None);
        self.sync_views();
        self.ui.chrome.home = None;
        if let Some(view) = self.ui.views.get_mut(index) {
            view.fit_pending = true;
        }
        Ok(())
    }
}
