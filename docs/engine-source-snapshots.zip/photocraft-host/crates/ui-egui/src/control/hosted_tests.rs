use super::*;
use photocraft_engine::Session;
use serde_json::{Value, json};

fn call(app: &mut PhotocraftApp, method: &str, params: Value) -> Value {
    let (request, _) = ControlRequest::new(method, params);
    match crate::control::handle(app, &egui::Context::default(), &request) {
        Outcome::Done(value) => value,
        _ => panic!("expected immediate native host response"),
    }
}
fn image() -> PhotocraftApp {
    let mut app = PhotocraftApp::new(Session::new(), crate::Services::default());
    app.background_jobs = false;
    let result = call(&mut app, "host.create", json!({"width":32,"height":24,"name":"Actual image","depth":16,"background":"transparent"}));
    assert_eq!(result["ok"], true, "{result}");
    app
}

#[test]
fn hosted_theme_and_language_leave_saved_preferences_and_standalone_palette_intact() {
    let mut app = image();
    let prefs = serde_json::to_value(app.session.prefs()).unwrap();
    let original_language = app.effective_ui_language().to_string();
    let original_theme = app.ui.theme;
    let ctx = egui::Context::default();
    let request = |embedded| ControlRequest::new("host.configure", json!({"embedded":embedded,"brightness":"light"})).0;
    assert!(matches!(crate::control::handle(&mut app, &ctx, &request(true)), Outcome::Done(_)));
    assert_eq!(app.effective_ui_language(), "zh-hans");
    assert_eq!(crate::theme::Tokens::get(&ctx).accent, egui::Color32::from_rgb(0x28, 0x7D, 0x6C));
    assert_eq!(serde_json::to_value(app.session.prefs()).unwrap(), prefs);
    assert!(matches!(crate::control::handle(&mut app, &ctx, &request(false)), Outcome::Done(_)));
    assert_eq!(app.effective_ui_language(), original_language);
    assert_eq!(crate::theme::Tokens::get(&ctx).accent, crate::theme::Tokens::for_kind(original_theme).accent);
    assert_eq!(serde_json::to_value(app.session.prefs()).unwrap(), prefs);
}

#[test]
fn an_uncommitted_native_crop_blocks_host_mutation_and_checkpoint_ack() {
    let mut app = image();
    let before = call(&mut app, "host.context", json!({}))["result"].clone();
    app.ui.crop_rect = Some([2.0, 3.0, 20.0, 18.0]);
    let pending = call(&mut app, "host.context", json!({}))["result"].clone();
    assert_eq!(pending["pendingInteraction"], true, "an uncommitted crop must retain manual ownership");
    assert_eq!(call(&mut app, "host.execute", json!({"base":before,"command":"layer.setProps","params":{"opacity":0.2}}))["ok"], false);
    assert_eq!(call(&mut app, "host.snapshot", json!({"format":"pcraft"}))["ok"], false);
    assert_eq!(call(&mut app, "host.saved", json!({"uid":before["uid"],"revision":before["revision"],"checkpoint":"a".repeat(64)}))["result"]["acknowledged"], false);
    assert_eq!(app.session.active().unwrap().doc.layers[0].opacity, 1.0);
    app.ui.crop_rect = None;
    assert_eq!(call(&mut app, "host.context", json!({}))["result"]["pendingInteraction"], false);
    app.ui.crop_rect = Some([0.0, 0.0, 32.0, 24.0]);
    app.crop.default_frame = true;
    assert_eq!(call(&mut app, "host.context", json!({}))["result"]["pendingInteraction"], false, "an untouched default frame is not a pending edit");
    app.ui.crop_rect = None;
    app.crop.default_frame = false;
    app.ui.perspective_crop = Some([[0.0, 0.0], [16.0, 0.0], [16.0, 16.0], [0.0, 16.0]]);
    assert_eq!(call(&mut app, "host.context", json!({}))["result"]["pendingInteraction"], true);
    app.ui.perspective_crop = None;
    app.run("edit.fill", json!({"color":"#336699"})).unwrap();
    crate::transform_tool::begin(&mut app, &egui::Context::default()).unwrap();
    assert!(app.ui.transform.is_some());
    assert_eq!(call(&mut app, "host.context", json!({}))["result"]["pendingInteraction"], true);
}
fn bytes(encoded: &Value) -> Vec<u8> {
    base64::engine::general_purpose::STANDARD.decode(encoded["dataBase64"].as_str().unwrap()).unwrap()
}

#[test]
fn native_source_and_png_are_real_encodings_of_the_current_image_and_depth_is_retained() {
    let mut app = image();
    let snapshot = call(&mut app, "host.snapshot", json!({"format":"pcraft"}));
    assert_eq!(snapshot["ok"], true, "{snapshot}");
    let original = bytes(&snapshot["result"]["encoded"]);
    let source = photocraft_format::load_from_bytes(&original).unwrap();
    assert_eq!(source.size.width, 32);
    assert_eq!(source.depth, photocraft_color::SampleType::U16);
    assert_eq!(source.name, app.session.active().unwrap().doc.name, "source snapshots must not append a file extension to the native document name");
    assert_eq!(snapshot["result"]["document"]["uid"].as_u64(), Some(app.session.active_generation()));
    let base = call(&mut app, "host.context", json!({}))["result"].clone();
    let bundle = call(&mut app, "host.bundle", json!({"base":base,"format":"png"}));
    assert_eq!(bundle["ok"], true, "{bundle}");
    assert_eq!(bytes(&bundle["result"]["source"]), original, "same native source must have stable bytes for a paired checkpoint");
    let png = photocraft_codecs::decode(&bytes(&bundle["result"]["derivative"])).unwrap();
    assert_eq!((png.width(), png.height()), (32, 24));
}

#[test]
fn native_layer_and_brush_target_changes_refuse_a_stale_base_without_overwriting_image_content() {
    let mut app = image();
    let first = app.session.active().unwrap().active_layer.unwrap().0;
    app.run("layer.new.layer", json!({"name":"Second"})).unwrap();
    let before = call(&mut app, "host.context", json!({}))["result"].clone();
    let original = bytes(&call(&mut app, "host.snapshot", json!({"format":"pcraft"}))["result"]["encoded"]);
    app.run("layer.select", json!({"layer":first})).unwrap();
    assert_eq!(call(&mut app, "host.execute", json!({"base":before,"command":"layer.setProps","params":{"opacity":0.5}}))["ok"], false);
    let base = call(&mut app, "host.context", json!({}))["result"].clone();
    let brush = app.session.tools.brush_rev;
    app.run("tools.setBrush", json!({"size":9})).unwrap();
    assert!(app.session.tools.brush_rev > brush);
    assert_eq!(call(&mut app, "host.execute", json!({"base":base,"command":"edit.fill","params":{"color":"#ff0000"}}))["ok"], false);
    assert_eq!(bytes(&call(&mut app, "host.snapshot", json!({"format":"pcraft"}))["result"]["encoded"]), original);
}

#[test]
fn hosted_menus_queue_file_intents_and_only_a_matching_durable_ack_clears_dirty() {
    let mut app = image();
    app.run("edit.fill", json!({"color":"#336699"})).unwrap();
    assert!(app.session.active().unwrap().is_dirty());
    assert_eq!(call(&mut app, "host.configure", json!({"embedded":true,"fileRouting":true}))["ok"], true);
    let ctx = egui::Context::default();
    let result = crate::menus::invoke(&mut app, &ctx, "file.save", json!({})).unwrap();
    assert_eq!(result["queued"], true);
    assert!(app.session.active().unwrap().is_dirty());
    let request = call(&mut app, "host.file.pending", json!({}))["result"]["request"].clone();
    let doc = call(&mut app, "host.context", json!({}))["result"].clone();
    let revision = doc["revision"].as_u64().unwrap();
    assert_eq!(call(&mut app, "host.saved", json!({"uid":doc["uid"],"revision":revision-1,"checkpoint":"a".repeat(64)}))["result"]["acknowledged"], false);
    assert!(app.session.active().unwrap().is_dirty());
    assert_eq!(call(&mut app, "host.file.finish", json!({"id":0,"ok":true}))["ok"], false);
    assert_eq!(
        call(&mut app, "host.saved", json!({"uid":doc["uid"],"revision":revision,"nativeDocumentId":u64::MAX,"checkpoint":"a".repeat(64)}))["result"]["acknowledged"],
        false
    );
    assert_eq!(call(&mut app, "host.saved", json!({"uid":doc["uid"],"revision":revision,"checkpoint":"a".repeat(64)}))["result"]["acknowledged"], true);
    assert!(!app.session.active().unwrap().is_dirty());
    assert_eq!(call(&mut app, "host.file.finish", json!({"id":request["id"],"ok":true}))["ok"], true);
    let size = json!({"width":17,"height":19,"name":"Requested image","depth":16});
    crate::menus::invoke(&mut app, &ctx, "file.new", size.clone()).unwrap();
    let queued = call(&mut app, "host.file.pending", json!({}))["result"]["request"].clone();
    assert_eq!(queued["params"], size);
    assert_eq!(app.session.documents().len(), 1, "the hosted request must not create a second native image");
}

#[test]
fn exact_native_document_id_revision_and_layer_id_remain_u64() {
    let mut app = image();
    let state = app.session.active_mut().unwrap();
    let doc = std::sync::Arc::make_mut(&mut state.doc);
    doc.id = photocraft_doc::DocId(u64::MAX - 1);
    let layer = doc.layers.first_mut().unwrap();
    layer.id = LayerId(9007199254740993);
    state.active_layer = Some(layer.id);
    state.selected_layers = vec![layer.id];
    state.revision = 9007199254740995;
    let context = call(&mut app, "host.context", json!({}));
    assert_eq!(context["ok"], true, "{context}");
    let doc = &context["result"];
    assert_eq!(doc["nativeDocumentId"].as_u64(), Some(u64::MAX - 1));
    assert_eq!(doc["revision"].as_u64(), Some(9007199254740995));
    assert_eq!(doc["nativeSelection"]["data"]["selectedLayers"][0].as_u64(), Some(9007199254740993));
    assert_eq!(doc["identityKind"], "native-active-document-generation");
}

#[test]
fn invalid_configurations_and_excessive_images_never_mutate_preferences_or_open_a_document() {
    let mut app = PhotocraftApp::new(Session::new(), crate::Services::default());
    let prefs = serde_json::to_value(app.session.prefs()).unwrap();
    for params in [json!({"embedded":true,"brightness":4}), json!({"embedded":true,"fileRouting":"yes"})] {
        assert_eq!(call(&mut app, "host.configure", params)["ok"], false);
        assert!(!app.hosted.embedded);
    }
    assert_eq!(call(&mut app, "host.create", json!({"width":16000,"height":16000}))["ok"], false);
    assert!(app.session.documents().is_empty());
    assert_eq!(call(&mut app, "host.configure", json!({"embedded":true,"brightness":"light"}))["ok"], true);
    crate::prefs_ui::tick(&mut app, &egui::Context::default());
    assert_eq!(app.ui.theme, crate::theme::ThemeKind::ProLight, "appearance synchronization must retain the actual embedding theme");
    assert_eq!(serde_json::to_value(app.session.prefs()).unwrap(), prefs);
}

#[test]
fn a_real_feathered_selection_is_a_source_backed_coverage_reference_and_roundtrips_exactly() {
    let mut app = image();
    app.run("select.rect", json!({"x":3,"y":4,"width":10,"height":8,"feather":1.5})).unwrap();
    let original = app.session.active().unwrap().doc.selection.clone().unwrap();
    let context = call(&mut app, "host.context", json!({}))["result"].clone();
    assert!(context.get("selection").is_none(), "a raster mask must not be disguised as a vector object list");
    assert_eq!(context["nativeSelection"]["data"]["rasterSelection"]["nativeRole"], "document.selection");
    let data = bytes(&call(&mut app, "host.snapshot", json!({"format":"pcraft"}))["result"]["encoded"]);
    let reopened = photocraft_format::load_from_bytes(&data).unwrap();
    assert_eq!(reopened.selection.as_ref(), Some(&original));
    app.run("select.rect", json!({"x":4,"y":4,"width":10,"height":8,"feather":1.5})).unwrap();
    assert_eq!(call(&mut app, "host.execute", json!({"base":context,"command":"layer.setProps","params":{"opacity":0.4}}))["ok"], false);
}

#[test]
fn a_real_background_filter_reply_waits_for_the_native_job_application() {
    let mut app = image();
    app.run("select.rect", json!({"x":8,"y":8,"width":8,"height":8})).unwrap();
    app.run("edit.fill", json!({"color":"#336699"})).unwrap();
    app.run("select.deselect", json!({})).unwrap();
    app.background_jobs = true;
    let before = call(&mut app, "host.context", json!({}))["result"].clone();
    let revision = before["revision"].as_u64().unwrap();
    let (request, receiver) = ControlRequest::new("host.execute", json!({"base":before,"command":"filter.blur.gaussianBlur","params":{"radius":2}}));
    assert!(matches!(crate::control::handle(&mut app, &egui::Context::default(), &request), Outcome::HostedPending));
    assert!(matches!(receiver.try_recv(), Err(TryRecvError::Empty)), "acceptance must not be the completion reply");
    let start = std::time::Instant::now();
    let reply = loop {
        crate::jobs_ui::tick(&mut app, &egui::Context::default());
        poll(&mut app);
        if let Ok(reply) = receiver.try_recv() {
            break reply;
        }
        assert!(start.elapsed() < std::time::Duration::from_secs(20));
        std::thread::sleep(std::time::Duration::from_millis(1));
    };
    assert_eq!(reply["ok"], true, "{reply}");
    assert!(reply["result"]["document"]["revision"].as_u64().unwrap() > revision);
    assert_eq!(reply["result"]["document"]["revision"].as_u64(), Some(app.session.active().unwrap().revision));
}
