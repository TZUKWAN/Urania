//! Native import for a memory-bounded embedding. Ordinary standalone import keeps its defaults.
use crate::{ImportResult, IoError};

#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub encoded_bytes: usize,
    pub decoded_bytes: u64,
    pub canvas_side: u32,
    pub canvas_pixels: u64,
}

impl Default for Limits {
    fn default() -> Self {
        Self { encoded_bytes: 256 << 20, decoded_bytes: 512 << 20, canvas_side: 16384, canvas_pixels: 24_000_000 }
    }
}

/// Read real `.pcraft`, PNG or JPEG without allocating against the standalone app's GiB budgets.
/// Other formats need their own bounded readers before an embedding may advertise them.
pub fn import(name: &str, bytes: &[u8], limits: Limits) -> Result<ImportResult, IoError> {
    if bytes.is_empty() || bytes.len() > limits.encoded_bytes || limits.decoded_bytes == 0 || limits.canvas_side == 0 || limits.canvas_pixels == 0 {
        return Err(IoError::Unsupported("embedded image input is empty or exceeds its budget".into()));
    }
    if name.to_ascii_lowercase().ends_with(".pcraft") || photocraft_format::is_pcraft(bytes) {
        let options = photocraft_format::LoadOptions {
            max_manifest_bytes: 8 << 20,
            max_blob_bytes: usize::try_from(limits.decoded_bytes.min(128 << 20)).unwrap_or(usize::MAX),
            max_total_bytes: limits.decoded_bytes,
            max_canvas_side: limits.canvas_side,
            max_canvas_pixels: limits.canvas_pixels,
            ..Default::default()
        };
        let document = photocraft_format::load_from_bytes_with(bytes, &options)?;
        let warnings = crate::open_warnings(&document);
        return Ok(ImportResult { document, warnings, source_read_only: false, preview_only: false });
    }
    if !matches!(photocraft_codecs::detect(bytes), Some(photocraft_codecs::Format::Png | photocraft_codecs::Format::Jpeg)) {
        return Err(IoError::Unsupported("the embedded editor currently admits pcraft, PNG and JPEG; other bounded readers are not connected".into()));
    }
    crate::flat::import_flat_bounded(
        name,
        bytes,
        photocraft_codecs::Limits {
            max_width: limits.canvas_side,
            max_height: limits.canvas_side,
            max_pixels: limits.canvas_pixels,
            max_alloc: limits.decoded_bytes,
        },
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use photocraft_codecs::{ChannelLayout, EncodeOptions, Format, Image};
    use photocraft_color::{ColorMode, SampleType};
    use photocraft_doc::Document;
    use photocraft_geom::Size;

    #[test]
    fn actual_sixteen_bit_png_preserves_native_depth_and_uses_the_real_importer() {
        let image = Image::from_u16(2, 1, ChannelLayout::Rgba, &[65535, 1000, 2000, 65535, 3000, 4000, 5000, 32768]).unwrap();
        let png = photocraft_codecs::encode(&image, Format::Png, &EncodeOptions::default()).unwrap();
        let result = import("sixteen.png", &png, Limits::default()).unwrap();
        assert_eq!(result.document.depth, SampleType::U16);
        assert_eq!(result.document.size, Size::new(2, 1));
        assert_eq!(result.document.layers.len(), 1);
        assert!(result.document.layers.first().unwrap().surface().is_some());
    }

    #[test]
    fn actual_native_bundle_reopens_and_a_sparse_oversized_canvas_is_refused_before_publication() {
        let document = Document::new("native", Size::new(64, 48), ColorMode::Rgb, SampleType::U16);
        let bytes = photocraft_format::save_to_bytes(&document, &Default::default()).unwrap();
        let reopened = import("native.pcraft", &bytes, Limits::default()).unwrap();
        assert_eq!(reopened.document.id, document.id);
        assert_eq!(reopened.document.depth, SampleType::U16);
        assert_eq!(reopened.document.size, document.size);
        assert!(import("native.pcraft", &bytes, Limits { canvas_pixels: 100, ..Default::default() }).is_err());
    }

    #[test]
    fn real_encoded_pixels_and_malformed_or_unsupported_inputs_fail_closed() {
        let image = Image::from_u8(32, 32, ChannelLayout::Rgba, vec![255; 32 * 32 * 4]).unwrap();
        let png = photocraft_codecs::encode(&image, Format::Png, &EncodeOptions::default()).unwrap();
        assert!(import("oversized.png", &png, Limits { canvas_pixels: 100, ..Default::default() }).is_err());
        assert!(import("oversized.png", &png, Limits { encoded_bytes: 1, ..Default::default() }).is_err());
        assert!(import("bad.pcraft", b"not a bundle", Limits::default()).is_err());
        assert!(import("bad.png", b"not an image", Limits::default()).is_err());
        assert!(import("empty.png", &[], Limits::default()).is_err());
    }
}
