use super::*;
use deckcraft_engine::Session;
use std::sync::Arc;

fn call(app: &mut SlideApp, method: &str, params: Value) -> Value {
    let (request, _) = ControlRequest::new(method, params);
    match crate::control::handle(app, &egui::Context::default(), &request) {
        Outcome::Done(value) => value,
        _ => panic!("expected immediate host response"),
    }
}
fn app() -> SlideApp {
    let mut app = SlideApp::new(Session::new(), crate::Services::default());
    assert_eq!(call(&mut app, "host.configure", json!({"embedded":true,"fileRouting":true,"brightness":"light"}))["ok"], true);
    assert_eq!(call(&mut app, "host.create", json!({"name":"Native Deck QA","width":320,"height":180}))["ok"], true);
    app.run("shape.insert", json!({"preset":"rect","rect":[20,30,120,50]})).unwrap();
    app
}
fn bytes(value: &Value) -> Vec<u8> {
    deckcraft_engine::cmd::base64_decode(value["dataBase64"].as_str().unwrap()).unwrap()
}
fn context(app: &mut SlideApp) -> Value {
    call(app, "host.context", json!({}))["result"].clone()
}

#[test]
fn hosted_media_buttons_reach_the_bounded_async_picker() {
    let mut app = app();
    let seen = Arc::new(std::sync::Mutex::new(Vec::<String>::new()));
    let observed = seen.clone();
    app.services.open_async = Some(Box::new(move |purpose, _| observed.lock().unwrap().push(purpose.to_string())));
    let revision = app.session.active().unwrap().revision;
    app.run("app.insertAudioDialog", json!({})).unwrap();
    app.run("app.insertVideoDialog", json!({})).unwrap();
    assert_eq!(*seen.lock().unwrap(), vec!["audio", "video"]);
    assert_eq!(app.session.active().unwrap().revision, revision, "opening the picker alone must not edit the source");
}

#[test]
fn hosted_single_view_starts_with_audience_and_preserves_explicit_presenter_choice() {
    let mut app = app();
    assert!(!app.ui.presenter_view);
    app.run("show.presenter", json!({"on":true})).unwrap();
    assert!(app.ui.presenter_view);
    assert_eq!(call(&mut app, "host.configure", json!({"embedded":true,"fileRouting":true,"brightness":"light"}))["ok"], true);
    assert!(app.ui.presenter_view, "theme synchronization must not reset an explicit choice");
    assert_eq!(call(&mut app, "host.configure", json!({"embedded":false,"fileRouting":false,"brightness":"light"}))["ok"], true);
    assert!(app.ui.presenter_view, "standalone setting is restored");
    let mut other = SlideApp::new(Session::new(), crate::Services::default());
    other.ui.presenter_view = false;
    assert_eq!(call(&mut other, "host.configure", json!({"embedded":true,"fileRouting":true}))["ok"], true);
    other.run("show.presenter", json!({"on":true})).unwrap();
    assert_eq!(call(&mut other, "host.configure", json!({"embedded":false,"fileRouting":false}))["ok"], true);
    assert!(!other.ui.presenter_view, "the original standalone choice is restored, not the embedded override");
}

#[test]
fn actual_native_pptx_and_png_come_from_the_same_current_deck() {
    let mut app = app();
    let before = context(&mut app);
    assert_eq!(before["width"], 320.0);
    assert_eq!(before["height"], 180.0);
    let source = call(&mut app, "host.snapshot", json!({"format":"deckcraft"}));
    assert_eq!(source["ok"], true, "{source}");
    let raw = bytes(&source["result"]["encoded"]);
    assert!(raw.starts_with(b"PK"));
    let loaded = deckcraft_engine::embedded::import("actual.deckcraft", &raw, Default::default()).unwrap();
    assert_eq!(serde_json::to_value(&loaded.presentation).unwrap(), serde_json::to_value(&app.session.active().unwrap().doc).unwrap());
    let bundle = call(&mut app, "host.bundle", json!({"base":before,"format":"png"}));
    assert_eq!(bundle["ok"], true, "{bundle}");
    assert_eq!(bytes(&bundle["result"]["source"]), raw);
    let png = bytes(&bundle["result"]["derivative"]);
    assert!(png.starts_with(b"\x89PNG\r\n\x1a\n"));
    assert_eq!(u32::from_be_bytes(png[16..20].try_into().unwrap()), 320);
    assert_eq!(u32::from_be_bytes(png[20..24].try_into().unwrap()), 180);
    let pptx = call(&mut app, "host.snapshot", json!({"format":"pptx"}));
    assert_eq!(pptx["ok"], true, "{pptx}");
    assert!(deckcraft_engine::embedded::import("actual.pptx", &bytes(&pptx["result"]["encoded"]), Default::default()).is_ok());
}

#[test]
fn switching_native_page_target_without_revision_refuses_old_commands() {
    let mut app = app();
    let before = context(&mut app);
    let revision = before["revision"].clone();
    let original = deckcraft_engine::cmd::file::save_bytes(&app.session.active().unwrap().doc, "deckcraft").unwrap();
    app.session.active_mut().unwrap().selection.target = Target::Layout { master: 0, layout: 0 };
    let current = context(&mut app);
    assert_eq!(current["revision"], revision);
    assert_ne!(current["selectionStamp"], before["selectionStamp"]);
    let reply = call(&mut app, "host.execute", json!({"base":before,"command":"shape.insert","params":{"preset":"rect","rect":[1,2,3,4]}}));
    assert_eq!(reply["ok"], false);
    assert_eq!(deckcraft_engine::cmd::file::save_bytes(&app.session.active().unwrap().doc, "deckcraft").unwrap(), original);
    assert_eq!(current["page"]["nativePage"]["kind"], "layout");
}

#[test]
fn actual_notes_draft_owns_the_source_until_the_native_editor_settles_it() {
    let mut app = app();
    let before = context(&mut app);
    let uid = app.session.active().unwrap().uid;
    app.notes_buf = (uid, 0, crate::notes::Draft { text: "unsaved native notes".into(), body: Default::default(), edited: true });
    assert_eq!(context(&mut app)["pendingInteraction"], true);
    assert_eq!(call(&mut app, "host.execute", json!({"base":before,"command":"shape.fill","params":{"color":"#225588"}}))["ok"], false);
    assert_eq!(call(&mut app, "host.snapshot", json!({"format":"deckcraft"}))["ok"], false);
    assert_eq!(
        call(&mut app, "host.saved", json!({"uid":uid,"revision":before["revision"],"checkpoint":"a".repeat(64)}))["result"]["acknowledged"],
        false
    );
    app.notes_buf.2.edited = false;
    assert_eq!(context(&mut app)["pendingInteraction"], false);
}

#[test]
fn hosted_shortcut_save_requests_the_workspace_checkpoint() {
    let mut app = app();
    assert!(app.session.active().unwrap().is_dirty());
    app.save();
    let pending = call(&mut app, "host.file.pending", json!({}))["result"]["request"].clone();
    assert_eq!(pending["action"], "save");
    assert!(app.session.active().unwrap().is_dirty(), "only a durable acknowledgement may clear dirty state");
}

#[test]
fn native_file_intents_keep_real_params_and_only_durable_ack_marks_clean() {
    let mut app = app();
    assert!(app.session.active().unwrap().is_dirty());
    app.run("file.new", json!({"name":"Actual queued name","template":"Native template argument"})).unwrap();
    assert_eq!(app.session.documents().len(), 1);
    let pending = call(&mut app, "host.file.pending", json!({}))["result"]["request"].clone();
    assert_eq!(pending["action"], "new");
    assert_eq!(pending["params"]["template"], "Native template argument");
    assert_eq!(call(&mut app, "host.file.finish", json!({"id":999}))["ok"], false);
    assert_eq!(call(&mut app, "host.file.finish", json!({"id":pending["id"]}))["ok"], true);
    let current = context(&mut app);
    assert_eq!(call(&mut app, "host.saved", json!({"uid":current["uid"],"revision":current["revision"],"checkpoint":"not-durable"}))["ok"], false);
    assert!(app.session.active().unwrap().is_dirty());
    assert_eq!(
        call(&mut app, "host.saved", json!({"uid":current["uid"],"revision":current["revision"],"checkpoint":"a".repeat(64)}))["result"]["acknowledged"],
        true
    );
    assert!(!app.session.active().unwrap().is_dirty());
}

#[test]
fn wide_native_groups_have_bounded_summaries_without_truncating_source() {
    let mut app = app();
    let doc = app.session.active_mut().unwrap();
    let p = Arc::make_mut(&mut doc.doc);
    let mut groups = Vec::new();
    for _ in 0..30 {
        let id = deckcraft_model::ShapeId(p.alloc_id().unwrap());
        let mut children = Vec::new();
        for _ in 0..50 {
            children.push(Shape { id: deckcraft_model::ShapeId(p.alloc_id().unwrap()), ..Default::default() });
        }
        groups.push(Shape { id, kind: ShapeKind::Group { children, child: Default::default() }, ..Default::default() });
    }
    Arc::make_mut(p.slides.first_mut().unwrap()).shapes = groups;
    let current = context(&mut app);
    assert_eq!(current["summaryLimited"], true);
    fn count(items: &Value) -> usize {
        items.as_array().unwrap().iter().map(|item| 1 + item.get("children").map(count).unwrap_or(0)).sum()
    }
    assert!(count(&current["layers"]) <= 200);
    assert_eq!(app.session.active().unwrap().current_slide().unwrap().shapes.len(), 30);
}

#[test]
fn real_source_reopen_and_malformed_open_never_adopt_a_second_or_partial_document() {
    let app = app();
    let source = deckcraft_engine::cmd::file::save_bytes(&app.session.active().unwrap().doc, "deckcraft").unwrap();
    let mut fresh = SlideApp::new(Session::new(), crate::Services::default());
    call(&mut fresh, "host.configure", json!({"embedded":true,"fileRouting":true,"brightness":"light"}));
    assert!(fresh.open_hosted_bytes("damaged.deckcraft", b"PK").is_err());
    assert!(fresh.session.documents().is_empty());
    assert!(fresh.hosted.open_error.is_some());
    fresh.open_hosted_bytes("原生演示.deckcraft", &source).unwrap();
    assert_eq!(fresh.session.documents().len(), 1);
    assert_eq!(context(&mut fresh)["title"], "原生演示");
    assert!(fresh.open_hosted_bytes("second.deckcraft", &source).is_err());
    assert_eq!(fresh.session.documents().len(), 1);
}

#[test]
fn native_uid_stays_u64_and_shape_lookup_refuses_ids_outside_native_u32() {
    let mut app = app();
    app.session.active_mut().unwrap().uid = 9_007_199_254_740_993;
    let current = context(&mut app);
    assert_eq!(current["uid"].as_u64(), Some(9_007_199_254_740_993));
    assert!(serde_json::to_string(&current).unwrap().contains("9007199254740993"));
    assert_eq!(call(&mut app, "host.node", json!({"base":current,"id":4_294_967_296u64}))["ok"], false);
}
