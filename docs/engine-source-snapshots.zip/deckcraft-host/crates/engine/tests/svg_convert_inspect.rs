#![allow(clippy::unwrap_used, clippy::panic, clippy::expect_used)]
//! Actual contributor-original Vector SVG exports and their rendered previews.
use deckcraft_engine::Session;
use serde_json::{Value, json};
const SIMPLE: &[u8] = include_bytes!("fixtures/dsh-svg-conversion/source.svg");
const SIMPLE_PREVIEW: &[u8] = include_bytes!("fixtures/dsh-svg-conversion/preview.png");
const TEXT: &[u8] = include_bytes!("fixtures/dsh-svg-conversion/text.svg");
const TEXT_PREVIEW: &[u8] = include_bytes!("fixtures/dsh-svg-conversion/text-preview.png");
const COMPLEX: &[u8] = include_bytes!("fixtures/host-svg/source.svg");
const COMPLEX_PREVIEW: &[u8] = include_bytes!("fixtures/host-svg/preview.png");
fn insert(s: &mut Session, svg: &[u8], preview: &[u8]) -> u64 {
    let p = json!({"name":"actual.svg","data":deckcraft_engine::cmd::base64_encode(svg),"previewData":deckcraft_engine::cmd::base64_encode(preview)});
    s.execute("insert.svgPicture", &p).unwrap()["id"].as_u64().unwrap()
}
fn inspect(s: &mut Session, id: u64) -> Value {
    s.execute("picture.inspectSvgConversion", &json!({"ids":[id]})).unwrap()
}

#[test]
fn actual_simple_svg_reports_three_shapes_without_changing_the_deck() {
    let mut s = Session::new();
    s.execute("file.new", &json!({})).unwrap();
    let id = insert(&mut s, SIMPLE, SIMPLE_PREVIEW);
    let before = s.doc().unwrap().doc.clone();
    let history = s.doc().unwrap().history.undo.len();
    let result = inspect(&mut s, id);
    assert_eq!(result["analysisOnly"], true);
    assert_eq!(result["conversionAvailable"], true);
    assert_eq!(result["basicGeometryRecognized"], true);
    assert_eq!(result["objects"], 3);
    assert_eq!(result["paths"], 3);
    assert_eq!(result["texts"], 0);
    assert_eq!(*s.doc().unwrap().doc, *before);
    assert_eq!(s.doc().unwrap().history.undo.len(), history);
}

#[test]
fn actual_gradient_and_clip_svg_are_reported_without_changing_the_deck() {
    let mut s = Session::new();
    s.execute("file.new", &json!({})).unwrap();
    let id = insert(&mut s, COMPLEX, COMPLEX_PREVIEW);
    let before = s.doc().unwrap().doc.clone();
    let history = s.doc().unwrap().history.undo.len();
    let result = inspect(&mut s, id);
    assert_eq!(result["basicGeometryRecognized"], false);
    assert_eq!(result["conversionAvailable"], false);
    assert_eq!(result["originalRetained"], true);
    assert!(result["reason"].as_str().unwrap().contains("unsupported"));
    assert_eq!(*s.doc().unwrap().doc, *before);
    assert_eq!(s.doc().unwrap().history.undo.len(), history);
}

#[test]
fn actual_vector_exported_text_reports_baseline_and_font_risk_without_modifying_deck() {
    let mut s = Session::new();
    s.execute("file.new", &json!({})).unwrap();
    let id = insert(&mut s, TEXT, TEXT_PREVIEW);
    let before = s.doc().unwrap().doc.clone();
    let history = s.doc().unwrap().history.undo.len();
    let result = inspect(&mut s, id);
    assert_eq!(result["basicGeometryRecognized"], true);
    assert_eq!(result["conversionAvailable"], true);
    assert_eq!(result["texts"], 1);
    assert_eq!(result["items"][0]["x"], 30.0);
    assert_eq!(result["items"][0]["y"], 90.0);
    assert_eq!(result["items"][0]["characters"], 13);
    assert!(!result["warnings"].as_array().unwrap().is_empty());
    assert_eq!(*s.doc().unwrap().doc, *before);
    assert_eq!(s.doc().unwrap().history.undo.len(), history);
}
