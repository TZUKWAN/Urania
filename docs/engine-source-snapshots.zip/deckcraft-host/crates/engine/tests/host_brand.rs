#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]
use deckcraft_engine::Session;
use deckcraft_model::{Shape, ShapeId};
use serde_json::{Value, json};

fn shape(session: &Session, id: u64) -> &Shape {
    session.doc().unwrap().doc.slides.iter().find_map(|slide| deckcraft_model::find_shape(&slide.shapes, ShapeId(id as u32))).unwrap()
}
fn origin(session: &Session, id: u64) -> Value {
    serde_json::from_str(&shape(session, id).tags.iter().find(|(key, _)| key.eq_ignore_ascii_case("DSH-BRAND-COLOR-V1")).unwrap().1).unwrap()
}
fn fixture() -> (Session, u64) {
    let mut s = Session::new();
    s.execute("file.new", &json!({})).unwrap();
    let id = s.execute("shape.insert", &json!({"preset":"rect","rect":[100,120,300,200]})).unwrap()["id"].as_u64().unwrap();
    s.execute("shape.fill", &json!({"ids":[id],"color":"#287D6C"})).unwrap();
    (s, id)
}
fn row(id: u64) -> Value {
    json!({"id":id,"projectId":"project-fixture","bindingId":"brandcolor-00000000-0000-4000-8000-000000000001"})
}

#[test]
fn assignment_preserves_appearance_is_idempotent_and_survives_undo_reopen_pptx() {
    let (mut s, id) = fixture();
    let before = s.doc().unwrap().doc.clone();
    let history = s.doc().unwrap().history.undo.len();
    let result = s.execute("shape.assignBrandOrigins", &json!({"origins":[row(id)]})).unwrap();
    let marker = origin(&s, id);
    assert_eq!(marker["projectId"], "project-fixture");
    assert_eq!(marker["bindingId"], "brandcolor-00000000-0000-4000-8000-000000000001");
    assert_eq!(result["origins"][0]["instanceId"], marker["instanceId"]);
    if let Some(directory) = std::env::var_os("DSH_BRAND_NATIVE_CAPTURE") {
        let directory = std::path::PathBuf::from(directory);
        std::fs::create_dir_all(&directory).unwrap();
        std::fs::write(directory.join("brand-deck-marker-before.deckcraft"), deckcraft_format::save(&before).unwrap()).unwrap();
        std::fs::write(directory.join("brand-deck-marker-after.deckcraft"), deckcraft_format::save(&s.doc().unwrap().doc).unwrap()).unwrap();
        std::fs::write(directory.join("brand-deck-marker.json"), serde_json::to_vec_pretty(&json!({"nativeId":id,"marker":marker})).unwrap())
            .unwrap();
    }
    assert_eq!(s.doc().unwrap().history.undo.len(), history + 1);
    let previous = before.slides.iter().find_map(|sl| deckcraft_model::find_shape(&sl.shapes, ShapeId(id as u32))).unwrap();
    let mut after = shape(&s, id).clone();
    after.tags.retain(|(key, _)| !key.eq_ignore_ascii_case("DSH-BRAND-COLOR-V1"));
    assert_eq!(&after, previous);
    let undo = s.doc().unwrap().history.undo.len();
    assert_eq!(s.execute("shape.assignBrandOrigins", &json!({"origins":[row(id)]})).unwrap()["unchanged"], true);
    assert_eq!(s.doc().unwrap().history.undo.len(), undo);
    s.execute("edit.undo", &json!({})).unwrap();
    assert_eq!(*s.doc().unwrap().doc, *before);
    s.execute("edit.redo", &json!({})).unwrap();
    assert_eq!(origin(&s, id), marker);
    let native = deckcraft_format::save(&s.doc().unwrap().doc).unwrap();
    assert_eq!(*s.doc().unwrap().doc, deckcraft_format::load(&native).unwrap());
    let pptx = deckcraft_pptx::export(&s.doc().unwrap().doc).unwrap();
    let (loaded, warnings) = deckcraft_pptx::import_checked(&pptx).unwrap();
    assert!(warnings.is_empty(), "{warnings:?}");
    assert!(loaded.slides.iter().flat_map(|slide| slide.shapes.iter()).any(|shape| {
        shape
            .tags
            .iter()
            .any(|(key, value)| key.eq_ignore_ascii_case("DSH-BRAND-COLOR-V1") && serde_json::from_str::<Value>(value).unwrap() == marker)
    }));
}

#[test]
fn invalid_or_conflicting_batches_do_not_change_native_document() {
    let (mut s, id) = fixture();
    let before = s.doc().unwrap().doc.clone();
    let history = s.doc().unwrap().history.undo.len();
    assert!(s.execute("shape.assignBrandOrigins", &json!({"origins":[row(id),row(4_294_967_295)]})).is_err());
    assert_eq!(*s.doc().unwrap().doc, *before);
    assert_eq!(s.doc().unwrap().history.undo.len(), history);
    s.execute("shape.assignBrandOrigins", &json!({"origins":[row(id)]})).unwrap();
    let marked = s.doc().unwrap().doc.clone();
    let mut conflict = row(id);
    conflict["bindingId"] = json!("brandcolor-00000000-0000-4000-8000-000000000002");
    assert!(s.execute("shape.assignBrandOrigins", &json!({"origins":[conflict]})).is_err());
    assert_eq!(*s.doc().unwrap().doc, *marked);
}

#[test]
fn duplicate_and_internal_clipboard_do_not_inherit_a_brand_binding() {
    let (mut s, id) = fixture();
    s.execute("shape.assignBrandOrigins", &json!({"origins":[row(id)]})).unwrap();
    let marker = origin(&s, id);
    let copy = s.execute("edit.duplicate", &json!({"ids":[id]})).unwrap()["ids"][0].as_u64().unwrap();
    assert!(!shape(&s, copy).tags.iter().any(|(key, _)| key.eq_ignore_ascii_case("DSH-BRAND-COLOR-V1")));
    assert_eq!(origin(&s, id), marker);
    s.execute("edit.select", &json!({"ids":[id]})).unwrap();
    s.execute("edit.copy", &json!({})).unwrap();
    let pasted = s.execute("edit.paste", &json!({})).unwrap()["ids"][0].as_u64().unwrap();
    assert!(!shape(&s, pasted).tags.iter().any(|(key, _)| key.eq_ignore_ascii_case("DSH-BRAND-COLOR-V1")));
    assert_eq!(origin(&s, id), marker);
    s.execute("slide.duplicate", &json!({"index":0})).unwrap();
    let tagged = s
        .doc()
        .unwrap()
        .doc
        .slides
        .iter()
        .flat_map(|slide| &slide.shapes)
        .filter(|shape| shape.tags.iter().any(|(key, _)| key.eq_ignore_ascii_case("DSH-BRAND-COLOR-V1")))
        .count();
    assert_eq!(tagged, 1);
}
