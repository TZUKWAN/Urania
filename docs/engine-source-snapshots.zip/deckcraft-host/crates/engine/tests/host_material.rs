#![allow(clippy::unwrap_used, clippy::panic, clippy::expect_used)]
// Real engine/internal clipboard, contributor-original pixels, no Office/OS clipboard.
use deckcraft_engine::Session;
use deckcraft_model::{Shape, ShapeId};
use serde_json::{Value, json};
use std::io::Cursor;
fn png(color: [u8; 4]) -> Vec<u8> {
    let mut out = Vec::new();
    image::RgbaImage::from_pixel(12, 8, image::Rgba(color)).write_to(&mut Cursor::new(&mut out), image::ImageFormat::Png).unwrap();
    out
}
fn encoded(bytes: &[u8]) -> String {
    deckcraft_engine::cmd::base64_encode(bytes)
}
fn material(asset: &str) -> Value {
    json!({"schema":1,"projectId":"project-fixture","assetId":asset})
}
fn shape(session: &Session, id: u64) -> &Shape {
    let p = &session.doc().unwrap().doc;
    p.slides.iter().find_map(|slide| deckcraft_model::find_shape(&slide.shapes, ShapeId(id as u32))).unwrap()
}
fn origin(session: &Session, id: u64) -> Value {
    serde_json::from_str(&shape(session, id).tags.iter().find(|(key, _)| key.eq_ignore_ascii_case("DSH-MATERIAL-V1")).unwrap().1).unwrap()
}
fn session() -> Session {
    let mut s = Session::new();
    s.execute("file.new", &json!({})).unwrap();
    s
}
fn place(session: &mut Session, marker: bool) -> u64 {
    let mut p = json!({"name":"original.png","data":encoded(&png([0,0,0,255])),"rect":[30,40,240,160]});
    if marker {
        p["hostMaterial"] = material("asset-original");
    }
    session.execute("insert.picture", &p).unwrap()["id"].as_u64().unwrap()
}
#[test]
fn origin_is_atomic_with_picture_insert_replace_and_undo_redo() {
    let mut s = session();
    let before = s.doc().unwrap().history.undo.len();
    let id = place(&mut s, true);
    let old = origin(&s, id);
    assert_eq!(s.doc().unwrap().history.undo.len(), before + 1);
    assert_eq!(old["assetId"], "asset-original");
    let source = s.doc().unwrap().doc.clone();
    let undo = s.doc().unwrap().history.undo.len();
    s.execute(
        "picture.replaceContent",
        &json!({"ids":[id],"name":"changed.png","data":encoded(&png([0,180,80,255])),"hostMaterial":material("asset-edited")}),
    )
    .unwrap();
    let updated = origin(&s, id);
    assert_eq!(updated["instanceId"], old["instanceId"]);
    assert_eq!(updated["assetId"], "asset-edited");
    assert_eq!(s.doc().unwrap().history.undo.len(), undo + 1);
    s.execute("edit.undo", &json!({})).unwrap();
    assert_eq!(origin(&s, id), old);
    assert_eq!(*s.doc().unwrap().doc, *source);
    s.execute("edit.redo", &json!({})).unwrap();
    assert_eq!(origin(&s, id), updated);
    let native = deckcraft_format::save(&s.doc().unwrap().doc).unwrap();
    assert_eq!(*s.doc().unwrap().doc, deckcraft_format::load(&native).unwrap());
    let pptx = deckcraft_pptx::export(&s.doc().unwrap().doc).unwrap();
    let (loaded, warnings) = deckcraft_pptx::import_checked(&pptx).unwrap();
    assert!(warnings.is_empty(), "{warnings:?}");
    assert!(loaded.slides.iter().flat_map(|slide| slide.shapes.iter()).any(|shape| {
        shape.tags.iter().any(|(k, v)| k.eq_ignore_ascii_case("DSH-MATERIAL-V1") && serde_json::from_str::<Value>(v).unwrap() == updated)
    }));
}
#[test]
fn duplicate_internal_clipboard_and_reused_shape_id_do_not_reuse_instance_identity() {
    let mut s = session();
    let id = place(&mut s, true);
    let old = origin(&s, id);
    let copied = s.execute("edit.duplicate", &json!({"ids":[id]})).unwrap()["ids"][0].as_u64().unwrap();
    let one = origin(&s, copied);
    assert_ne!(one["instanceId"], old["instanceId"]);
    assert_eq!(one["assetId"], old["assetId"]);
    s.execute("edit.undo", &json!({})).unwrap();
    s.execute("edit.redo", &json!({})).unwrap();
    assert_eq!(origin(&s, copied), one);
    s.execute("edit.undo", &json!({})).unwrap();
    s.execute("edit.select", &json!({"ids":[id]})).unwrap();
    let again = s.execute("edit.duplicate", &json!({"ids":[id]})).unwrap()["ids"][0].as_u64().unwrap();
    assert_ne!(origin(&s, again)["instanceId"], one["instanceId"]);
    s.execute("edit.copy", &json!({})).unwrap();
    let pasted = s.execute("edit.paste", &json!({})).unwrap()["ids"][0].as_u64().unwrap();
    assert_ne!(origin(&s, pasted)["instanceId"], origin(&s, again)["instanceId"]);
    assert_eq!(origin(&s, pasted)["assetId"], old["assetId"]);
}
#[test]
fn legacy_annotation_is_reversible_and_invalid_origin_cannot_mutate_source() {
    let mut s = session();
    let id = place(&mut s, false);
    let source = s.doc().unwrap().doc.clone();
    let undo = s.doc().unwrap().history.undo.len();
    s.execute("picture.assignMaterialOrigins", &json!({"origins":[{"id":id,"hostMaterial":material("asset-original")}]})).unwrap();
    assert_eq!(origin(&s, id)["assetId"], "asset-original");
    assert_eq!(s.doc().unwrap().history.undo.len(), undo + 1);
    s.execute("edit.undo", &json!({})).unwrap();
    assert_eq!(*s.doc().unwrap().doc, *source);
    let undo = s.doc().unwrap().history.undo.len();
    assert!(
        s.execute(
            "picture.replaceContent",
            &json!({"ids":[id],"data":encoded(&png([255,0,0,255])),"hostMaterial":{"schema":1,"projectId":"../bad","assetId":"asset-edited"}})
        )
        .is_err()
    );
    assert_eq!(*s.doc().unwrap().doc, *source);
    assert_eq!(s.doc().unwrap().history.undo.len(), undo);
}
