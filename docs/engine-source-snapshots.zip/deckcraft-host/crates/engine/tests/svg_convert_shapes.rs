#![allow(clippy::unwrap_used, clippy::panic, clippy::expect_used)]
//! Native conversion of actual contributor-original Vector exports and previews.
use deckcraft_engine::Session;
use deckcraft_model::{Geom, Presentation, Shape, ShapeId, ShapeKind};
use serde_json::{Value, json};
use std::io::{Cursor, Read};
const SIMPLE: &[u8] = include_bytes!("fixtures/dsh-svg-conversion/source.svg");
const SIMPLE_PREVIEW: &[u8] = include_bytes!("fixtures/dsh-svg-conversion/preview.png");
const TEXT: &[u8] = include_bytes!("fixtures/dsh-svg-conversion/text.svg");
const TEXT_PREVIEW: &[u8] = include_bytes!("fixtures/dsh-svg-conversion/text-preview.png");
const COMPLEX: &[u8] = include_bytes!("fixtures/host-svg/source.svg");
const COMPLEX_PREVIEW: &[u8] = include_bytes!("fixtures/host-svg/preview.png");
fn session() -> Session {
    let mut s = Session::new();
    s.execute("file.new", &json!({})).unwrap();
    s
}
fn insert(s: &mut Session, svg: &[u8], preview: &[u8], rect: [f64; 4]) -> ShapeId {
    let result=s.execute("insert.svgPicture",&json!({"name":"actual.svg","data":deckcraft_engine::cmd::base64_encode(svg),"previewData":deckcraft_engine::cmd::base64_encode(preview),"rect":rect})).unwrap();
    ShapeId(result["id"].as_u64().unwrap() as u32)
}
fn find(p: &Presentation, id: ShapeId) -> &Shape {
    p.slides.iter().find_map(|slide| deckcraft_model::find_shape(&slide.shapes, id)).unwrap()
}
fn original_svg(p: &Presentation, id: ShapeId) -> &[u8] {
    let ShapeKind::Picture { fill } = &find(p, id).kind else { panic!("expected original picture") };
    p.media(fill.svg_source.unwrap()).unwrap().data.as_slice()
}
fn entry(bytes: &[u8], name: &str) -> String {
    let mut zip = zip::ZipArchive::new(Cursor::new(bytes)).unwrap();
    let mut file = zip.by_name(name).unwrap();
    let mut text = String::new();
    file.read_to_string(&mut text).unwrap();
    text
}
fn ids(value: &Value) -> Vec<ShapeId> {
    value["ids"].as_array().unwrap().iter().map(|v| ShapeId(v.as_u64().unwrap() as u32)).collect()
}

#[test]
fn real_svg_converts_to_native_paths_preserves_original_and_roundtrips_pptx() {
    let mut s = session();
    let first = insert(&mut s, SIMPLE, SIMPLE_PREVIEW, [40.0, 60.0, 320.0, 240.0]);
    let other = insert(&mut s, SIMPLE, SIMPLE_PREVIEW, [400.0, 60.0, 320.0, 240.0]);
    let before = s.doc().unwrap().doc.clone();
    let n = s.doc().unwrap().history.undo.len();
    let result = s.execute("picture.convertSvgToShapes", &json!({"ids":[first.0]})).unwrap();
    let converted = ids(&result);
    assert_eq!(converted.len(), 3);
    assert_eq!(result["originalRetained"], true);
    assert_eq!(result["originalHidden"], true);
    let after = s.doc().unwrap().doc.clone();
    assert_eq!(s.doc().unwrap().history.undo.len(), n + 1);
    assert!(find(&after, first).hidden);
    assert_eq!(original_svg(&after, first), SIMPLE);
    assert_eq!(find(&after, other), find(&before, other));
    for id in &converted {
        let sh = find(&after, *id);
        assert!(matches!(sh.kind, ShapeKind::Shape));
        assert!(matches!(sh.geom, Geom::Custom { .. }));
        assert!(!sh.hidden);
    }
    let actual_shapes = converted.iter().map(|id| find(&after, *id).clone()).collect::<Vec<_>>();
    assert_eq!(result["nativeShapes"], serde_json::to_value(&actual_shapes).unwrap());
    let native = deckcraft_format::save(&after).unwrap();
    let reopened = deckcraft_format::load(&native).unwrap();
    assert_eq!(original_svg(&reopened, first), SIMPLE);
    let pptx = deckcraft_pptx::export(&reopened).unwrap();
    let slide = entry(&pptx, "ppt/slides/slide1.xml");
    assert!(slide.matches("<a:custGeom>").count() >= 3);
    assert!(slide.contains("<p:pic>") && slide.contains("asvg:svgBlip") && slide.contains("hidden=\"1\""));
    let (imported, warnings) = deckcraft_pptx::import_checked(&pptx).unwrap();
    assert!(warnings.is_empty(), "{warnings:?}");
    assert!(imported.slides.iter().flat_map(|slide| slide.shapes.iter()).filter(|sh| matches!(sh.geom, Geom::Custom { .. })).count() >= 3);
    assert!(imported.slides.iter().flat_map(|slide| slide.shapes.iter()).any(|sh| sh.hidden && matches!(sh.kind, ShapeKind::Picture { .. })));
    let old_image = deckcraft_render::render_slide(&before, 0, &deckcraft_render::RenderOpts::default());
    let new_image = deckcraft_render::render_slide(&after, 0, &deckcraft_render::RenderOpts::default());
    for (x, y) in [(120, 125), (260, 130), (170, 240)] {
        assert_eq!(old_image.straight_at(x, y), new_image.straight_at(x, y), "interior colour at {x},{y}");
    }
    let changed = old_image.pixels.chunks_exact(4).zip(new_image.pixels.chunks_exact(4)).filter(|(a, b)| a != b).count();
    if let Some(path) = std::env::var_os("DESIGNCRAFT_F5_TEST_CAPTURE") {
        let path = std::path::Path::new(&path);
        std::fs::create_dir_all(path).unwrap();
        std::fs::write(path.join("before.deckcraft"), deckcraft_format::save(&before).unwrap()).unwrap();
        std::fs::write(path.join("after.deckcraft"), &native).unwrap();
        std::fs::write(path.join("converted.pptx"), &pptx).unwrap();
        std::fs::write(path.join("native-result.json"), serde_json::to_vec(&result).unwrap()).unwrap();
        std::fs::write(path.join("before.png"), old_image.to_png()).unwrap();
        std::fs::write(path.join("after.png"), new_image.to_png()).unwrap();
        std::fs::write(
            path.join("comparison.json"),
            json!({"changedPixels":changed,"size":[old_image.width,old_image.height],"interiorColoursEqual":true}).to_string(),
        )
        .unwrap();
    }
    s.execute("edit.undo", &json!({})).unwrap();
    assert_eq!(*s.doc().unwrap().doc, *before);
    s.execute("edit.redo", &json!({})).unwrap();
    assert_eq!(*s.doc().unwrap().doc, *after);
}

#[test]
fn actual_text_becomes_native_editable_text_with_explicit_layout_warning() {
    let mut s = session();
    let source = insert(&mut s, TEXT, TEXT_PREVIEW, [40.0, 50.0, 320.0, 160.0]);
    let result = s.execute("picture.convertSvgToShapes", &json!({"ids":[source.0]})).unwrap();
    let converted = ids(&result);
    assert_eq!(converted.len(), 1);
    assert_eq!(result["textCount"], 1);
    assert!(!result["warnings"].as_array().unwrap().is_empty());
    let doc = s.doc().unwrap().doc.clone();
    let text = find(&doc, converted[0]).text.as_ref().unwrap();
    assert_eq!(text.paragraphs[0].runs[0].text, "Editable text");
    assert_eq!(text.paragraphs[0].runs[0].props.font.as_deref(), Some("Inter"));
    assert_eq!(original_svg(&doc, source), TEXT);
    let pptx = deckcraft_pptx::export(&doc).unwrap();
    let slide = entry(&pptx, "ppt/slides/slide1.xml");
    assert!(slide.contains("<p:txBody>") && slide.contains("Editable text") && slide.contains("asvg:svgBlip"));
    let (imported, _) = deckcraft_pptx::import_checked(&pptx).unwrap();
    assert!(
        imported.slides.iter().flat_map(|slide| slide.shapes.iter()).any(|shape| shape
            .text
            .as_ref()
            .is_some_and(|body| body.paragraphs.iter().any(|p| p.runs.iter().any(|run| run.text == "Editable text"))))
    );
    if let Some(path) = std::env::var_os("DESIGNCRAFT_F5_TEST_CAPTURE") {
        let path = std::path::Path::new(&path);
        std::fs::create_dir_all(path).unwrap();
        std::fs::write(path.join("converted-text.pptx"), &pptx).unwrap();
    }
}

#[test]
fn complex_svg_and_cropped_picture_refuse_without_any_mutation() {
    for complex in [true, false] {
        let mut s = session();
        let id = if complex {
            insert(&mut s, COMPLEX, COMPLEX_PREVIEW, [20.0, 30.0, 320.0, 240.0])
        } else {
            insert(&mut s, SIMPLE, SIMPLE_PREVIEW, [20.0, 30.0, 320.0, 240.0])
        };
        if !complex {
            s.execute("picture.crop", &json!({"ids":[id.0],"left":0.1})).unwrap();
            let report = s.execute("picture.inspectSvgConversion", &json!({"ids":[id.0]})).unwrap();
            assert_eq!(report["basicGeometryRecognized"], true);
            assert_eq!(report["conversionAvailable"], false);
        }
        let before = s.doc().unwrap().doc.clone();
        let n = s.doc().unwrap().history.undo.len();
        assert!(s.execute("picture.convertSvgToShapes", &json!({"ids":[id.0]})).is_err());
        assert_eq!(*s.doc().unwrap().doc, *before);
        assert_eq!(s.doc().unwrap().history.undo.len(), n);
    }
}

#[test]
fn deliberately_unsupported_open_or_stroked_paths_never_modify_a_presentation() {
    // Adversarial parser inputs only: the real preview is not presented as a
    // visual match for these deliberately altered SVGs.
    for extra in ["", " stroke=\"#000000\""] {
        let svg = format!(
            "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"320\" height=\"240\" viewBox=\"0 0 320 240\"><path d=\"M 10 10 L 100 100\" fill=\"#287d6c\"{extra}/></svg>"
        );
        let mut s = session();
        let id = insert(&mut s, svg.as_bytes(), SIMPLE_PREVIEW, [20.0, 30.0, 320.0, 240.0]);
        let before = s.doc().unwrap().doc.clone();
        let n = s.doc().unwrap().history.undo.len();
        let report = s.execute("picture.inspectSvgConversion", &json!({"ids":[id.0]})).unwrap();
        assert_eq!(report["conversionAvailable"], false);
        assert!(s.execute("picture.convertSvgToShapes", &json!({"ids":[id.0]})).is_err());
        assert_eq!(*s.doc().unwrap().doc, *before);
        assert_eq!(s.doc().unwrap().history.undo.len(), n);
    }
}
