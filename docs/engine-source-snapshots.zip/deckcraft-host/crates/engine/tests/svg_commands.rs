#![allow(clippy::unwrap_used, clippy::panic, clippy::expect_used)]
//! Real native commands over paired original/edited Vector exports. No SVG
//! renderer is simulated: both genuine PNG previews retain capture provenance.
use deckcraft_engine::Session;
use deckcraft_model::{Presentation, Shape, ShapeId, ShapeKind};
use serde_json::{Value, json};
const SVG: &[u8] = include_bytes!("fixtures/host-svg/source.svg");
const PNG: &[u8] = include_bytes!("fixtures/host-svg/preview.png");
const EDITED_SVG: &[u8] = include_bytes!("fixtures/host-svg/edited-source.svg");
const EDITED_PNG: &[u8] = include_bytes!("fixtures/host-svg/edited-preview.png");
fn params(edited: bool) -> Value {
    json!({"name":"native-source.svg","data":deckcraft_engine::cmd::base64_encode(if edited {EDITED_SVG} else {SVG}),"previewData":deckcraft_engine::cmd::base64_encode(if edited {EDITED_PNG} else {PNG}),"hostMaterial":{"schema":1,"projectId":"project-fixture","assetId":if edited {"asset-edited"} else {"asset-original"}}})
}
fn shape(p: &Presentation, id: ShapeId) -> &Shape {
    p.slides.iter().find_map(|s| deckcraft_model::find_shape(&s.shapes, id)).unwrap()
}
fn shape_mut(p: &mut Presentation, id: ShapeId) -> &mut Shape {
    p.slides.iter_mut().find_map(|s| deckcraft_model::find_shape_mut(&mut std::sync::Arc::make_mut(s).shapes, id)).unwrap()
}
fn origin(shape: &Shape) -> Value {
    serde_json::from_str(&shape.tags.iter().find(|(k, _)| k.eq_ignore_ascii_case("DSH-MATERIAL-V1")).unwrap().1).unwrap()
}
fn assert_pair(p: &Presentation, id: ShapeId, edited: bool) {
    let ShapeKind::Picture { fill } = &shape(p, id).kind else { panic!("picture") };
    assert_eq!(p.media(fill.media).unwrap().data.as_slice(), if edited { EDITED_PNG } else { PNG });
    assert_eq!(p.media(fill.svg_source.unwrap()).unwrap().data.as_slice(), if edited { EDITED_SVG } else { SVG });
}
fn session() -> Session {
    let mut s = Session::new();
    s.execute("file.new", &json!({})).unwrap();
    s
}
fn insert(s: &mut Session) -> ShapeId {
    ShapeId(s.execute("insert.svgPicture", &params(false)).unwrap()["id"].as_u64().unwrap() as u32)
}

#[test]
fn svg_pair_insert_replace_has_one_undo_preserves_other_use_and_full_layout() {
    let mut s = session();
    let original = s.doc().unwrap().doc.clone();
    let n = s.doc().unwrap().history.undo.len();
    let id = insert(&mut s);
    assert_eq!(s.doc().unwrap().history.undo.len(), n + 1);
    assert_pair(&s.doc().unwrap().doc, id, false);
    s.execute("edit.undo", &json!({})).unwrap();
    assert_eq!(*s.doc().unwrap().doc, *original);
    s.execute("edit.redo", &json!({})).unwrap();
    let other = insert(&mut s);
    s.execute("picture.crop", &json!({"ids":[id.0],"left":0.1,"top":0.12,"right":0.02,"bottom":0.08})).unwrap();
    s.execute("picture.adjust", &json!({"ids":[id.0],"transparency":0.37,"brightness":0.17})).unwrap();
    s.execute("shape.rotate", &json!({"ids":[id.0],"deg":17})).unwrap();
    s.execute("arrange.group", &json!({"ids":[id.0,other.0]})).unwrap();
    s.edit(|doc, _| {
        shape_mut(doc, id).tags.push(("custom-tag".into(), "keep".into()));
        Ok(())
    })
    .unwrap();
    let before = s.doc().unwrap().doc.clone();
    let old = origin(shape(&before, id));
    let n = s.doc().unwrap().history.undo.len();
    let mut p = params(true);
    p["ids"] = json!([id.0]);
    s.execute("picture.replaceSvgContent", &p).unwrap();
    assert_eq!(s.doc().unwrap().history.undo.len(), n + 1);
    assert_pair(&s.doc().unwrap().doc, id, true);
    assert_pair(&s.doc().unwrap().doc, other, false);
    let new = origin(shape(&s.doc().unwrap().doc, id));
    assert_eq!(new["instanceId"], old["instanceId"]);
    assert_eq!(new["assetId"], "asset-edited");
    let mut normalized = (*s.doc().unwrap().doc).clone();
    normalized.media = before.media.clone();
    normalized.next_id = before.next_id;
    let original_node = shape(&before, id);
    let node = shape_mut(&mut normalized, id);
    let ShapeKind::Picture { fill: old_fill } = &original_node.kind else { panic!("picture") };
    let ShapeKind::Picture { fill } = &mut node.kind else { panic!("picture") };
    fill.media = old_fill.media;
    fill.svg_source = old_fill.svg_source;
    node.tags.iter_mut().find(|(k, _)| k.eq_ignore_ascii_case("DSH-MATERIAL-V1")).unwrap().1 =
        original_node.tags.iter().find(|(k, _)| k.eq_ignore_ascii_case("DSH-MATERIAL-V1")).unwrap().1.clone();
    assert_eq!(normalized, *before);
    let after = s.doc().unwrap().doc.clone();
    s.execute("edit.undo", &json!({})).unwrap();
    assert_eq!(*s.doc().unwrap().doc, *before);
    s.execute("edit.redo", &json!({})).unwrap();
    assert_eq!(*s.doc().unwrap().doc, *after);
    let native = deckcraft_format::save(&after).unwrap();
    let loaded = deckcraft_engine::embedded::import("source.deckcraft", &native, Default::default()).unwrap();
    assert_pair(&loaded.presentation, id, true);
    let pptx = deckcraft_pptx::export(&after).unwrap();
    let loaded = deckcraft_engine::embedded::import("source.pptx", &pptx, Default::default()).unwrap();
    assert!(loaded.warnings.is_empty(), "{:?}", loaded.warnings);
    let target = loaded.presentation.slides.iter().flat_map(|s| s.shapes.iter()).find_map(|s| find_origin(s, &new)).unwrap();
    assert_pair(&loaded.presentation, target.id, true);
    // Optional evidence output follows every assertion; it never substitutes
    // for the native commands or their checks.
    if let Some(path) = std::env::var_os("DSH_DESIGNCRAFT_TEST_SVG_OUT") {
        let out = std::path::PathBuf::from(path);
        assert!(out.is_absolute());
        std::fs::create_dir_all(&out).unwrap();
        std::fs::write(out.join("before.deckcraft"), deckcraft_format::save(&before).unwrap()).unwrap();
        std::fs::write(out.join("after.deckcraft"), &native).unwrap();
        std::fs::write(out.join("after.pptx"), &pptx).unwrap();
        std::fs::write(out.join("metadata.json"), serde_json::to_vec_pretty(&json!({"targetId":id.0,"otherId":other.0,"originBefore":old,"originAfter":new,"producer":"actual insert.svgPicture/picture.replaceSvgContent integration test"})).unwrap()).unwrap();
    }
}
fn find_origin<'a>(s: &'a Shape, expected: &Value) -> Option<&'a Shape> {
    if s.tags.iter().any(|(k, v)| k.eq_ignore_ascii_case("DSH-MATERIAL-V1") && serde_json::from_str::<Value>(v).ok().as_ref() == Some(expected)) {
        return Some(s);
    }
    if let ShapeKind::Group { children, .. } = &s.kind {
        return children.iter().find_map(|s| find_origin(s, expected));
    }
    None
}

#[test]
fn invalid_or_uneditable_svg_pair_never_mutates_native_document_or_history() {
    let mut s = session();
    let id = insert(&mut s);
    let before = s.doc().unwrap().doc.clone();
    let n = s.doc().unwrap().history.undo.len();
    for bytes in [
        b"<svg xmlns='http://www.w3.org/2000/svg'><script>bad()</script></svg>".as_slice(),
        b"<svg xmlns='http://www.w3.org/2000/svg'><image href='https://example.invalid/x.png'/></svg>".as_slice(),
        b"<svg xmlns='http://www.w3.org/2000/svg'><g>".as_slice(),
    ] {
        let mut p = params(true);
        p["ids"] = json!([id.0]);
        p["data"] = json!(deckcraft_engine::cmd::base64_encode(bytes));
        assert!(s.execute("picture.replaceSvgContent", &p).is_err());
        assert_eq!(*s.doc().unwrap().doc, *before);
        assert_eq!(s.doc().unwrap().history.undo.len(), n);
    }
    let mut p = params(true);
    p["ids"] = json!([id.0]);
    p["previewData"] = json!(deckcraft_engine::cmd::base64_encode(&PNG[..PNG.len() / 2]));
    assert!(s.execute("picture.replaceSvgContent", &p).is_err());
    assert_eq!(*s.doc().unwrap().doc, *before);
    assert!(
        s.execute("picture.replaceContent", &json!({"ids":[id.0],"name":"raw.png","data":deckcraft_engine::cmd::base64_encode(EDITED_PNG)})).is_err()
    );
    assert_eq!(*s.doc().unwrap().doc, *before);
    let other = insert(&mut s);
    let grouped = s.execute("arrange.group", &json!({"ids":[id.0,other.0]})).unwrap()["id"].as_u64().unwrap();
    s.edit(|doc, _| {
        shape_mut(doc, ShapeId(grouped as u32)).locked = true;
        Ok(())
    })
    .unwrap();
    let before = s.doc().unwrap().doc.clone();
    let mut p = params(true);
    p["ids"] = json!([id.0]);
    assert!(s.execute("picture.replaceSvgContent", &p).is_err());
    assert_eq!(*s.doc().unwrap().doc, *before);
}

#[test]
fn explicit_raster_change_clears_svg_and_provenance_and_undo_restores_them() {
    let mut s = session();
    let id = insert(&mut s);
    let old = origin(shape(&s.doc().unwrap().doc, id));
    s.execute("picture.change", &json!({"ids":[id.0],"name":"changed.png","data":deckcraft_engine::cmd::base64_encode(EDITED_PNG)})).unwrap();
    let ShapeKind::Picture { fill } = &shape(&s.doc().unwrap().doc, id).kind else { panic!("picture") };
    assert!(fill.svg_source.is_none());
    assert!(!shape(&s.doc().unwrap().doc, id).tags.iter().any(|(k, _)| k.eq_ignore_ascii_case("DSH-MATERIAL-V1")));
    s.execute("edit.undo", &json!({})).unwrap();
    assert_pair(&s.doc().unwrap().doc, id, false);
    assert_eq!(origin(shape(&s.doc().unwrap().doc, id)), old);
}
