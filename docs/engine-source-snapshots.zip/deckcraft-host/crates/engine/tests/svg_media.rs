#![allow(clippy::unwrap_used, clippy::panic, clippy::expect_used)]
//! Codec/media-walker input tests, not SVG command or UI acceptance.
//! These source/preview bytes came from the real same-revision Vector App;
//! provenance and original contributor geometry are in fixtures/host-svg/.
use deckcraft_engine::Session;
use deckcraft_model::style::PictureFill;
use deckcraft_model::{Presentation, Shape, ShapeId, ShapeKind};
use serde_json::json;
use std::io::{Cursor, Read};

const SVG: &[u8] = include_bytes!("fixtures/host-svg/source.svg");
const PNG: &[u8] = include_bytes!("fixtures/host-svg/preview.png");

fn shape(session: &Session, id: ShapeId) -> &Shape {
    session.doc().unwrap().doc.slides.iter().find_map(|slide| deckcraft_model::find_shape(&slide.shapes, id)).unwrap()
}
fn fill(shape: &Shape) -> &PictureFill {
    let ShapeKind::Picture { fill } = &shape.kind else { panic!("expected actual picture") };
    fill
}
fn assert_pair(p: &Presentation, shape: &Shape) {
    let fill = fill(shape);
    let source = p.media(fill.svg_source.unwrap()).unwrap();
    let preview = p.media(fill.media).unwrap();
    assert_eq!(source.content_type, "image/svg+xml");
    assert_eq!(source.data.as_slice(), SVG);
    assert_eq!(preview.content_type, "image/png");
    assert_eq!(preview.data.as_slice(), PNG);
    assert_ne!(source.id, preview.id);
}
fn paired() -> (Session, ShapeId) {
    let mut s = Session::new();
    s.execute("file.new", &json!({})).unwrap();
    let id = s
        .execute("insert.picture", &json!({"name":"real-preview.png","data":deckcraft_engine::cmd::base64_encode(PNG),"rect":[36,48,240,180]}))
        .unwrap()["id"]
        .as_u64()
        .unwrap();
    let id = ShapeId(id as u32);
    // Construct a model input for codecs. Native SVG insert/replace is a
    // subsequent integration unit; do not pretend it exists in this test.
    s.edit(|doc, _| {
        let source = doc.add_media("original-vector.svg", "image/svg+xml", SVG.to_vec()).unwrap();
        let target = deckcraft_model::find_shape_mut(&mut std::sync::Arc::make_mut(&mut doc.slides[0]).shapes, id).unwrap();
        let ShapeKind::Picture { fill } = &mut target.kind else { panic!("picture changed") };
        fill.svg_source = Some(source);
        fill.crop = [0.1, 0.12, 0.02, 0.08];
        fill.alpha = Some(0.63);
        fill.adjust.brightness = 0.17;
        Ok(())
    })
    .unwrap();
    s.execute("shape.rotate", &json!({"ids":[id.0],"deg":17})).unwrap();
    (s, id)
}

#[test]
fn actual_svg_and_preview_survive_native_and_standard_pptx_roundtrips() {
    let (s, id) = paired();
    let original = &s.doc().unwrap().doc;
    assert_pair(original, shape(&s, id));
    let native = deckcraft_format::save(original).unwrap();
    assert_eq!(**original, deckcraft_format::load(&native).unwrap());
    let pptx = deckcraft_pptx::export(original).unwrap();
    let mut zip = zip::ZipArchive::new(Cursor::new(&pptx)).unwrap();
    let mut xml = String::new();
    zip.by_name("ppt/slides/slide1.xml").unwrap().read_to_string(&mut xml).unwrap();
    assert!(xml.contains("{96DAC541-7B7A-43D3-8B79-37D633B846F1}"));
    assert!(xml.contains("http://schemas.microsoft.com/office/drawing/2016/SVG/main"));
    assert_eq!(xml.matches("<asvg:svgBlip ").count(), 1);
    assert_eq!(xml.matches("<a:extLst>").count(), 1);
    let (loaded, warnings) = deckcraft_pptx::import_checked(&pptx).unwrap();
    assert!(warnings.is_empty(), "{warnings:?}");
    let imported = loaded.slides.iter().flat_map(|sl| sl.shapes.iter()).find(|sh| matches!(&sh.kind, ShapeKind::Picture { .. })).unwrap();
    assert_pair(&loaded, imported);
    assert_eq!(imported.xfrm, shape(&s, id).xfrm);
    assert_eq!(fill(imported).crop, fill(shape(&s, id)).crop);
    assert_eq!(fill(imported).alpha, fill(shape(&s, id)).alpha);
    assert_eq!(fill(imported).adjust, fill(shape(&s, id)).adjust);
    assert_eq!(loaded, deckcraft_format::load(&deckcraft_format::save(&loaded).unwrap()).unwrap());
    let (again, warnings) = deckcraft_pptx::import_checked(&deckcraft_pptx::export(&loaded).unwrap()).unwrap();
    assert!(warnings.is_empty(), "{warnings:?}");
    let imported = again.slides.iter().flat_map(|sl| sl.shapes.iter()).find(|sh| matches!(&sh.kind, ShapeKind::Picture { .. })).unwrap();
    assert_pair(&again, imported);
}

#[test]
fn internal_clipboard_keeps_and_remaps_both_svg_and_preview_across_native_documents() {
    let (mut s, id) = paired();
    let source_id = fill(shape(&s, id)).svg_source.unwrap();
    s.execute("edit.select", &json!({"ids":[id.0]})).unwrap();
    s.execute("edit.copy", &json!({})).unwrap();
    s.execute("file.new", &json!({})).unwrap();
    // Identical PNG bytes deduplicate, so they cannot force a media-id
    // collision. Distinct contributor-original prefix pixels occupy the old
    // source's actual id; the copied SVG and its real preview stay untouched.
    s.edit(|doc, _| {
        for n in 0..16u8 {
            if doc.media(source_id).is_some() {
                break;
            }
            let mut bytes = Vec::new();
            image::RgbaImage::from_pixel(1, 1, image::Rgba([n, 5, 6, 255])).write_to(&mut Cursor::new(&mut bytes), image::ImageFormat::Png).unwrap();
            doc.add_media(&format!("prefix-{n}.png"), "image/png", bytes).unwrap();
        }
        assert_ne!(doc.media(source_id).unwrap().data.as_slice(), SVG);
        Ok(())
    })
    .unwrap();
    let pasted = s.execute("edit.paste", &json!({})).unwrap()["ids"][0].as_u64().unwrap();
    let pasted = ShapeId(pasted as u32);
    assert_ne!(fill(shape(&s, pasted)).svg_source.unwrap(), source_id);
    assert_pair(&s.doc().unwrap().doc, shape(&s, pasted));
    let loaded = deckcraft_format::load(&deckcraft_format::save(&s.doc().unwrap().doc).unwrap()).unwrap();
    let copied = loaded.slides.iter().find_map(|sl| deckcraft_model::find_shape(&sl.shapes, pasted)).unwrap();
    assert_pair(&loaded, copied);
}
