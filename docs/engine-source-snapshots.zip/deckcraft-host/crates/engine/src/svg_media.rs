//! Static original SVG and a separately rendered, bounded PNG preview.
//! This validates and retains SVG; it is not an SVG-to-raster renderer.
use quick_xml::events::Event;

pub(crate) const MAX_BYTES: usize = 4 * 1024 * 1024;

fn urls(value: &str) -> Result<(), String> {
    let lower = value.to_ascii_lowercase();
    if lower.contains("@import") || lower.contains("javascript:") {
        return Err("active SVG content is not admitted".into());
    }
    let mut rest = lower.as_str();
    while let Some(at) = rest.find("url(") {
        rest = rest.get(at + 4..).ok_or("invalid SVG URL")?;
        let end = rest.find(')').ok_or("unterminated SVG URL")?;
        let target = rest.get(..end).ok_or("invalid SVG URL")?.trim().trim_matches(['\'', '"']);
        if !target.starts_with('#') {
            return Err("external SVG resources are not admitted".into());
        }
        rest = rest.get(end + 1..).ok_or("invalid SVG URL")?;
    }
    Ok(())
}

pub(crate) fn admit_svg(bytes: &[u8]) -> Result<(), String> {
    if bytes.is_empty() || bytes.len() > MAX_BYTES {
        return Err("SVG exceeds the 4 MiB source budget".into());
    }
    let text = std::str::from_utf8(bytes).map_err(|_| "SVG must be UTF-8")?;
    let mut reader = quick_xml::Reader::from_str(text.trim_start_matches('\u{feff}'));
    reader.config_mut().check_end_names = true;
    let (mut depth, mut nodes, mut root_seen) = (0usize, 0usize, false);
    loop {
        let event = reader.read_event().map_err(|e| format!("SVG XML cannot be read: {e}"))?;
        let opens = matches!(&event, Event::Start(_));
        match event {
            Event::Start(e) | Event::Empty(e) => {
                nodes += 1;
                if nodes > 100_000 || depth >= 128 {
                    return Err("SVG exceeds its node/depth budget".into());
                }
                let local = String::from_utf8_lossy(e.local_name().as_ref()).to_ascii_lowercase();
                if matches!(
                    local.as_str(),
                    "script" | "foreignobject" | "iframe" | "object" | "embed" | "animate" | "animatemotion" | "animatetransform" | "set"
                ) {
                    return Err("only static SVG artwork is admitted".into());
                }
                let root = depth == 0;
                if root && (root_seen || e.local_name().as_ref() != b"svg") {
                    return Err("SVG needs exactly one svg root".into());
                }
                let qualified = String::from_utf8_lossy(e.name().as_ref()).into_owned();
                let namespace = qualified.split_once(':').map(|(p, _)| format!("xmlns:{p}")).unwrap_or_else(|| "xmlns".into());
                let mut root_namespace = false;
                for attr in e.attributes().with_checks(true) {
                    let attr = attr.map_err(|e| e.to_string())?;
                    let key = String::from_utf8_lossy(attr.key.as_ref()).to_ascii_lowercase();
                    let value = attr.decoded_and_normalized_value(quick_xml::XmlVersion::Implicit1_0, reader.decoder()).map_err(|e| e.to_string())?;
                    if root && key == namespace && value == "http://www.w3.org/2000/svg" {
                        root_namespace = true;
                    }
                    let local = key.rsplit(':').next().unwrap_or("");
                    if local.starts_with("on") || key == "xml:base" {
                        return Err("active SVG attributes are not admitted".into());
                    }
                    if local == "href" {
                        let value = value.trim();
                        if !value.starts_with('#')
                            && !["data:image/png;base64,", "data:image/jpeg;base64,", "data:image/gif;base64,", "data:image/webp;base64,"]
                                .iter()
                                .any(|p| value.starts_with(p))
                        {
                            return Err("external SVG links are not admitted".into());
                        }
                    }
                    urls(&value)?;
                }
                if root {
                    if !root_namespace {
                        return Err("SVG root namespace is missing".into());
                    }
                    root_seen = true;
                }
                if opens {
                    depth += 1;
                }
            }
            Event::End(_) => {
                depth = depth.checked_sub(1).ok_or("unmatched SVG end")?;
            }
            Event::Text(t) => {
                let value = t.decode().map_err(|e| e.to_string())?;
                if depth == 0 && !value.trim().is_empty() {
                    return Err("text outside SVG root".into());
                }
                urls(&value)?;
            }
            Event::CData(t) => {
                if depth == 0 {
                    return Err("CDATA outside SVG root".into());
                }
                urls(&String::from_utf8_lossy(&t))?;
            }
            Event::DocType(_) | Event::PI(_) => return Err("DTD and processing instructions are not admitted in SVG".into()),
            Event::Decl(_) if root_seen => return Err("XML declaration after SVG root".into()),
            Event::GeneralRef(r) => {
                if !r.is_char_ref() && !matches!(r.as_ref(), b"amp" | b"lt" | b"gt" | b"quot" | b"apos") {
                    return Err("unknown SVG entity".into());
                }
                if r.is_char_ref() && r.resolve_char_ref().map_err(|e| e.to_string())?.is_none() {
                    return Err("invalid SVG character reference".into());
                }
            }
            Event::Eof => break,
            _ => {}
        }
    }
    if !root_seen || depth != 0 {
        return Err("SVG is empty or unfinished".into());
    }
    Ok(())
}

pub(crate) fn admit_preview(bytes: &[u8]) -> Result<(), String> {
    if bytes.len() > MAX_BYTES || !bytes.starts_with(b"\x89PNG\r\n\x1a\n") {
        return Err("SVG preview must be a PNG of at most 4 MiB".into());
    }
    crate::embedded::picture_admission(bytes, 24_000_000)?;
    let mut reader = image::ImageReader::with_format(std::io::Cursor::new(bytes), image::ImageFormat::Png);
    let mut limits = image::Limits::default();
    limits.max_alloc = Some(128 << 20);
    reader.limits(limits);
    reader.decode().map_err(|e| format!("SVG preview PNG cannot be read: {e}"))?;
    Ok(())
}

/// SVG media is admitted for source-owning picture pairs. Other SVG references
/// still fail explicitly instead of opening an invisible, unrendered picture.
pub(crate) fn paired_sources(doc: &deckcraft_model::Presentation) -> Result<std::collections::HashSet<deckcraft_model::MediaId>, String> {
    use deckcraft_model::{MediaId, Presentation, Shape, ShapeKind};
    use std::collections::HashSet;
    fn visit(
        doc: &Presentation,
        shapes: &[Shape],
        depth: usize,
        sources: &mut HashSet<MediaId>,
        checked: &mut HashSet<(MediaId, MediaId)>,
    ) -> Result<(), String> {
        if depth > 64 {
            return Err("SVG picture hierarchy exceeds depth budget".into());
        }
        for shape in shapes {
            match &shape.kind {
                ShapeKind::Group { children, .. } => visit(doc, children, depth + 1, sources, checked)?,
                ShapeKind::Picture { fill } => {
                    if let Some(id) = fill.svg_source {
                        let original = doc.media(id).ok_or("SVG source media is missing")?;
                        let preview_id = fill.artistic.as_ref().map(|a| a.original).unwrap_or(fill.media);
                        let preview = doc.media(preview_id).ok_or("SVG preview media is missing")?;
                        if original.content_type != "image/svg+xml"
                            || original.link.is_some()
                            || preview.content_type != "image/png"
                            || preview.link.is_some()
                        {
                            return Err("SVG picture requires embedded SVG and PNG preview".into());
                        }
                        if checked.insert((id, preview_id)) {
                            admit_svg(&original.data)?;
                            admit_preview(&preview.data)?;
                        }
                        sources.insert(id);
                    }
                }
                _ => {}
            }
        }
        Ok(())
    }
    let (mut sources, mut checked) = (HashSet::new(), HashSet::new());
    for slide in &doc.slides {
        visit(doc, &slide.shapes, 0, &mut sources, &mut checked)?;
    }
    for master in doc.masters.iter().chain(doc.notes_master.iter()).chain(doc.handout_master.iter()) {
        visit(doc, &master.shapes, 0, &mut sources, &mut checked)?;
        for layout in &master.layouts {
            visit(doc, &layout.shapes, 0, &mut sources, &mut checked)?;
        }
    }
    Ok(sources)
}
