//! Font markers are native object identities, not authorization or proof of font.
use super::bad;
use crate::{Result, Session};
use deckcraft_model::{Shape, ShapeId};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};

const TAG: &str = "DSH-BRAND-FONT-V1";
#[derive(Deserialize)]
#[serde(deny_unknown_fields, rename_all = "camelCase")]
struct Row {
    id: u32,
    project_id: String,
    binding_id: String,
}
#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields, rename_all = "camelCase")]
struct Stored {
    schema: u8,
    project_id: String,
    binding_id: String,
    instance_id: String,
}

fn name(value: &str, prefix: &str) -> bool {
    value.starts_with(prefix)
        && value.len() > prefix.len()
        && value.len() <= 81
        && value.bytes().all(|c| c.is_ascii_alphanumeric() || matches!(c, b'_' | b'-'))
}
fn binding_id(value: &str) -> bool {
    value.strip_prefix("brandfont-").is_some_and(|id| {
        id.len() == 36
            && id.bytes().enumerate().all(
                |(i, c)| {
                    if matches!(i, 8 | 13 | 18 | 23) { c == b'-' } else { c.is_ascii_digit() || (b'a'..=b'f').contains(&c) }
                },
            )
    })
}
fn read(shape: &Shape) -> Option<Stored> {
    let mut tags = shape.tags.iter().filter(|(key, _)| key.eq_ignore_ascii_case(TAG));
    let (_, value) = tags.next()?;
    if tags.next().is_some() || value.len() > 1024 {
        return None;
    }
    let stored: Stored = serde_json::from_str(value).ok()?;
    (stored.schema == 1
        && name(&stored.project_id, "project-")
        && binding_id(&stored.binding_id)
        && stored.instance_id.len() == 32
        && stored.instance_id.bytes().all(|c| c.is_ascii_digit() || (b'a'..=b'f').contains(&c)))
    .then_some(stored)
}
fn instance() -> Result<String> {
    let mut bytes = [0; 16];
    getrandom::fill(&mut bytes).map_err(|e| bad("shape.assignFontOrigins", format!("identity randomness unavailable: {e}")))?;
    Ok(bytes.iter().map(|b| format!("{b:02x}")).collect())
}
/// Ordinary copies are independent; a copied shape is not a font binding member.
pub(crate) fn copied(shape: &mut Shape) {
    shape.tags.retain(|(key, _)| !key.eq_ignore_ascii_case(TAG));
}

pub(crate) fn assign(session: &mut Session, params: &Value) -> Result<Value> {
    const CMD: &str = "shape.assignFontOrigins";
    let rows = params
        .get("origins")
        .and_then(Value::as_array)
        .filter(|v| !v.is_empty() && v.len() <= 100)
        .ok_or_else(|| bad(CMD, "give 1..100 explicit brand origins"))?;
    let mut prepared = Vec::new();
    let mut seen = std::collections::BTreeSet::new();
    let mut changed = false;
    let state = session.doc()?;
    for value in rows {
        let row: Row = serde_json::from_value(value.clone()).map_err(|_| bad(CMD, "invalid brand origin"))?;
        if !name(&row.project_id, "project-") || !binding_id(&row.binding_id) || !seen.insert(row.id) {
            return Err(bad(CMD, "invalid or duplicate brand identity"));
        }
        let id = ShapeId(row.id);
        let shape = state.shape(id).ok_or_else(|| bad(CMD, "brand target missing"))?;
        if shape.hidden || shape.locked || shape.text.as_ref().is_none_or(|text| text.is_empty()) {
            return Err(bad(CMD, "font target must be visible, unlocked and contain text"));
        }
        let existing = read(shape);
        if shape.tags.iter().any(|(key, _)| key.eq_ignore_ascii_case(TAG))
            && existing.as_ref().is_none_or(|old| old.project_id != row.project_id || old.binding_id != row.binding_id)
        {
            return Err(bad(CMD, "brand identity conflicts with an existing tag"));
        }
        changed |= existing.is_none();
        let origin = Stored {
            schema: 1,
            project_id: row.project_id,
            binding_id: row.binding_id,
            instance_id: match existing {
                Some(old) => old.instance_id,
                None => instance()?,
            },
        };
        let serialized = serde_json::to_string(&origin).map_err(|e| bad(CMD, e.to_string()))?;
        prepared.push((id, serialized, origin.instance_id));
    }
    if !changed {
        return Ok(
            json!({"origins": prepared.iter().map(|(id, _, token)| json!({"id":id.0,"instanceId":token})).collect::<Vec<_>>(),"unchanged":true}),
        );
    }
    session.edit(|doc, selection| {
        let shapes = crate::shapes_mut(doc, selection).ok_or_else(|| bad(CMD, "no current slide shape tree"))?;
        for (id, value, _) in &prepared {
            let shape = deckcraft_model::find_shape_mut(shapes, *id).ok_or_else(|| bad(CMD, "brand target moved"))?;
            if let Some((_, old)) = shape.tags.iter_mut().find(|(key, _)| key.eq_ignore_ascii_case(TAG)) {
                *old = value.clone();
            } else {
                shape.tags.push((TAG.into(), value.clone()));
            }
        }
        Ok(json!({"origins": prepared.iter().map(|(id, _, token)| json!({"id":id.0,"instanceId":token})).collect::<Vec<_>>() }))
    })
}
