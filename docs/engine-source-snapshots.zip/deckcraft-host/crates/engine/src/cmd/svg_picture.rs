//! A source SVG and its real rendered preview change as one native command.
use super::{NO_ID_SPACE, bad, base64_decode, str_param};
use crate::{Result, Session};
use deckcraft_model::{Shape, ShapeId, ShapeKind};
use serde_json::{Value, json};
use std::collections::HashSet;

fn decode(p: &Value, key: &str, cmd: &str) -> Result<Vec<u8>> {
    let value = str_param(p, key).ok_or_else(|| bad(cmd, format!("missing {key}")))?;
    if value.len() > crate::svg_media::MAX_BYTES.div_ceil(3) * 4 + 4 {
        return Err(bad(cmd, "SVG/preview encoded input exceeds budget"));
    }
    base64_decode(value).ok_or_else(|| bad(cmd, format!("invalid base64 {key}")))
}
fn pair(p: &Value, cmd: &str) -> Result<(String, Vec<u8>, Vec<u8>)> {
    if p.get("path").is_some() {
        return Err(bad(cmd, "provide embedded SVG and preview bytes, not a path"));
    }
    let name = str_param(p, "name").unwrap_or("original.svg");
    if name.is_empty() || name.len() > 512 {
        return Err(bad(cmd, "invalid SVG name"));
    }
    let svg = decode(p, "data", cmd)?;
    let png = decode(p, "previewData", cmd)?;
    crate::svg_media::admit_svg(&svg).map_err(|e| bad(cmd, e))?;
    crate::svg_media::admit_preview(&png).map_err(|e| bad(cmd, e))?;
    Ok((name.to_string(), svg, png))
}
pub(super) fn insert(s: &mut Session, p: &Value) -> Result<Value> {
    const CMD: &str = "insert.svgPicture";
    let (name, svg, _) = pair(p, CMD)?;
    let mut raster = p.as_object().cloned().ok_or_else(|| bad(CMD, "parameters must be an object"))?;
    let preview = str_param(p, "previewData").ok_or_else(|| bad(CMD, "missing previewData"))?;
    raster.insert("data".into(), Value::String(preview.into()));
    raster.insert("name".into(), Value::String(format!("{name}.preview.png")));
    raster.remove("previewData");
    let result = super::insert::picture_for_svg(s, &Value::Object(raster))?;
    let id = result
        .get("id")
        .and_then(Value::as_u64)
        .and_then(|id| u32::try_from(id).ok())
        .map(ShapeId)
        .ok_or_else(|| bad(CMD, "missing actual inserted picture id"))?;
    s.edit(|doc, selection| {
        let source = doc.add_media(&name, "image/svg+xml", svg).ok_or_else(|| bad(CMD, NO_ID_SPACE))?;
        let shapes = crate::shapes_mut(doc, selection).ok_or_else(|| bad(CMD, "no target tree"))?;
        let shape = deckcraft_model::find_shape_mut(shapes, id).ok_or_else(|| bad(CMD, "inserted SVG picture disappeared"))?;
        let ShapeKind::Picture { fill } = &mut shape.kind else { return Err(bad(CMD, "inserted shape is not a picture")) };
        fill.svg_source = Some(source);
        shape.descr = name.clone();
        Ok(())
    })?;
    Ok(result)
}
fn editable(shapes: &[Shape], id: ShapeId, blocked: bool, depth: usize) -> bool {
    if depth > 64 {
        return false;
    }
    for shape in shapes {
        let blocked = blocked || shape.hidden || shape.locked;
        if shape.id == id {
            return !blocked;
        }
        if let ShapeKind::Group { children, .. } = &shape.kind
            && editable(children, id, blocked, depth + 1)
        {
            return true;
        }
    }
    false
}
pub(super) fn replace(s: &mut Session, p: &Value) -> Result<Value> {
    const CMD: &str = "picture.replaceSvgContent";
    let (name, svg, png) = pair(p, CMD)?;
    let ids = super::targets(s, p)?;
    if ids.is_empty() || ids.len() > 100 || ids.iter().collect::<HashSet<_>>().len() != ids.len() {
        return Err(bad(CMD, "pass one to 100 distinct SVG pictures"));
    }
    let material = super::host_material::request(p, CMD)?;
    let mut work = Vec::new();
    {
        let state = s.doc()?;
        for id in ids {
            if !editable(state.shapes(), id, false, 0) {
                return Err(bad(CMD, "SVG picture or an ancestor is locked, hidden or unavailable"));
            }
            let shape = state.shape(id).ok_or_else(|| bad(CMD, "SVG picture no longer exists"))?;
            let ShapeKind::Picture { fill } = &shape.kind else { return Err(bad(CMD, "target is not an SVG picture")) };
            let original = fill.svg_source.and_then(|id| state.doc.media(id)).ok_or_else(|| bad(CMD, "target has no original SVG"))?;
            let preview = state.doc.media(fill.media).ok_or_else(|| bad(CMD, "target has no preview"))?;
            if original.content_type != "image/svg+xml"
                || original.link.is_some()
                || original.data.is_empty()
                || preview.content_type != "image/png"
                || preview.data.is_empty()
                || preview.link.is_some()
                || fill.artistic.is_some()
            {
                return Err(bad(CMD, "linked, unavailable or artistic SVG content is not admitted for replacement"));
            }
            let origin = material.as_ref().map(|m| super::host_material::prepare(Some(shape), m, true, CMD)).transpose()?;
            work.push((id, origin));
        }
    }
    s.edit(move |doc, selection| {
        let source = doc.add_media(&name, "image/svg+xml", svg).ok_or_else(|| bad(CMD, NO_ID_SPACE))?;
        let preview = doc.add_media(&format!("{name}.preview.png"), "image/png", png).ok_or_else(|| bad(CMD, NO_ID_SPACE))?;
        let shapes = crate::shapes_mut(doc, selection).ok_or_else(|| bad(CMD, "no target tree"))?;
        for (id, origin) in &work {
            let shape = deckcraft_model::find_shape_mut(shapes, *id).ok_or_else(|| bad(CMD, "SVG picture disappeared"))?;
            let ShapeKind::Picture { fill } = &mut shape.kind else { return Err(bad(CMD, "SVG target changed kind")) };
            fill.media = preview;
            fill.svg_source = Some(source);
            if let Some(value) = origin {
                super::host_material::set(shape, value.clone());
            }
        }
        Ok(json!({"ids":work.iter().map(|(id,_)|id.0).collect::<Vec<_>>(),"svg":source.0,"preview":preview.0}))
    })
}
