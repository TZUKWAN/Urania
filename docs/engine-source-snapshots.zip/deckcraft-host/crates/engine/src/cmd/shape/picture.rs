use super::{NO_ID_SPACE, Result, Session, Value, bad, bool_or, bool_param, edit_geometry, edit_shapes, f64_param, json};

pub(super) fn crop(s: &mut Session, p: &Value) -> Result<Value> {
    let c = [f64_param(p, "left"), f64_param(p, "top"), f64_param(p, "right"), f64_param(p, "bottom")];
    edit_geometry(s, p, "picture.crop", |sh| {
        if let deckcraft_model::ShapeKind::Picture { fill } = &mut sh.kind {
            for (i, v) in c.iter().enumerate() {
                if let (Some(v), Some(slot)) = (v, fill.crop.get_mut(i)) {
                    *slot = v.clamp(-10.0, 0.95);
                }
            }
        }
        Ok(())
    })
}

pub(super) fn picture_adjust(s: &mut Session, p: &Value) -> Result<Value> {
    edit_shapes(s, p, "picture.adjust", |sh| {
        if let deckcraft_model::ShapeKind::Picture { fill } = &mut sh.kind {
            let a = &mut fill.adjust;
            if bool_or(p, "reset", false) {
                *a = Default::default();
            }
            if let Some(v) = f64_param(p, "brightness") {
                a.brightness = v.clamp(-1.0, 1.0);
            }
            if let Some(v) = f64_param(p, "contrast") {
                a.contrast = v.clamp(-1.0, 1.0);
            }
            if let Some(v) = f64_param(p, "saturation") {
                a.saturation = Some(v.clamp(0.0, 4.0));
            }
            if let Some(v) = bool_param(p, "grayscale") {
                a.grayscale = v;
            }
            if let Some(v) = f64_param(p, "transparency") {
                fill.alpha = Some((1.0 - v).clamp(0.0, 1.0));
            }
        }
        Ok(())
    })
}

pub(super) fn picture_reset(s: &mut Session, p: &Value) -> Result<Value> {
    edit_shapes(s, p, "picture.reset", |sh| {
        if let deckcraft_model::ShapeKind::Picture { fill } = &mut sh.kind {
            fill.adjust = Default::default();
            fill.crop = [0.0; 4];
            fill.alpha = None;
            if let Some(a) = fill.artistic.take() {
                fill.media = a.original;
            }
        }
        sh.effects = None;
        sh.line = None;
        Ok(())
    })
}

pub(super) fn picture_change(s: &mut Session, p: &Value) -> Result<Value> {
    let (name, bytes) = crate::cmd::insert::media_bytes(p, "picture.change")?;
    let ct = crate::cmd::insert::content_type(&name, &bytes);
    let media = s.edit(|doc, _| doc.add_media(&name, ct, bytes).ok_or_else(|| bad("picture.change", NO_ID_SPACE)))?;
    edit_shapes(s, p, "picture.change", |sh| {
        if let deckcraft_model::ShapeKind::Picture { fill } = &mut sh.kind {
            fill.media = media;
            fill.crop = [0.0; 4];
            fill.artistic = None;
            fill.svg_source = None;
            crate::cmd::host_material::clear(sh);
        }
        Ok(())
    })
}

/// A content-only native edit: never reset crop/effects or recreate the layout object.
pub(super) fn picture_replace_content(s: &mut Session, p: &Value) -> Result<Value> {
    const CMD: &str = "picture.replaceContent";
    let material = crate::cmd::host_material::request(p, CMD)?;
    let ids = crate::cmd::targets(s, p)?;
    if ids.is_empty() || ids.len() > 100 {
        return Err(bad(CMD, "pass one to 100 actual pictures"));
    }
    let (name, bytes) = crate::cmd::insert::media_bytes(p, CMD)?;
    crate::embedded::picture_admission(&bytes, 24_000_000).map_err(|error| bad(CMD, error))?;
    let mut work = Vec::new();
    let mut processed = std::collections::BTreeMap::new();
    {
        let st = s.doc()?;
        for id in &ids {
            let shape = st.shape(*id).ok_or_else(|| bad(CMD, "target picture no longer exists"))?;
            let origin = material.as_ref().map(|m| crate::cmd::host_material::prepare(Some(shape), m, true, CMD)).transpose()?;
            if shape.locked {
                return Err(bad(CMD, "target picture is locked"));
            }
            let deckcraft_model::ShapeKind::Picture { fill } = &shape.kind else {
                return Err(bad(CMD, "every target must be an actual picture"));
            };
            if fill.svg_source.is_some() {
                return Err(bad(CMD, "an SVG picture needs picture.replaceSvgContent; its original SVG was not discarded"));
            }
            let effect = fill.artistic.as_ref().map(|art| art.effect.clone());
            if let Some(effect) = &effect
                && !processed.contains_key(effect) {
                processed.insert(effect.clone(), crate::cmd::artistic::process(effect, &bytes)?);
            }
            work.push((*id, effect, origin));
        }
    }
    let ct = crate::cmd::insert::content_type(&name, &bytes);
    s.edit(move |doc, selection| {
        let original = doc.add_media(&name, ct, bytes).ok_or_else(|| bad(CMD, NO_ID_SPACE))?;
        let mut rendered = std::collections::BTreeMap::new();
        for (effect, data) in processed {
            let id = doc.add_media(&format!("{}-{}.png", name, effect), "image/png", data).ok_or_else(|| bad(CMD, NO_ID_SPACE))?;
            rendered.insert(effect, id);
        }
        let shapes = crate::shapes_mut(doc, selection).ok_or_else(|| bad(CMD, "no native target tree"))?;
        for (id, effect, origin) in &work {
            let shape = deckcraft_model::find_shape_mut(shapes, *id).ok_or_else(|| bad(CMD, "picture disappeared during replacement"))?;
            let deckcraft_model::ShapeKind::Picture { fill } = &mut shape.kind else {
                return Err(bad(CMD, "target changed kind"));
            };
            fill.media = effect.as_ref().and_then(|effect| rendered.get(effect)).copied().unwrap_or(original);
            if let Some(art) = fill.artistic.as_mut() {
                art.original = original;
            }
            if let Some(value) = origin { crate::cmd::host_material::set(shape, value.clone()); }
        }
        Ok(json!({"ids":work.iter().map(|(id,_,_)|id.0).collect::<Vec<_>>(),"media":original.0}))
    })
}

#[cfg(test)]
#[path = "picture_replace_tests.rs"]
mod preserve_tests;

pub(super) fn media_options(s: &mut Session, p: &Value) -> Result<Value> {
    edit_shapes(s, p, "media.options", |sh| {
        if let deckcraft_model::ShapeKind::Media(m) = &mut sh.kind {
            if let Some(v) = bool_param(p, "autoplay") {
                m.autoplay = v;
            }
            if let Some(v) = bool_param(p, "loop") {
                m.loop_play = v;
            }
            if let Some(v) = bool_param(p, "rewind") {
                m.rewind = v;
            }
            if let Some(v) = bool_param(p, "acrossSlides") {
                m.play_across_slides = v;
            }
            if let Some(v) = bool_param(p, "hide") {
                m.hide_while_not_playing = v;
            }
            if let Some(v) = bool_param(p, "fullScreen") {
                m.full_screen = v;
            }
            if let Some(v) = f64_param(p, "volume") {
                m.volume = v.clamp(0.0, 1.0);
            }
            let ms = |k: &str| p.get(k).and_then(Value::as_u64).map(|v| v.min(u32::MAX as u64) as u32);
            if let Some(v) = ms("trimStart") {
                m.trim_start_ms = v;
            }
            if let Some(v) = ms("trimEnd") {
                m.trim_end_ms = v;
            }
            if let Some(v) = ms("fadeIn") {
                m.fade_in_ms = v;
            }
            if let Some(v) = ms("fadeOut") {
                m.fade_out_ms = v;
            }
        }
        Ok(())
    })?;
    Ok(json!({}))
}
