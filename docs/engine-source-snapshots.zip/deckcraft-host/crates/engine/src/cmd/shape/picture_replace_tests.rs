use crate::Session;
use deckcraft_model::{ShapeId, ShapeKind};
use serde_json::{Value, json};
use std::io::Cursor;
use std::sync::Arc;

fn png(color: [u8; 4], w: u32, h: u32) -> Vec<u8> {
    let image = image::RgbaImage::from_fn(w, h, |x, y| {
        image::Rgba([color[0].saturating_add((x % 16) as u8), color[1].saturating_add((y % 16) as u8), color[2], color[3]])
    });
    let mut bytes = Cursor::new(Vec::new());
    image::DynamicImage::ImageRgba8(image).write_to(&mut bytes, image::ImageFormat::Png).unwrap();
    bytes.into_inner()
}
fn fixture(artistic: bool) -> (Session, ShapeId, ShapeId, Vec<u8>) {
    let mut s = Session::new();
    s.execute("file.new", &json!({})).unwrap();
    let original = png([20, 80, 150, 220], 32, 24);
    let id = ShapeId(
        s.execute("insert.picture", &json!({"name":"owned-original.png","data":crate::cmd::base64_encode(&original),"rect":[120,180,240,100]}))
            .unwrap()["id"]
            .as_u64()
            .unwrap() as u32,
    );
    s.execute("picture.crop", &json!({"ids":[id],"left":0.12,"top":0.07,"right":0.18,"bottom":0.09})).unwrap();
    s.execute("picture.adjust", &json!({"ids":[id],"brightness":0.2,"contrast":0.1,"saturation":0.8,"transparency":0.25})).unwrap();
    s.execute("shape.effects", &json!({"ids":[id],"shadow":"outer","softEdges":2})).unwrap();
    if artistic {
        s.execute("picture.artisticEffect", &json!({"ids":[id],"effect":"artisticBlur"})).unwrap();
    }
    let duplicate;
    {
        let st = s.doc_mut().unwrap();
        let p = Arc::make_mut(&mut st.doc);
        let mut picture = p.slides[0].shapes.iter().find(|shape| shape.id == id).unwrap().clone();
        picture.xfrm.as_mut().unwrap().rot = 31.0;
        picture.xfrm.as_mut().unwrap().flip_h = true;
        let ShapeKind::Picture { fill } = &mut picture.kind else { panic!("picture") };
        fill.upright = true;
        duplicate = ShapeId(p.alloc_id().unwrap());
        let mut other = picture.clone();
        other.id = duplicate;
        other.name = "Independent sibling using same media".into();
        other.xfrm.as_mut().unwrap().x = 430.0;
        let group_id = ShapeId(p.alloc_id().unwrap());
        let group = deckcraft_model::Shape {
            id: group_id,
            name: "Owned group".into(),
            xfrm: Some(deckcraft_geom::Xfrm::new(50.0, 50.0, 700.0, 400.0)),
            kind: ShapeKind::Group { children: vec![picture, other], child: deckcraft_geom::Xfrm::new(0.0, 0.0, 700.0, 400.0) },
            ..Default::default()
        };
        Arc::make_mut(&mut p.slides[0]).shapes = vec![group];
        st.selection.shapes = vec![id];
        st.selection.text = None;
    }
    (s, id, duplicate, original)
}
fn find(p: &deckcraft_model::Presentation, id: ShapeId) -> &deckcraft_model::Shape {
    p.slides.iter().find_map(|slide| deckcraft_model::find_shape(&slide.shapes, id)).unwrap()
}
fn normalized(after: &deckcraft_model::Presentation, before: &deckcraft_model::Presentation, id: ShapeId) -> Value {
    let mut result = after.clone();
    result.media = before.media.clone();
    result.next_id = before.next_id;
    let old = find(before, id);
    let new = deckcraft_model::find_shape_mut(&mut Arc::make_mut(&mut result.slides[0]).shapes, id).unwrap();
    let (ShapeKind::Picture { fill: old }, ShapeKind::Picture { fill: new }) = (&old.kind, &mut new.kind) else { panic!("pictures") };
    new.media = old.media;
    if let (Some(old), Some(new)) = (&old.artistic, &mut new.artistic) {
        new.original = old.original;
    }
    serde_json::to_value(&result).unwrap()
}

#[test]
fn content_replacement_preserves_exact_layout_group_crop_style_and_other_use() {
    let (mut s, id, other, original) = fixture(false);
    let before = (*s.doc().unwrap().doc).clone();
    let history = s.doc().unwrap().history.undo.len();
    let replacement = png([150, 20, 30, 200], 48, 16);
    let value =
        s.execute("picture.replaceContent", &json!({"ids":[id],"name":"actual-new.png","data":crate::cmd::base64_encode(&replacement)})).unwrap();
    assert_eq!(value["ids"], json!([id]));
    let after = &s.doc().unwrap().doc;
    assert_eq!(normalized(after, &before, id), serde_json::to_value(&before).unwrap());
    assert_eq!(serde_json::to_value(find(after, other)).unwrap(), serde_json::to_value(find(&before, other)).unwrap());
    let ShapeKind::Picture { fill } = &find(after, id).kind else { panic!("picture") };
    assert_eq!(after.media(fill.media).unwrap().data.as_slice(), replacement.as_slice());
    assert!(after.media.iter().any(|m| m.data.as_slice() == original.as_slice()));
    assert_eq!(s.doc().unwrap().history.undo.len(), history + 1);
    let native = deckcraft_format::save(after).unwrap();
    let reopened = deckcraft_format::load(&native).unwrap();
    assert_eq!(serde_json::to_value(&reopened).unwrap(), serde_json::to_value(after).unwrap());
    let pptx = deckcraft_pptx::export(after).unwrap();
    assert!(deckcraft_pptx::import_checked(&pptx).is_ok());
    s.execute("edit.undo", &json!({})).unwrap();
    assert_eq!(serde_json::to_value(&s.doc().unwrap().doc).unwrap(), serde_json::to_value(&before).unwrap());
}

#[test]
fn existing_artistic_intent_is_reprocessed_from_new_pixels_without_resetting_crop() {
    let (mut s, id, other, _) = fixture(true);
    let before = (*s.doc().unwrap().doc).clone();
    let replacement = png([170, 30, 40, 210], 32, 24);
    s.execute("picture.replaceContent", &json!({"ids":[id],"name":"new-art.png","data":crate::cmd::base64_encode(&replacement)})).unwrap();
    let after = &s.doc().unwrap().doc;
    assert_eq!(normalized(after, &before, id), serde_json::to_value(&before).unwrap());
    let ShapeKind::Picture { fill } = &find(after, id).kind else { panic!("picture") };
    let artistic = fill.artistic.as_ref().unwrap();
    assert_eq!(artistic.effect, "artisticBlur");
    assert_eq!(after.media(artistic.original).unwrap().data.as_slice(), replacement.as_slice());
    let expected = crate::cmd::artistic::process("artisticBlur", &replacement).unwrap();
    assert_eq!(after.media(fill.media).unwrap().data.as_slice(), expected.as_slice());
    assert_eq!(serde_json::to_value(find(after, other)).unwrap(), serde_json::to_value(find(&before, other)).unwrap());
}

#[test]
fn invalid_input_locked_target_and_wrong_identity_are_atomic_refusals() {
    let (mut s, id, _, _) = fixture(false);
    let before = serde_json::to_value(&s.doc().unwrap().doc).unwrap();
    let history = s.doc().unwrap().history.undo.len();
    assert!(
        s.execute("picture.replaceContent", &json!({"ids":[id],"name":"broken.png","data":crate::cmd::base64_encode(b"not a picture")})).is_err()
    );
    assert_eq!(serde_json::to_value(&s.doc().unwrap().doc).unwrap(), before);
    assert_eq!(s.doc().unwrap().history.undo.len(), history);
    let good = crate::cmd::base64_encode(&png([80, 40, 20, 255], 4, 4));
    assert!(s.execute("picture.replaceContent", &json!({"ids":[4294967295u32],"name":"good.png","data":good})).is_err());
    assert_eq!(serde_json::to_value(&s.doc().unwrap().doc).unwrap(), before);
    let st = s.doc_mut().unwrap();
    deckcraft_model::find_shape_mut(&mut Arc::make_mut(&mut Arc::make_mut(&mut st.doc).slides[0]).shapes, id).unwrap().locked = true;
    let locked = serde_json::to_value(&s.doc().unwrap().doc).unwrap();
    assert!(s.execute("picture.replaceContent", &json!({"ids":[id],"name":"good.png","data":good})).is_err());
    assert_eq!(serde_json::to_value(&s.doc().unwrap().doc).unwrap(), locked);
}
