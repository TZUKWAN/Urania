//! Read-only admission for a deliberately small SVG-to-native-shapes subset.
//! It never claims conversion has happened and never replaces the source.
use std::collections::BTreeMap;

use deckcraft_color::Rgba;
use deckcraft_geom::{Affine, BezPath, PathEl, Point, Xfrm};
use deckcraft_model::style::{PictureAdjust, PictureMode};
use deckcraft_model::text::{AutoFit, TextBody};
use deckcraft_model::{ColorRef, CustomPath, Fill, Geom, Line, Shape, ShapeId, ShapeKind};
use quick_xml::events::{BytesStart, Event};
use serde_json::{Value, json};

use super::{bad, targets};
use crate::{Result, Session};

const CMD: &str = "picture.inspectSvgConversion";
const CONVERT: &str = "picture.convertSvgToShapes";
const MAX_ITEMS: usize = 512;
const MAX_PATH_ELEMENTS: usize = 20_000;
const MAX_COORD: f64 = 1_000_000.0;

#[derive(Clone, Debug)]
struct Style {
    fill: Option<Rgba>,
    stroke: Option<Rgba>,
    stroke_width: f64,
    font: Option<String>,
    font_size: f64,
}
impl Default for Style {
    fn default() -> Self {
        Self { fill: Some(Rgba::BLACK), stroke: None, stroke_width: 1.0, font: None, font_size: 16.0 }
    }
}

#[derive(Clone, Debug)]
enum Geometry {
    Path(String),
    Text { x: f64, y: f64, value: String },
}
#[derive(Clone, Debug)]
struct Item {
    name: String,
    geometry: Geometry,
    style: Style,
}
#[derive(Clone, Debug)]
struct Plan {
    view: [f64; 4],
    items: Vec<Item>,
}
struct Frame {
    tag: String,
    style: Style,
    text: Option<TextBuilder>,
}
struct TextBuilder {
    x: f64,
    y: f64,
    tx: f64,
    ty: f64,
    name: String,
    value: String,
    span: bool,
}

fn attrs(e: &BytesStart<'_>, decoder: quick_xml::encoding::Decoder) -> std::result::Result<BTreeMap<String, String>, String> {
    let mut out = BTreeMap::new();
    for a in e.attributes().with_checks(true) {
        let a = a.map_err(|e| e.to_string())?;
        let key = std::str::from_utf8(a.key.as_ref()).map_err(|_| "SVG attribute name is not UTF-8")?.to_string();
        let value = a.decoded_and_normalized_value(quick_xml::XmlVersion::Implicit1_0, decoder).map_err(|e| e.to_string())?.into_owned();
        if key.len() > 128 || value.len() > 1024 * 1024 || out.insert(key, value).is_some() {
            return Err("SVG attributes exceed the supported budget".into());
        }
    }
    Ok(out)
}
fn num(value: &str) -> std::result::Result<f64, String> {
    let value = value.trim();
    let value = value.strip_suffix("px").unwrap_or(value);
    let n = value.parse::<f64>().map_err(|_| "only numeric or px SVG coordinates are supported")?;
    if !n.is_finite() || n.abs() > MAX_COORD {
        return Err("SVG coordinate exceeds the supported budget".into());
    }
    Ok(n)
}
fn required(a: &mut BTreeMap<String, String>, key: &str) -> std::result::Result<f64, String> {
    let value = a.remove(key).ok_or_else(|| format!("missing SVG {key}"))?;
    num(&value)
}
fn optional(a: &mut BTreeMap<String, String>, key: &str, default: f64) -> std::result::Result<f64, String> {
    a.remove(key).map_or(Ok(default), |value| num(&value))
}
fn translation(value: &str) -> std::result::Result<(f64, f64), String> {
    let body = value.trim().strip_prefix("matrix(").and_then(|s| s.strip_suffix(')')).ok_or("only a translation matrix is supported for SVG text")?;
    let values =
        body.split(|c: char| c == ',' || c.is_ascii_whitespace()).filter(|s| !s.is_empty()).map(num).collect::<std::result::Result<Vec<_>, _>>()?;
    let [a, b, c, d, x, y] = values.as_slice() else {
        return Err("SVG text matrix needs six numbers".into());
    };
    if *a != 1.0 || *b != 0.0 || *c != 0.0 || *d != 1.0 {
        return Err("scaled or rotated SVG text is unsupported".into());
    }
    Ok((*x, *y))
}
fn color(value: &str) -> std::result::Result<Option<Rgba>, String> {
    let value = value.trim();
    if value == "none" {
        return Ok(None);
    }
    let color = if value.starts_with('#') { Rgba::from_hex(value) } else { deckcraft_color::preset(value) };
    let color = color.ok_or_else(|| format!("unsupported SVG colour {value}"))?;
    if color.a != 255 {
        return Err("SVG colour transparency requires the original SVG".into());
    }
    Ok(Some(color))
}
fn style(a: &mut BTreeMap<String, String>, parent: &Style) -> std::result::Result<Style, String> {
    let mut result = parent.clone();
    if let Some(v) = a.remove("fill") {
        result.fill = color(&v)?;
    }
    if let Some(v) = a.remove("stroke") {
        result.stroke = color(&v)?;
    }
    if let Some(v) = a.remove("stroke-width") {
        result.stroke_width = num(&v)?;
        if result.stroke_width < 0.0 {
            return Err("negative SVG stroke width".into());
        }
    }
    if let Some(v) = a.remove("font-family") {
        if v.is_empty() || v.len() > 200 {
            return Err("invalid SVG font family".into());
        }
        result.font = Some(v);
    }
    if let Some(v) = a.remove("font-size") {
        result.font_size = num(&v)?;
        if result.font_size <= 0.0 {
            return Err("invalid SVG font size".into());
        }
    }
    for key in ["opacity", "fill-opacity", "stroke-opacity"] {
        if let Some(v) = a.remove(key)
            && num(&v)? != 1.0
        {
            return Err(format!("SVG {key} is not supported"));
        }
    }
    if let Some(v) = a.remove("fill-rule")
        && v != "nonzero"
    {
        return Err("SVG even-odd fill is not supported".into());
    }
    Ok(result)
}
fn common(a: &mut BTreeMap<String, String>) -> std::result::Result<String, String> {
    let name = a.remove("id").unwrap_or_default();
    if name.len() > 200 {
        return Err("SVG element name is too long".into());
    }
    a.remove("data-name");
    Ok(name)
}
fn no_remaining(a: &BTreeMap<String, String>) -> std::result::Result<(), String> {
    if let Some(key) = a.keys().next() { Err(format!("unsupported SVG attribute {key}")) } else { Ok(()) }
}
fn inside(view: [f64; 4], x: f64, y: f64) -> bool {
    x >= view[0] && y >= view[1] && x <= view[0] + view[2] && y <= view[1] + view[3]
}
fn path_checked(d: &str, view: [f64; 4]) -> std::result::Result<(), String> {
    if d.len() > 1024 * 1024 {
        return Err("SVG path exceeds budget".into());
    }
    let path = BezPath::from_svg(d).map_err(|_| "SVG path data is invalid")?;
    if path.elements().is_empty() || path.elements().len() > MAX_PATH_ELEMENTS {
        return Err("SVG path has no geometry or exceeds budget".into());
    }
    let point = |p: Point| p.x.is_finite() && p.y.is_finite() && p.x.abs() <= MAX_COORD && p.y.abs() <= MAX_COORD && inside(view, p.x, p.y);
    for e in path.elements() {
        let valid = match *e {
            PathEl::MoveTo(p) | PathEl::LineTo(p) => point(p),
            PathEl::QuadTo(a, b) => point(a) && point(b),
            PathEl::CurveTo(a, b, c) => point(a) && point(b) && point(c),
            PathEl::ClosePath => true,
        };
        if !valid {
            return Err("SVG path extends outside its viewport or coordinate budget".into());
        }
    }
    Ok(())
}
fn root_view(a: &mut BTreeMap<String, String>) -> std::result::Result<[f64; 4], String> {
    a.remove("xmlns");
    a.remove("xmlns:xlink");
    a.remove("version");
    let view = a.remove("viewBox").ok_or("SVG needs an explicit viewBox")?;
    let values =
        view.split(|c: char| c == ',' || c.is_ascii_whitespace()).filter(|s| !s.is_empty()).map(num).collect::<std::result::Result<Vec<_>, _>>()?;
    let [x, y, w, h] = values.as_slice() else {
        return Err("SVG viewBox needs four numbers".into());
    };
    if *w <= 0.0 || *h <= 0.0 {
        return Err("SVG viewBox has no size".into());
    }
    let width = optional(a, "width", *w)?;
    let height = optional(a, "height", *h)?;
    if width <= 0.0 || height <= 0.0 || (width / height - w / h).abs() > 1e-9 * (1.0 + (w / h).abs()) {
        return Err("SVG viewport aspect ratio requires preserving the original".into());
    }
    if let Some(v) = a.remove("preserveAspectRatio")
        && !matches!(v.as_str(), "xMidYMid meet" | "xMidYMid" | "none")
    {
        return Err("SVG viewport alignment is unsupported".into());
    }
    Ok([*x, *y, *w, *h])
}
fn shape(tag: &str, a: &mut BTreeMap<String, String>, view: [f64; 4]) -> std::result::Result<Geometry, String> {
    let d = match tag {
        "path" => a.remove("d").ok_or("SVG path is missing d")?,
        "rect" => {
            let x = optional(a, "x", 0.0)?;
            let y = optional(a, "y", 0.0)?;
            let w = required(a, "width")?;
            let h = required(a, "height")?;
            if w <= 0.0 || h <= 0.0 || optional(a, "rx", 0.0)? != 0.0 || optional(a, "ry", 0.0)? != 0.0 {
                return Err("rounded or empty SVG rectangle is unsupported".into());
            }
            format!("M {x} {y} L {} {y} L {} {} L {x} {} Z", x + w, x + w, y + h, y + h)
        }
        "circle" => {
            let x = required(a, "cx")?;
            let y = required(a, "cy")?;
            let r = required(a, "r")?;
            if r <= 0.0 {
                return Err("empty SVG circle".into());
            }
            format!("M {} {y} A {r} {r} 0 1 0 {} {y} A {r} {r} 0 1 0 {} {y} Z", x - r, x + r, x - r)
        }
        "ellipse" => {
            let x = required(a, "cx")?;
            let y = required(a, "cy")?;
            let rx = required(a, "rx")?;
            let ry = required(a, "ry")?;
            if rx <= 0.0 || ry <= 0.0 {
                return Err("empty SVG ellipse".into());
            }
            format!("M {} {y} A {rx} {ry} 0 1 0 {} {y} A {rx} {ry} 0 1 0 {} {y} Z", x - rx, x + rx, x - rx)
        }
        "polygon" => {
            let points = a.remove("points").ok_or("SVG polygon is missing points")?;
            let values = points
                .split(|c: char| c == ',' || c.is_ascii_whitespace())
                .filter(|s| !s.is_empty())
                .map(num)
                .collect::<std::result::Result<Vec<_>, _>>()?;
            if values.len() < 6 || values.len() > MAX_PATH_ELEMENTS * 2 || !values.len().is_multiple_of(2) {
                return Err("SVG polygon has invalid or too many points".into());
            }
            let mut pairs = values.chunks_exact(2);
            let first = pairs.next().ok_or("SVG polygon has no points")?;
            let [x, y] = first else {
                return Err("SVG polygon point is incomplete".into());
            };
            let mut out = format!("M {x} {y}");
            for pair in pairs {
                let [x, y] = pair else {
                    return Err("SVG polygon point is incomplete".into());
                };
                out.push_str(&format!(" L {x} {y}"));
            }
            out.push_str(" Z");
            out
        }
        _ => return Err(format!("unsupported SVG element {tag}")),
    };
    path_checked(&d, view)?;
    Ok(Geometry::Path(d))
}
fn parse(bytes: &[u8]) -> std::result::Result<Plan, String> {
    crate::svg_media::admit_svg(bytes)?;
    let text = std::str::from_utf8(bytes).map_err(|_| "SVG is not UTF-8")?;
    let mut reader = quick_xml::Reader::from_str(text.trim_start_matches('\u{feff}'));
    reader.config_mut().check_end_names = true;
    let mut stack: Vec<Frame> = Vec::new();
    let mut view = None;
    let mut items = Vec::new();
    loop {
        let event = reader.read_event().map_err(|e| e.to_string())?;
        let opens = matches!(&event, Event::Start(_));
        match event {
            Event::Start(e) | Event::Empty(e) => {
                let tag = std::str::from_utf8(e.local_name().as_ref()).map_err(|_| "invalid SVG element")?.to_string();
                let mut a = attrs(&e, reader.decoder())?;
                if tag == "tspan" && stack.last().is_some_and(|p| p.tag == "text") {
                    if !opens {
                        return Err("empty SVG text span is unsupported".into());
                    }
                    let parent = stack.last_mut().ok_or("SVG text span has no parent")?;
                    let builder = parent.text.as_mut().ok_or("SVG text span has no text")?;
                    if builder.span || !builder.value.is_empty() {
                        return Err("multiple SVG text spans are unsupported".into());
                    }
                    let x = optional(&mut a, "x", builder.x)?;
                    let y = optional(&mut a, "y", builder.y)?;
                    if x != builder.x || y != builder.y {
                        return Err("independently positioned SVG text spans are unsupported".into());
                    }
                    no_remaining(&a)?;
                    builder.span = true;
                    let st = parent.style.clone();
                    stack.push(Frame { tag, style: st, text: None });
                    continue;
                }
                let parent = stack.last();
                if parent.is_some_and(|p| !matches!(p.tag.as_str(), "svg" | "g")) {
                    return Err("nested SVG content is unsupported".into());
                }
                let mut st = parent.map_or_else(Style::default, |p| p.style.clone());
                if tag == "svg" && parent.is_none() {
                    view = Some(root_view(&mut a)?);
                } else if parent.is_none() || tag == "svg" {
                    return Err("SVG must have one unnested root".into());
                }
                st = style(&mut a, &st)?;
                let name = common(&mut a)?;
                let frame = if matches!(tag.as_str(), "svg" | "g" | "title" | "desc") {
                    no_remaining(&a)?;
                    Frame { tag, style: st, text: None }
                } else if tag == "text" {
                    let x = optional(&mut a, "x", 0.0)?;
                    let y = optional(&mut a, "y", 0.0)?;
                    let (tx, ty) = a.remove("transform").map_or(Ok((0.0, 0.0)), |v| translation(&v))?;
                    if let Some(v) = a.remove("xml:space")
                        && v != "preserve"
                    {
                        return Err("SVG text whitespace mode is unsupported".into());
                    }
                    if st.stroke.is_some() {
                        return Err("outlined SVG text is unsupported".into());
                    }
                    no_remaining(&a)?;
                    Frame { tag, style: st, text: Some(TextBuilder { x, y, tx, ty, name, value: String::new(), span: false }) }
                } else {
                    let geometry = shape(&tag, &mut a, view.ok_or("missing SVG viewBox")?)?;
                    no_remaining(&a)?;
                    items.push(Item { name, geometry, style: st.clone() });
                    if items.len() > MAX_ITEMS {
                        return Err("SVG object count exceeds budget".into());
                    }
                    Frame { tag, style: st, text: None }
                };
                if opens {
                    stack.push(frame);
                } else if frame.text.is_some() {
                    return Err("empty SVG text is unsupported".into());
                }
            }
            Event::End(_) => {
                let frame = stack.pop().ok_or("unmatched SVG end")?;
                if let Some(TextBuilder { x, y, tx, ty, name, value, .. }) = frame.text {
                    if value.is_empty() || value.trim() != value || value.chars().any(char::is_control) || value.contains("  ") {
                        return Err("SVG text whitespace or empty text is unsupported".into());
                    }
                    if !inside(view.ok_or("missing SVG viewBox")?, x + tx, y + ty) {
                        return Err("SVG text lies outside its viewport".into());
                    }
                    items.push(Item { name, geometry: Geometry::Text { x: x + tx, y: y + ty, value }, style: frame.style });
                    if items.len() > MAX_ITEMS {
                        return Err("SVG object count exceeds budget".into());
                    }
                }
            }
            Event::Text(t) => {
                let text = t.decode().map_err(|e| e.to_string())?;
                if stack.last().is_some_and(|f| f.tag == "tspan") {
                    let parent = stack
                        .len()
                        .checked_sub(2)
                        .and_then(|i| stack.get_mut(i))
                        .and_then(|f| f.text.as_mut())
                        .ok_or("SVG text span has no parent text")?;
                    parent.value.push_str(&text);
                    if parent.value.len() > 100_000 {
                        return Err("SVG text exceeds budget".into());
                    }
                } else if let Some(frame) = stack.last_mut() {
                    if let Some(builder) = &mut frame.text {
                        if builder.span && !text.is_empty() {
                            return Err("mixed SVG text spans are unsupported".into());
                        }
                        builder.value.push_str(&text);
                        if builder.value.len() > 100_000 {
                            return Err("SVG text exceeds budget".into());
                        }
                    } else if !matches!(frame.tag.as_str(), "title" | "desc") && !text.trim().is_empty() {
                        return Err("unexpected SVG text".into());
                    }
                } else if !text.trim().is_empty() {
                    return Err("text outside SVG".into());
                }
            }
            Event::GeneralRef(_) | Event::CData(_) | Event::DocType(_) => return Err("SVG entities or CDATA are unsupported for conversion".into()),
            Event::Eof => break,
            _ => {}
        }
    }
    if !stack.is_empty() || items.is_empty() {
        return Err("SVG has no supported visible objects".into());
    }
    Ok(Plan { view: view.ok_or("missing SVG viewBox")?, items })
}

pub(super) fn inspect(s: &mut Session, p: &Value) -> Result<Value> {
    let ids = targets(s, p)?;
    let [id] = ids.as_slice() else {
        return Err(bad(CMD, "select exactly one SVG picture"));
    };
    let state = s.doc()?;
    let shape = state.shape(*id).ok_or_else(|| bad(CMD, "SVG picture no longer exists"))?;
    let ShapeKind::Picture { fill } = &shape.kind else {
        return Err(bad(CMD, "selected object is not a picture"));
    };
    let source = fill.svg_source.and_then(|id| state.doc.media(id)).ok_or_else(|| bad(CMD, "picture has no preserved original SVG"))?;
    if source.content_type != "image/svg+xml" || source.link.is_some() {
        return Err(bad(CMD, "original SVG is unavailable or external"));
    }
    match parse(source.data.as_slice()) {
        Ok(plan) => {
            let paths = plan.items.iter().filter(|i| matches!(i.geometry, Geometry::Path(_))).count();
            let texts = plan.items.len() - paths;
            let eligibility = prepare(s, p).and_then(|(_, frame, plan)| converted_shapes(&plan, frame).map(|_| ()).map_err(|e| bad(CMD, e)));
            let available = eligibility.is_ok();
            let reason = eligibility.err().map(|error| error.to_string());
            let items=plan.items.iter().map(|item|match &item.geometry {
                Geometry::Path(d)=>json!({"name":item.name,"kind":"path","pathBytes":d.len(),"fill":item.style.fill,"stroke":item.style.stroke,"strokeWidth":item.style.stroke_width}),
                Geometry::Text{x,y,value}=>json!({"name":item.name,"kind":"text","x":x,"y":y,"characters":value.chars().count(),"font":item.style.font,"fontSize":item.style.font_size,"fill":item.style.fill}),
            }).collect::<Vec<_>>();
            Ok(
                json!({"analysisOnly":true,"conversionAvailable":available,"basicGeometryRecognized":true,"reason":reason,"objects":plan.items.len(),"paths":paths,"texts":texts,"viewBox":plan.view,"items":items,"warnings":if texts>0{vec!["Editable text can use different font metrics or baselines; the original SVG must be retained"]}else{vec![]}}),
            )
        }
        Err(reason) => {
            Ok(json!({"analysisOnly":true,"conversionAvailable":false,"basicGeometryRecognized":false,"reason":reason,"originalRetained":true}))
        }
    }
}

/// Read the actual original SVG and reject transformations we cannot preserve.
fn prepare(s: &Session, p: &Value) -> Result<(ShapeId, Xfrm, Plan)> {
    let ids = targets(s, p)?;
    let [id] = ids.as_slice() else {
        return Err(bad(CONVERT, "select exactly one SVG picture"));
    };
    let state = s.doc()?;
    let shape = state
        .shapes()
        .iter()
        .find(|shape| shape.id == *id)
        .ok_or_else(|| bad(CONVERT, "only an SVG picture on the current slide's top level is supported"))?;
    if shape.hidden
        || shape.locked
        || shape.ph.is_some()
        || shape.effects.is_some()
        || shape.line.is_some()
        || shape.fill.is_some()
        || shape.style.is_some()
        || shape.text.is_some()
        || shape.click.is_some()
        || shape.hover.is_some()
        || shape.raw_ext.is_some()
    {
        return Err(bad(CONVERT, "picture has hidden, locked, placeholder, effect, outline or link properties; original SVG retained"));
    }
    if !matches!(&shape.geom,Geom::Preset{name,adj} if name=="rect"&&adj.is_empty()) {
        return Err(bad(CONVERT, "nonrectangular picture geometry is unsupported; original SVG retained"));
    }
    let frame = shape
        .xfrm
        .filter(|x| x.is_finite() && x.w > 0.0 && x.h > 0.0 && x.rot == 0.0 && !x.flip_h && !x.flip_v)
        .ok_or_else(|| bad(CONVERT, "rotated, flipped or invalid picture frame is unsupported; original SVG retained"))?;
    let ShapeKind::Picture { fill } = &shape.kind else {
        return Err(bad(CONVERT, "selected object is not a picture"));
    };
    if fill.crop != [0.0; 4]
        || !matches!(&fill.mode,PictureMode::Stretch{fill_rect} if *fill_rect==[0.0;4])
        || fill.alpha.is_some_and(|a| a != 1.0)
        || fill.adjust != PictureAdjust::default()
        || fill.artistic.is_some()
        || fill.upright
    {
        return Err(bad(CONVERT, "cropped, recoloured, transparent or effected pictures are unsupported; original SVG retained"));
    }
    let source = fill.svg_source.and_then(|id| state.doc.media(id)).ok_or_else(|| bad(CONVERT, "picture has no preserved original SVG"))?;
    if source.content_type != "image/svg+xml" || source.link.is_some() {
        return Err(bad(CONVERT, "original SVG is unavailable or external"));
    }
    let plan = parse(source.data.as_slice()).map_err(|reason| bad(CONVERT, format!("{reason}; original SVG retained")))?;
    let sx = frame.w / plan.view[2];
    let sy = frame.h / plan.view[3];
    if !sx.is_finite() || !sy.is_finite() || sx <= 0.0 || sy <= 0.0 || (sx - sy).abs() > 1e-9 * (1.0 + sx.abs().max(sy.abs())) {
        return Err(bad(CONVERT, "nonuniformly scaled SVG pictures are unsupported; original SVG retained"));
    }
    if plan.items.iter().any(|item| item.style.stroke.is_some()) {
        return Err(bad(CONVERT, "SVG strokes are not yet supported; original SVG retained"));
    }
    for item in &plan.items {
        if let Geometry::Path(d) = &item.geometry {
            if item.style.fill.is_none() {
                return Err(bad(CONVERT, "invisible SVG paths are unsupported; original SVG retained"));
            }
            let path = BezPath::from_svg(d).map_err(|_| bad(CONVERT, "SVG path data became invalid"))?;
            let starts = path.elements().iter().filter(|e| matches!(e, PathEl::MoveTo(_))).count();
            let closes = path.elements().iter().filter(|e| matches!(e, PathEl::ClosePath)).count();
            if starts != 1 || closes != 1 || !matches!(path.elements().last(), Some(PathEl::ClosePath)) {
                return Err(bad(CONVERT, "open or compound SVG paths are unsupported; original SVG retained"));
            }
        }
    }
    Ok((*id, frame, plan))
}

fn coordinate(v: f64) -> String {
    let s = format!("{v:.7}");
    let s = s.trim_end_matches('0').trim_end_matches('.');
    if s == "-0" || s.is_empty() { "0".into() } else { s.into() }
}
fn native_path(d: &str, view: [f64; 4]) -> std::result::Result<String, String> {
    let mut path = BezPath::from_svg(d).map_err(|_| "SVG path data became invalid")?;
    path.apply_affine(Affine::translate((-view[0], -view[1])));
    let mut out = String::new();
    for e in path.elements() {
        let part = match *e {
            PathEl::MoveTo(p) => format!("M {} {}", coordinate(p.x), coordinate(p.y)),
            PathEl::LineTo(p) => format!("L {} {}", coordinate(p.x), coordinate(p.y)),
            PathEl::QuadTo(a, b) => format!("Q {} {} {} {}", coordinate(a.x), coordinate(a.y), coordinate(b.x), coordinate(b.y)),
            PathEl::CurveTo(a, b, c) => {
                format!("C {} {} {} {} {} {}", coordinate(a.x), coordinate(a.y), coordinate(b.x), coordinate(b.y), coordinate(c.x), coordinate(c.y))
            }
            PathEl::ClosePath => "Z".into(),
        };
        if !out.is_empty() {
            out.push(' ');
        }
        out.push_str(&part);
        if out.len() > 2 * 1024 * 1024 {
            return Err("native path exceeds budget".into());
        }
    }
    if out.is_empty() {
        return Err("native path is empty".into());
    }
    Ok(out)
}
fn shape_name(item: &Item, index: usize) -> String {
    if item.name.is_empty() { format!("SVG object {}", index + 1) } else { item.name.clone() }
}
fn converted_shapes(plan: &Plan, frame: Xfrm) -> std::result::Result<Vec<Shape>, String> {
    let scale = frame.w / plan.view[2];
    let mut shapes = Vec::with_capacity(plan.items.len());
    for (index, item) in plan.items.iter().enumerate() {
        let name = shape_name(item, index);
        let shape = match &item.geometry {
            Geometry::Path(d) => {
                let path = native_path(d, plan.view)?;
                Shape {
                    name,
                    xfrm: Some(frame),
                    geom: Geom::Custom {
                        paths: vec![CustomPath {
                            w: plan.view[2],
                            h: plan.view[3],
                            d: path,
                            fill: if item.style.fill.is_some() {
                                deckcraft_geom::preset::FillMode::Norm
                            } else {
                                deckcraft_geom::preset::FillMode::None
                            },
                            stroke: false,
                        }],
                    },
                    fill: Some(item.style.fill.map_or(Fill::None, |c| Fill::solid(ColorRef::rgb(c)))),
                    line: Some(Line::none()),
                    ..Default::default()
                }
            }
            Geometry::Text { x, y, value } => {
                let color = item.style.fill.ok_or("invisible SVG text is unsupported")?;
                let font_size = item.style.font_size * scale;
                let left = frame.x + (x - plan.view[0]) * scale;
                let baseline = frame.y + (y - plan.view[1]) * scale;
                let top = baseline - font_size * 0.8;
                let width = frame.x + frame.w - left;
                let height = font_size * 1.5;
                if !font_size.is_finite()
                    || font_size <= 0.0
                    || font_size > 4096.0
                    || !left.is_finite()
                    || !top.is_finite()
                    || top < frame.y
                    || width <= 0.0
                    || height <= 0.0
                {
                    return Err("SVG text frame cannot be safely represented".into());
                }
                let mut text = TextBody::from_text(value);
                text.body.inset_l = Some(0.0);
                text.body.inset_r = Some(0.0);
                text.body.inset_t = Some(0.0);
                text.body.inset_b = Some(0.0);
                text.body.wrap = Some(false);
                text.body.autofit = Some(AutoFit::None);
                let run = text.paragraphs.first_mut().and_then(|p| p.runs.first_mut()).ok_or("SVG text has no editable run")?;
                run.props.size = Some(font_size);
                run.props.fill = Some(Fill::solid(ColorRef::rgb(color)));
                run.props.font = item
                    .style
                    .font
                    .as_ref()
                    .and_then(|f| f.split(',').next())
                    .map(|f| f.trim().trim_matches(['\'', '"']).to_string())
                    .filter(|f| !f.is_empty());
                Shape {
                    name,
                    xfrm: Some(Xfrm::new(left, top, width, height)),
                    geom: Geom::preset("rect"),
                    fill: Some(Fill::None),
                    line: Some(Line::none()),
                    text_box: true,
                    text: Some(text),
                    ..Default::default()
                }
            }
        };
        shapes.push(shape);
    }
    Ok(shapes)
}

pub(super) fn convert(s: &mut Session, p: &Value) -> Result<Value> {
    let (id, frame, plan) = prepare(s, p)?;
    let text_count = plan.items.iter().filter(|item| matches!(item.geometry, Geometry::Text { .. })).count();
    let mut made = converted_shapes(&plan, frame).map_err(|reason| bad(CONVERT, format!("{reason}; original SVG retained")))?;
    s.edit(move |doc,selection|{
        for shape in &mut made {shape.id=ShapeId(doc.alloc_id().ok_or_else(||bad(CONVERT,super::NO_ID_SPACE))?);}
        let ids=made.iter().map(|shape|shape.id).collect::<Vec<_>>();
        let native_shapes=serde_json::to_value(&made).map_err(|_|bad(CONVERT,"cannot record converted native objects"))?;
        if native_shapes.to_string().len()>1024*1024{return Err(bad(CONVERT,"converted native objects exceed the safe receipt budget; original SVG retained"));}
        let list=crate::shapes_mut(doc,selection).ok_or_else(||bad(CONVERT,"no slide available"))?;
        let index=list.iter().position(|shape|shape.id==id).ok_or_else(||bad(CONVERT,"original SVG picture changed"))?;
        let original=list.get_mut(index).ok_or_else(||bad(CONVERT,"original SVG picture disappeared"))?;original.hidden=true;
        list.splice(index+1..index+1,made);
        selection.shapes=ids.clone();selection.text=None;
        Ok(json!({"originalId":id.0,"originalRetained":true,"originalHidden":true,"ids":ids.iter().map(|id|id.0).collect::<Vec<_>>(),"nativeShapes":native_shapes,"textCount":text_count,"warnings":if text_count>0{vec!["Text font metrics and baseline may differ; the original SVG is retained as a hidden picture"]}else{vec![]}}))
    })
}
