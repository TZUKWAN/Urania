//! Source declarations in native add-in tags. The random instance id is an
//! object identity, never a credential or implicit linked-group membership.
use deckcraft_model::Shape;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};

use super::bad;
use crate::{Result, Session};

pub(crate) const TAG: &str = "DSH-MATERIAL-V1";
#[derive(Clone, Deserialize)]
#[serde(deny_unknown_fields, rename_all = "camelCase")]
pub(crate) struct Material {
    schema: u8,
    project_id: String,
    asset_id: String,
}
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields, rename_all = "camelCase")]
struct Stored {
    schema: u8,
    project_id: String,
    asset_id: String,
    instance_id: String,
}
fn name(value: &str, prefix: &str) -> bool {
    value.starts_with(prefix)
        && value.len() > prefix.len()
        && value.len() <= 81
        && value.bytes().all(|c| c.is_ascii_alphanumeric() || matches!(c, b'_' | b'-'))
}
fn read(shape: &Shape) -> Option<Stored> {
    let mut tags = shape.tags.iter().filter(|(key, _)| key.eq_ignore_ascii_case(TAG));
    let (_, value) = tags.next()?;
    if tags.next().is_some() || value.len() > 1024 {
        return None;
    }
    let origin: Stored = serde_json::from_str(value).ok()?;
    (origin.schema == 1
        && name(&origin.project_id, "project-")
        && name(&origin.asset_id, "asset-")
        && origin.instance_id.len() == 32
        && origin.instance_id.bytes().all(|c| c.is_ascii_digit() || (b'a'..=b'f').contains(&c)))
    .then_some(origin)
}
fn instance(cmd: &str) -> Result<String> {
    let mut bytes = [0; 16];
    getrandom::fill(&mut bytes).map_err(|e| bad(cmd, format!("material instance randomness unavailable: {e}")))?;
    Ok(bytes.iter().map(|b| format!("{b:02x}")).collect())
}
pub(crate) fn request(params: &Value, cmd: &str) -> Result<Option<Material>> {
    let Some(value) = params.get("hostMaterial").filter(|v| !v.is_null()) else { return Ok(None) };
    if value.to_string().len() > 1024 {
        return Err(bad(cmd, "hostMaterial exceeds budget"));
    }
    let material: Material = serde_json::from_value(value.clone()).map_err(|_| bad(cmd, "invalid hostMaterial"))?;
    if material.schema != 1 || !name(&material.project_id, "project-") || !name(&material.asset_id, "asset-") {
        return Err(bad(cmd, "invalid material project/asset identity"));
    }
    Ok(Some(material))
}
pub(crate) fn check(shape: &Shape, material: &Material, cmd: &str) -> Result<()> {
    if shape.tags.iter().any(|(key, _)| key.eq_ignore_ascii_case(TAG)) && read(shape).is_none_or(|old| old.project_id != material.project_id) {
        return Err(bad(cmd, "reserved material tag conflicts with this project"));
    }
    Ok(())
}
/// Prepare before document mutation when an insertion has several native stages.
pub(crate) fn prepare(shape: Option<&Shape>, material: &Material, preserve: bool, cmd: &str) -> Result<String> {
    if let Some(shape) = shape {
        check(shape, material, cmd)?;
    }
    let id = match shape.and_then(read).filter(|_| preserve) {
        Some(old) => old.instance_id,
        None => instance(cmd)?,
    };
    serde_json::to_string(&Stored { schema: 1, project_id: material.project_id.clone(), asset_id: material.asset_id.clone(), instance_id: id })
        .map_err(|e| bad(cmd, e.to_string()))
}
pub(crate) fn set(shape: &mut Shape, value: String) {
    if let Some((_, old)) = shape.tags.iter_mut().find(|(key, _)| key.eq_ignore_ascii_case(TAG)) {
        *old = value;
    } else {
        shape.tags.push((TAG.into(), value));
    }
}
pub(crate) fn clear(shape: &mut Shape) {
    shape.tags.retain(|(key, _)| !key.eq_ignore_ascii_case(TAG));
}
/// Called only on newly re-identified copies, inside the native undo transaction.
pub(crate) fn copied(shape: &mut Shape, cmd: &str) -> Result<()> {
    if let Some(mut origin) = read(shape) {
        origin.instance_id = instance(cmd)?;
        let value = serde_json::to_string(&origin).map_err(|e| bad(cmd, e.to_string()))?;
        set(shape, value);
    }
    Ok(())
}
pub(crate) fn assign(session: &mut Session, params: &Value) -> Result<Value> {
    const CMD: &str = "picture.assignMaterialOrigins";
    let rows = params
        .get("origins")
        .and_then(Value::as_array)
        .filter(|rows| !rows.is_empty() && rows.len() <= 100)
        .ok_or_else(|| bad(CMD, "give 1..100 explicit origins"))?;
    let mut prepared = Vec::new();
    let mut seen = std::collections::BTreeSet::new();
    let state = session.doc()?;
    for row in rows {
        let number = row
            .get("id")
            .and_then(Value::as_u64)
            .and_then(|id| u32::try_from(id).ok())
            .ok_or_else(|| bad(CMD, "origin id must be a native shape id"))?;
        let id = deckcraft_model::ShapeId(number);
        if !seen.insert(id) {
            return Err(bad(CMD, "origin ids must be unique"));
        }
        let shape = state.shape(id).ok_or_else(|| bad(CMD, "origin target missing"))?;
        if !matches!(shape.kind, deckcraft_model::ShapeKind::Picture { .. }) {
            return Err(bad(CMD, "origin target is not a picture"));
        }
        let material = request(row, CMD)?.ok_or_else(|| bad(CMD, "origin needs hostMaterial"))?;
        prepared.push((id, prepare(Some(shape), &material, true, CMD)?));
    }
    session.edit(|doc, selection| {
        let shapes = crate::shapes_mut(doc, selection).ok_or_else(|| bad(CMD, "no native picture target tree"))?;
        for (id, value) in &prepared {
            let shape = deckcraft_model::find_shape_mut(shapes, *id).ok_or_else(|| bad(CMD, "origin target moved"))?;
            set(shape, value.clone());
        }
        Ok(json!({"ids":prepared.iter().map(|(id,_)|id.0).collect::<Vec<_>>()}))
    })
}
