//! Bounded, source-preserving imports for a source-owning embedded host.
//!
//! The ordinary desktop readers retain their existing behavior. Here a streaming ZIP
//! admission pass checks every member and CRC before the genuine native/PPTX reader
//! receives the same immutable bytes. No document is added to a Session by this module.
use std::io::{Cursor, Read};
use std::collections::{HashMap, HashSet};
use std::sync::Arc;

use deckcraft_model::{Presentation, Shape, ShapeKind};

#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub encoded_bytes: usize,
    pub archive_entries: usize,
    pub member_bytes: u64,
    pub inflated_bytes: u64,
    pub slides: usize,
    pub shapes: usize,
    pub picture_pixels: u64,
    pub total_picture_pixels: u64,
}

impl Default for Limits {
    fn default() -> Self {
        Self {
            encoded_bytes: 256 << 20,
            archive_entries: 20_000,
            member_bytes: 64 << 20,
            inflated_bytes: 256 << 20,
            slides: 100,
            shapes: 20_000,
            picture_pixels: 24_000_000,
            total_picture_pixels: 48_000_000,
        }
    }
}

#[derive(Debug)]
pub struct Imported {
    pub presentation: Presentation,
    pub warnings: Vec<String>,
}

fn u16_at(bytes: &[u8], at: usize) -> Result<u16, String> {
    let end = at.checked_add(2).ok_or("ZIP field overflow")?;
    let field: [u8; 2] = bytes.get(at..end).ok_or("truncated ZIP field")?.try_into().map_err(|_| "invalid ZIP field")?;
    Ok(u16::from_le_bytes(field))
}

fn u32_at(bytes: &[u8], at: usize) -> Result<u32, String> {
    let end = at.checked_add(4).ok_or("ZIP field overflow")?;
    let field: [u8; 4] = bytes.get(at..end).ok_or("truncated ZIP field")?.try_into().map_err(|_| "invalid ZIP field")?;
    Ok(u32::from_le_bytes(field))
}

/// Refuse excessive central-directory metadata before the ZIP crate allocates it.
fn directory_admission(bytes: &[u8], maximum: usize) -> Result<usize, String> {
    let last = bytes.len().checked_sub(22).ok_or("truncated ZIP directory")?;
    let first = bytes.len().saturating_sub(65_557);
    let mut found = None;
    for at in (first..=last).rev() {
        if bytes.get(at..at.saturating_add(4)) != Some(b"PK\x05\x06") {
            continue;
        }
        let comment = usize::from(u16_at(bytes, at + 20)?);
        if at.checked_add(22).and_then(|end| end.checked_add(comment)) == Some(bytes.len()) {
            found = Some(at);
            break;
        }
    }
    let at = found.ok_or("missing ZIP directory")?;
    if u16_at(bytes, at + 4)? != 0 || u16_at(bytes, at + 6)? != 0 {
        return Err("multi-disk archives are not admitted by the embedded host".into());
    }
    let entries = u16_at(bytes, at + 10)?;
    if entries == u16::MAX
        || u16_at(bytes, at + 8)? != entries
        || at.checked_sub(20).and_then(|start| bytes.get(start..start + 4)) == Some(b"PK\x06\x07")
    {
        return Err("ZIP64 directories are not admitted by the embedded host".into());
    }
    let entries = usize::from(entries);
    if entries == 0 || entries > maximum {
        return Err("ZIP entry count exceeds embedded budget".into());
    }
    let size = u64::from(u32_at(bytes, at + 12)?);
    let offset = u64::from(u32_at(bytes, at + 16)?);
    if offset.checked_add(size).is_none_or(|end| end > at as u64) {
        return Err("ZIP directory range is invalid".into());
    }
    Ok(entries)
}

fn archive_admission(bytes: &[u8], limits: Limits) -> Result<(), String> {
    let maximum = Limits::default();
    if limits.encoded_bytes == 0
        || limits.encoded_bytes > maximum.encoded_bytes
        || limits.archive_entries == 0
        || limits.archive_entries > maximum.archive_entries
        || limits.member_bytes == 0
        || limits.member_bytes > maximum.member_bytes
        || limits.inflated_bytes == 0
        || limits.inflated_bytes > maximum.inflated_bytes
        || limits.slides == 0
        || limits.slides > maximum.slides
        || limits.shapes == 0
        || limits.shapes > maximum.shapes
        || limits.picture_pixels == 0
        || limits.picture_pixels > maximum.picture_pixels
        || limits.total_picture_pixels == 0
        || limits.total_picture_pixels > maximum.total_picture_pixels
    {
        return Err("invalid embedded import limits".into());
    }
    if bytes.is_empty() || bytes.len() > limits.encoded_bytes {
        return Err("encoded presentation exceeds embedded budget".into());
    }
    let entries = directory_admission(bytes, limits.archive_entries)?;
    let mut archive = zip::ZipArchive::new(Cursor::new(bytes)).map_err(|error| format!("ZIP directory: {error}"))?;
    if archive.len() != entries {
        return Err("ZIP directory count is inconsistent".into());
    }
    let mut total = 0u64;
    let mut scratch = [0u8; 16_384];
    for index in 0..archive.len() {
        let mut member = archive.by_index(index).map_err(|error| format!("ZIP entry: {error}"))?;
        let name = member.name().to_ascii_lowercase();
        let member_limit = if name.ends_with(".xml") || name.ends_with(".json") || name.ends_with(".rels") {
            limits.member_bytes.min(8 << 20)
        } else {
            limits.member_bytes
        };
        if member.size() > member_limit {
            return Err("ZIP member exceeds embedded budget".into());
        }
        let remaining = limits.inflated_bytes.checked_sub(total).ok_or("inflated presentation exceeds embedded budget")?;
        if member.size() > remaining {
            return Err("inflated presentation exceeds embedded budget".into());
        }
        let cap = member_limit.min(remaining);
        let mut read = 0u64;
        let mut stream = (&mut member).take(cap.saturating_add(1));
        loop {
            let n = stream.read(&mut scratch).map_err(|error| format!("ZIP entry decode/CRC: {error}"))?;
            if n == 0 {
                break;
            }
            read = read.checked_add(n as u64).ok_or("inflated size overflow")?;
            if read > cap {
                return Err("inflated ZIP member exceeds embedded budget".into());
            }
        }
        total = total.checked_add(read).ok_or("inflated total overflow")?;
    }
    Ok(())
}

fn json_budget(value: &serde_json::Value, depth: usize, left: &mut usize, limits: Limits) -> Result<(), String> {
    if depth > 64 || *left == 0 {
        return Err("native manifest exceeds nesting/node budget".into());
    }
    *left -= 1;
    match value {
        serde_json::Value::Array(items) => {
            if items.len() > 20_000 {
                return Err("native manifest collection exceeds budget".into());
            }
            for item in items {
                json_budget(item, depth + 1, left, limits)?;
            }
        }
        serde_json::Value::Object(fields) => {
            for (name, item) in fields {
                if let Some(items) = item.as_array() {
                    let cap = match name.as_str() {
                        "slides" => limits.slides,
                        "masters" => 100,
                        "layouts" => 512,
                        "shapes" | "children" => limits.shapes,
                        _ => 20_000,
                    };
                    if items.len() > cap {
                        return Err(format!("native manifest collection {name} exceeds budget"));
                    }
                }
                json_budget(item, depth + 1, left, limits)?;
            }
        }
        _ => {}
    }
    Ok(())
}

/// Bound sparse/default model containers before typed deserialization allocates their defaults.
fn native_manifest_admission(bytes: &[u8], limits: Limits) -> Result<(), String> {
    let mut archive = zip::ZipArchive::new(Cursor::new(bytes)).map_err(|error| error.to_string())?;
    let member = archive.by_name("presentation.json").map_err(|error| error.to_string())?;
    let mut data = Vec::new();
    member.take((8 << 20) + 1).read_to_end(&mut data).map_err(|error| error.to_string())?;
    if data.len() > 8 << 20 {
        return Err("native manifest exceeds byte budget".into());
    }
    let value: serde_json::Value = serde_json::from_slice(&data).map_err(|error| error.to_string())?;
    json_budget(&value, 0, &mut 100_000, limits)
}

/// Check real raster headers before a picker or native model admits pixel data.
pub fn picture_admission(bytes: &[u8], pixel_limit: u64) -> Result<(u32, u32), String> {
    if bytes.is_empty() || bytes.len() > 64 * 1024 * 1024 || pixel_limit == 0 || pixel_limit > Limits::default().picture_pixels {
        return Err("embedded picture input exceeds budget".into());
    }
    let mut reader = image::ImageReader::new(Cursor::new(bytes)).with_guessed_format().map_err(|error| error.to_string())?;
    if reader.format().is_none() {
        return Err("this embedded import stage admits raster media only; SVG, fonts, audio and video remain unsupported".into());
    }
    let mut allocation = image::Limits::default();
    allocation.max_alloc = Some(128 << 20);
    reader.limits(allocation);
    let (w, h) = reader.into_dimensions().map_err(|error| format!("embedded picture format/header is not admitted: {error}"))?;
    if w == 0 || h == 0 || w > 16384 || h > 16384 || u64::from(w) * u64::from(h) > pixel_limit {
        return Err("embedded pictures exceed canvas/pixel budget".into());
    }
    Ok((w, h))
}

fn count_shapes(shapes: &[Shape], depth: usize, count: &mut usize, maximum: usize) -> Result<(), String> {
    if depth > 64 {
        return Err("embedded shape hierarchy exceeds depth budget".into());
    }
    for shape in shapes {
        *count = count.checked_add(1).ok_or("shape count overflow")?;
        if *count > maximum {
            return Err("embedded presentation exceeds shape budget".into());
        }
        if let ShapeKind::Group { children, .. } = &shape.kind {
            count_shapes(children, depth + 1, count, maximum)?;
        }
    }
    Ok(())
}

/// Bound compressed input and the decoded audio allocation before the hosted
/// player or source owner can admit a real clip. Headers are inspected without
/// decoding, and an unknown duration cannot claim a bounded PCM allocation.
pub fn media_admission(bytes: &[u8], needs_video: bool) -> Result<u64, String> {
    if bytes.is_empty() || bytes.len() > 64 * 1024 * 1024 {
        return Err("embedded media is empty or exceeds 64 MiB".into());
    }
    let info = deckcraft_media::probe_headers(&Arc::new(bytes.to_vec())).map_err(|error| format!("media header: {error}"))?;
    if info.duration_ms == 0 || info.duration_ms > 2 * 60 * 60 * 1000 {
        return Err("embedded media needs a known duration of at most two hours".into());
    }
    if needs_video && !info.video.as_ref().is_some_and(|video| video.decodable) {
        return Err("this video codec is not supported by the embedded renderer".into());
    }
    if !needs_video && !info.audio.as_ref().is_some_and(|audio| audio.decodable) {
        return Err("this audio codec is not supported by the embedded player".into());
    }
    if let Some(video) = &info.video {
        if !video.decodable || video.width == 0 || video.height == 0 || video.width > 4096 || video.height > 4096
            || u64::from(video.width) * u64::from(video.height) > 8_000_000 || !video.fps.is_finite() || video.fps < 0.0 || video.fps > 120.0
        {
            return Err("embedded video dimensions, rate or codec exceed the supported budget".into());
        }
    }
    let audio_bytes = if let Some(audio) = &info.audio {
        if !audio.decodable || audio.sample_rate == 0 || audio.sample_rate > 192_000 || audio.channels == 0 || audio.channels > 8 {
            return Err("embedded audio format exceeds the supported budget".into());
        }
        u64::from(audio.sample_rate).checked_mul(u64::from(audio.channels)).and_then(|n| n.checked_mul(info.duration_ms))
            .and_then(|n| n.checked_mul(4)).map(|n| n / 1000).ok_or("audio allocation overflow")?
    } else {
        0
    };
    if audio_bytes > 192 * 1024 * 1024 {
        return Err("decoded audio exceeds the embedded memory budget".into());
    }
    Ok(audio_bytes)
}

fn collect_clip_sources(shapes: &[Shape], depth: usize, clips: &mut HashMap<u32, bool>, pictures: &mut HashSet<u32>) -> Result<(), String> {
    if depth > 64 { return Err("embedded media nesting exceeds budget".into()); }
    for shape in shapes {
        {
            let mut picture = |id: &deckcraft_model::MediaId| { pictures.insert(id.0); };
            if let Some(fill) = &shape.fill { crate::media_refs::visit::fill(fill, &mut picture); }
            if let Some(line) = &shape.line { crate::media_refs::visit::line(line, &mut picture); }
        }
        match &shape.kind {
            ShapeKind::Picture { fill } => crate::media_refs::visit::picture(fill, &mut |id| { pictures.insert(id.0); }),
            ShapeKind::Media(clip) => {
                clips.entry(clip.media.0).and_modify(|video| *video |= clip.video).or_insert(clip.video);
                if let Some(poster) = clip.poster { pictures.insert(poster.0); }
            }
            ShapeKind::Group { children, .. } => collect_clip_sources(children, depth + 1, clips, pictures)?,
            _ => {}
        }
    }
    Ok(())
}

/// Check the current native model before an embedded host publishes a source/export.
pub fn model_admission(doc: &Presentation, limits: Limits) -> Result<(), String> {
    if doc.slides.len() > limits.slides {
        return Err("embedded presentation exceeds slide budget".into());
    }
    if doc.masters.len() > 100
        || doc.masters.iter().map(|master| master.layouts.len()).try_fold(0usize, |sum, n| sum.checked_add(n)).is_none_or(|n| n > 512)
    {
        return Err("native master/layout collection exceeds embedded budget".into());
    }
    if !doc.slide_size.width.is_finite()
        || !doc.slide_size.height.is_finite()
        || doc.slide_size.width <= 0.0
        || doc.slide_size.height <= 0.0
        || doc.slide_size.width > 4_000.0
        || doc.slide_size.height > 4_000.0
    {
        return Err("embedded slide dimensions are invalid".into());
    }
    let mut count = 0usize;
    for slide in &doc.slides {
        count_shapes(&slide.shapes, 0, &mut count, limits.shapes)?;
    }
    for master in doc.masters.iter().chain(doc.notes_master.iter()).chain(doc.handout_master.iter()) {
        count_shapes(&master.shapes, 0, &mut count, limits.shapes)?;
        for layout in &master.layouts {
            count_shapes(&layout.shapes, 0, &mut count, limits.shapes)?;
        }
    }
    let svg_sources = crate::svg_media::paired_sources(doc)?;
    let referenced: std::collections::HashSet<_> = crate::media_refs::presentation_media(doc).into_iter().collect();
    let mut clips = HashMap::new();
    let mut pictures = HashSet::new();
    for slide in &doc.slides { collect_clip_sources(&slide.shapes, 0, &mut clips, &mut pictures)?; }
    for master in doc.masters.iter().chain(doc.notes_master.iter()).chain(doc.handout_master.iter()) {
        collect_clip_sources(&master.shapes, 0, &mut clips, &mut pictures)?;
        for layout in &master.layouts { collect_clip_sources(&layout.shapes, 0, &mut clips, &mut pictures)?; }
    }
    if clips.keys().any(|id| pictures.contains(id)) {
        return Err("a media clip cannot also be used as a picture or poster".into());
    }
    if doc.embedded_fonts.len() > 64 { return Err("embedded font family count exceeds budget".into()); }
    let font_ids: HashSet<_> = doc.embedded_fonts.iter().flat_map(|font| font.faces().into_iter().flatten()).collect();
    if font_ids.len() > 256 { return Err("embedded font face count exceeds budget".into()); }
    let mut without_fonts = doc.clone();
    without_fonts.embedded_fonts.clear();
    if crate::media_refs::presentation_media(&without_fonts).iter().any(|id| font_ids.contains(id)) {
        return Err("an embedded font part is also referenced by another media role".into());
    }
    let mut image_pixels = 0u64;
    let mut audio_bytes = 0u64;
    let mut compressed_media = 0u64;
    let mut font_bytes = 0u64;
    let mut admitted_clips = HashSet::new();
    let mut admitted_fonts = HashSet::new();
    let mut seen_media = HashSet::new();
    for media in &doc.media {
        if !seen_media.insert(media.id) { return Err("presentation media contains duplicate identities".into()); }
        if font_ids.contains(&media.id) {
            if media.link.is_some() || media.data.is_empty() || media.data.len() > 32 * 1024 * 1024 {
                return Err("embedded font part is missing or exceeds 32 MiB".into());
            }
            font_bytes = font_bytes.checked_add(media.data.len() as u64).ok_or("font size overflow")?;
            if font_bytes > 64 * 1024 * 1024 { return Err("embedded fonts exceed the total budget".into()); }
            admitted_fonts.insert(media.id);
            continue;
        }
        let media_type = media.content_type.to_ascii_lowercase();
        let needs_video = clips.get(&media.id.0).copied().or_else(|| {
            if media_type.starts_with("audio/") { Some(false) }
            else if media_type.starts_with("video/") { Some(true) }
            else { None }
        });
        if let Some(needs_video) = needs_video {
            if pictures.contains(&media.id.0) { return Err("audio or video bytes cannot also serve as a picture or poster".into()); }
            if media.link.is_some() || media.data.is_empty() { return Err("embedded audio or video must contain its original bytes".into()); }
            compressed_media = compressed_media.checked_add(media.data.len() as u64).ok_or("media size overflow")?;
            audio_bytes = audio_bytes.checked_add(media_admission(&media.data, needs_video)?).ok_or("audio allocation overflow")?;
            if compressed_media > 128 * 1024 * 1024 || audio_bytes > 192 * 1024 * 1024 {
                return Err("presentation media exceeds the embedded total budget".into());
            }
            admitted_clips.insert(media.id.0);
            continue;
        }
        if media.content_type.eq_ignore_ascii_case("image/svg+xml") {
            if referenced.contains(&media.id) && !svg_sources.contains(&media.id) { return Err("SVG picture has no supported embedded PNG preview".into()); }
            if !svg_sources.contains(&media.id) && !media.data.is_empty() { crate::svg_media::admit_svg(&media.data)?; }
            continue;
        }
        if media.data.is_empty() {
            continue;
        }
        let (w, h) = picture_admission(media.data.as_slice(), limits.picture_pixels)?;
        let pixels = u64::from(w) * u64::from(h);
        image_pixels = image_pixels.checked_add(pixels).ok_or("picture pixel budget overflow")?;
        if w == 0 || h == 0 || w > 16_384 || h > 16_384 || pixels > limits.picture_pixels || image_pixels > limits.total_picture_pixels {
            return Err("embedded pictures exceed canvas/pixel budget".into());
        }
    }
    if clips.keys().any(|id| !admitted_clips.contains(id)) { return Err("presentation has a missing embedded media source".into()); }
    if font_ids.iter().any(|id| !admitted_fonts.contains(id)) { return Err("presentation has a missing embedded font part".into()); }
    Ok(())
}

/// Refuse an insertion that would make the current source exceed the same aggregate
/// media budgets required when it is next saved. This checks a detached model: the
/// live presentation is never changed by admission.
pub fn insert_media_admission(doc: &Presentation, bytes: &[u8], needs_video: bool) -> Result<(), String> {
    let next = doc.media.iter().map(|item| item.id.0).max().unwrap_or(0).checked_add(1).ok_or("media identity exhausted")?;
    let mut candidate = doc.clone();
    candidate.media.push(deckcraft_model::MediaItem {
        id: deckcraft_model::MediaId(next),
        name: "pending-media-admission".into(),
        content_type: if needs_video { "video/admission" } else { "audio/admission" }.into(),
        data: Arc::new(bytes.to_vec()),
        link: None,
    });
    model_admission(&candidate, Limits::default())
}

/// Read a native or PPTX presentation using the genuine readers after bounded admission.
/// The caller retains the original bytes and decides when to publish this document to a Session.
pub fn import(name: &str, bytes: &[u8], limits: Limits) -> Result<Imported, String> {
    let ext = name.rsplit_once('.').map(|(_, ext)| ext.to_ascii_lowercase()).ok_or("presentation needs a file extension")?;
    if !matches!(ext.as_str(), "deckcraft" | "slidecraft" | "pptx" | "potx" | "ppsx") {
        return Err("embedded import currently admits native DeckCraft and PPTX-family files only".into());
    }
    source_admission(&ext, bytes, limits)?;
    let (presentation, mut warnings) = if matches!(ext.as_str(), "deckcraft" | "slidecraft") {
        deckcraft_format::load_checked(bytes).map_err(|error| error.to_string())?
    } else {
        deckcraft_pptx::import_checked(bytes).map_err(|error| error.to_string())?
    };
    model_admission(&presentation, limits)?;
    let mut unsupported = HashSet::new();
    for font in &presentation.embedded_fonts {
        if font.faces().into_iter().flatten().any(|id| presentation.media(id).is_some_and(|item| deckcraft_fonts::embedded_sfnt(&item.data).is_none())) {
            unsupported.insert(font.typeface.clone());
        }
    }
    if !unsupported.is_empty() {
        let mut families: Vec<_> = unsupported.into_iter().collect();
        families.sort();
        warnings.push(format!("Some embedded font parts were preserved but cannot be loaded for rendering: {}", families.join(", ")));
    }
    Ok(Imported { presentation, warnings })
}

/// Validate generated archives against the same admission policy used when reopening them.
pub fn source_admission(format: &str, bytes: &[u8], limits: Limits) -> Result<(), String> {
    if !matches!(format, "deckcraft" | "slidecraft" | "pptx" | "potx" | "ppsx") {
        return Err("unadmitted presentation source format".into());
    }
    archive_admission(bytes, limits)?;
    if matches!(format, "deckcraft" | "slidecraft") {
        native_manifest_admission(bytes, limits)?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use deckcraft_model::{ShapeId, Xfrm, defaults, text::TextBody};
    use std::io::Write;
    use std::sync::Arc;

    fn presentation() -> Presentation {
        let mut p = defaults::new_presentation(None);
        let id = p.alloc_id().unwrap();
        let slide = Arc::make_mut(p.slides.first_mut().unwrap());
        slide.notes = TextBody::from_text("Owned embedded-reader QA notes");
        slide.shapes.push(Shape {
            id: ShapeId(id),
            name: "Owned QA rectangle".into(),
            xfrm: Some(Xfrm::new(20.0, 30.0, 120.0, 50.0)),
            text: Some(TextBody::from_text("Native editable QA")),
            ..Default::default()
        });
        p
    }

    #[test]
    fn actual_native_and_pptx_sources_keep_editable_shapes_and_notes() {
        let p = presentation();
        let native = deckcraft_format::save(&p).unwrap();
        let loaded = import("actual.deckcraft", &native, Limits::default()).unwrap();
        assert!(loaded.warnings.is_empty());
        assert_eq!(serde_json::to_value(&loaded.presentation).unwrap(), serde_json::to_value(&p).unwrap());
        let pptx = deckcraft_pptx::export(&p).unwrap();
        let loaded = import("actual.pptx", &pptx, Limits::default()).unwrap();
        assert_eq!(loaded.presentation.slides.len(), p.slides.len());
        let slide = loaded.presentation.slides.first().unwrap();
        assert!(slide.notes.text().contains("Owned embedded-reader QA notes"));
        assert!(slide.shapes.iter().any(|shape| shape.text.as_ref().is_some_and(|text| text.text().contains("Native editable QA"))));
        let mut empty = p.clone();
        empty.slides.clear();
        let native = deckcraft_format::save(&empty).unwrap();
        assert!(import("empty.deckcraft", &native, Limits::default()).unwrap().presentation.slides.is_empty());
    }

    #[test]
    fn encoded_entry_inflation_and_model_budgets_refuse_real_archives() {
        let bytes = deckcraft_format::save(&presentation()).unwrap();
        assert!(import("actual.deckcraft", &bytes, Limits { encoded_bytes: bytes.len() - 1, ..Default::default() }).is_err());
        assert!(import("actual.deckcraft", &bytes, Limits { archive_entries: 1, ..Default::default() }).is_err());
        assert!(import("actual.deckcraft", &bytes, Limits { member_bytes: 64, ..Default::default() }).is_err());
        assert!(import("actual.deckcraft", &bytes, Limits { inflated_bytes: 64, ..Default::default() }).is_err());
        assert!(import("actual.deckcraft", &bytes, Limits { shapes: 1, ..Default::default() }).is_err());
        let mut writer = zip::ZipWriter::new(Cursor::new(Vec::new()));
        writer
            .start_file("presentation.json", zip::write::SimpleFileOptions::default().compression_method(zip::CompressionMethod::Deflated))
            .unwrap();
        writer.write_all(&vec![b' '; 65_536]).unwrap();
        let tiny = writer.finish().unwrap().into_inner();
        assert!(tiny.len() < 1024);
        assert!(import("compressed.deckcraft", &tiny, Limits { member_bytes: 1024, ..Default::default() }).unwrap_err().contains("member"));
    }

    #[test]
    fn malformed_crc_and_zip64_inputs_never_publish_a_document() {
        assert!(import("broken.deckcraft", b"PK", Limits::default()).is_err());
        let mut bytes = deckcraft_format::save(&presentation()).unwrap();
        let at = {
            let mut archive = zip::ZipArchive::new(Cursor::new(&bytes)).unwrap();
            let start = archive.by_name("mimetype").unwrap().data_start() as usize;
            start
        };
        bytes[at] ^= 1;
        assert!(import("corrupt.deckcraft", &bytes, Limits::default()).is_err());
        let mut bytes = deckcraft_format::save(&presentation()).unwrap();
        let at = bytes.windows(4).rposition(|s| s == b"PK\x05\x06").unwrap();
        bytes[at + 10..at + 12].copy_from_slice(&u16::MAX.to_le_bytes());
        assert!(import("zip64.deckcraft", &bytes, Limits::default()).unwrap_err().contains("ZIP64"));
    }

    #[test]
    fn picture_headers_do_not_trust_declared_media_types() {
        let mut p = presentation();
        let mut png = Cursor::new(Vec::new());
        image::DynamicImage::new_rgba8(2, 2).write_to(&mut png, image::ImageFormat::Png).unwrap();
        let payload = png.into_inner();
        let id = deckcraft_model::MediaId(p.alloc_id().unwrap());
        p.media.push(deckcraft_model::MediaItem {
            id,
            name: "owned-qa.png".into(),
            content_type: "application/octet-stream".into(),
            data: Arc::new(payload.clone()),
            link: None,
        });
        let bytes = deckcraft_format::save(&p).unwrap();
        let imported = import("picture.deckcraft", &bytes, Limits::default()).unwrap();
        assert_eq!(imported.presentation.media.first().unwrap().data.as_slice(), payload.as_slice());
        let result = import("picture.deckcraft", &bytes, Limits { picture_pixels: 3, ..Default::default() });
        assert!(result.is_err(), "a mislabeled raster must not bypass the actual pixel budget");
        assert!(import("picture.deckcraft", &bytes, Limits { total_picture_pixels: 3, ..Default::default() }).is_err());
        p.media.first_mut().unwrap().data = Arc::new(b"unadmitted binary payload".to_vec());
        let unknown = deckcraft_format::save(&p).unwrap();
        assert!(import("unknown.deckcraft", &unknown, Limits::default()).unwrap_err().contains("raster media only"));
    }

    #[test]
    fn native_sparse_default_containers_are_bounded_before_model_construction() {
        let mut manifest = serde_json::json!({"format":"deckcraft","version":1,"generator":"Owned sparse-native QA","presentation":presentation()});
        manifest["presentation"]["masters"] = serde_json::json!(vec![serde_json::json!({}); 101]);
        let mut writer = zip::ZipWriter::new(Cursor::new(Vec::new()));
        writer.start_file("mimetype", zip::write::SimpleFileOptions::default()).unwrap();
        writer.write_all(deckcraft_format::MIMETYPE.as_bytes()).unwrap();
        writer
            .start_file("presentation.json", zip::write::SimpleFileOptions::default().compression_method(zip::CompressionMethod::Deflated))
            .unwrap();
        writer.write_all(&serde_json::to_vec(&manifest).unwrap()).unwrap();
        let raw = writer.finish().unwrap().into_inner();
        let error = import("many-masters.deckcraft", &raw, Limits::default()).unwrap_err();
        assert!(error.contains("native manifest collection masters"), "{error}");
    }
}
