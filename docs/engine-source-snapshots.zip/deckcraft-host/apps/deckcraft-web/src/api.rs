//! Lossless browser transport to the same displayed DeckCraft App.
use deckcraft_ui_egui::ControlRequest;
use serde_json::Value;
use std::cell::RefCell;
use std::sync::mpsc::{Receiver, Sender, TryRecvError};
use wasm_bindgen::prelude::*;

type Waiting = (Receiver<Value>, js_sys::Function, js_sys::Function);
type Inbox = std::sync::Arc<std::sync::Mutex<Vec<(String, Vec<u8>)>>>;
thread_local! {
    static TX: RefCell<Option<Sender<ControlRequest>>> = const { RefCell::new(None) };
    static WAITING: RefCell<Vec<Waiting>> = const { RefCell::new(Vec::new()) };
    static CTX: RefCell<Option<egui::Context>> = const { RefCell::new(None) };
    static INBOX: RefCell<Option<Inbox>> = const { RefCell::new(None) };
}

pub fn connect(tx: Sender<ControlRequest>, inbox: Inbox, ctx: egui::Context) {
    TX.with(|slot| *slot.borrow_mut() = Some(tx));
    INBOX.with(|slot| *slot.borrow_mut() = Some(inbox));
    CTX.with(|slot| *slot.borrow_mut() = Some(ctx));
}
fn repaint() {
    CTX.with(|slot| {
        if let Some(ctx) = slot.borrow().as_ref() {
            ctx.request_repaint();
        }
    });
}
pub fn poll_replies() {
    WAITING.with(|slot| {
        slot.borrow_mut().retain(|(rx, resolve, reject)| match rx.try_recv() {
            Ok(reply) => {
                if reply.get("ok").and_then(Value::as_bool) == Some(true) {
                    // Do not send uint64 fields through JavaScript JSON.parse. The host
                    // decodes exact integer tokens from this original Rust JSON string.
                    let text = reply.get("result").unwrap_or(&Value::Null).to_string();
                    let _ = resolve.call1(&JsValue::NULL, &JsValue::from_str(&text));
                } else {
                    let error = reply.get("error").and_then(Value::as_str).unwrap_or("native operation failed");
                    let _ = reject.call1(&JsValue::NULL, &js_sys::Error::new(error));
                }
                false
            }
            Err(TryRecvError::Empty) => true,
            Err(TryRecvError::Disconnected) => {
                let _ = reject.call1(&JsValue::NULL, &js_sys::Error::new("native request was dropped"));
                false
            }
        })
    });
}
fn request_json(method: String, text: String) -> js_sys::Promise {
    if method.is_empty() || method.len() > 128 || text.len() > 8 * 1024 * 1024 {
        return js_sys::Promise::reject(&js_sys::Error::new("native request exceeds its method/JSON budget"));
    }
    let params = match serde_json::from_str::<Value>(&text) {
        Ok(value) if value.is_object() => value,
        _ => return js_sys::Promise::reject(&js_sys::Error::new("native parameters must be a JSON object")),
    };
    let result = js_sys::Promise::new(&mut |resolve, reject| {
        if WAITING.with(|slot| slot.borrow().len() >= 16) {
            let _ = reject.call1(&JsValue::NULL, &js_sys::Error::new("native request queue is full"));
            return;
        }
        let (request, receiver) = ControlRequest::new(method.clone(), params.clone());
        if TX.with(|slot| slot.borrow().as_ref().is_some_and(|tx| tx.send(request).is_ok())) {
            WAITING.with(|slot| slot.borrow_mut().push((receiver, resolve, reject)));
        } else {
            let _ = reject.call1(&JsValue::NULL, &js_sys::Error::new("DeckCraft has not started"));
        }
    });
    repaint();
    result
}
fn open_file(name: String, bytes: js_sys::Uint8Array) -> bool {
    if name.is_empty() || name.len() > 960 || name.contains(['/', '\\', '\0']) || bytes.length() == 0 || bytes.length() > 256 * 1024 * 1024 {
        return false;
    }
    let queued = INBOX.with(|slot| {
        slot.borrow().as_ref().is_some_and(|inbox| {
            let mut files = inbox.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
            if !files.is_empty() {
                return false;
            }
            files.push((name, bytes.to_vec()));
            true
        })
    });
    repaint();
    queued
}
/// Register an explicit project font in this web editor only.
fn add_project_font(bytes: js_sys::Uint8Array) -> Result<JsValue, JsValue> {
    if bytes.length() == 0 || bytes.length() > 4 * 1024 * 1024 || CTX.with(|ctx| ctx.borrow().is_none()) {
        return Err(js_sys::Error::new("project font is empty, too large, or editor is not ready").into());
    }
    let faces = deckcraft_fonts::FontDb::global().add_font(bytes.to_vec());
    if faces == 0 {
        return Err(js_sys::Error::new("font is invalid or its family and style are already present").into());
    }
    repaint();
    Ok(JsValue::from_f64(faces as f64))
}
pub fn install() -> Result<(), JsValue> {
    let object = js_sys::Object::new();
    let set = |name: &str, value: JsValue| js_sys::Reflect::set(&object, &JsValue::from_str(name), &value).map(|_| ());
    set("addProjectFont", Closure::<dyn Fn(js_sys::Uint8Array) -> Result<JsValue, JsValue>>::new(add_project_font).into_js_value())?;
    set("requestJson", Closure::<dyn Fn(String, String) -> js_sys::Promise>::new(request_json).into_js_value())?;
    set("openFile", Closure::<dyn Fn(String, js_sys::Uint8Array) -> bool>::new(open_file).into_js_value())?;
    set(
        "captureDownloads",
        Closure::<dyn Fn(bool) -> Result<(), JsValue>>::new(|capture| {
            if capture { Err(js_sys::Error::new("in-memory download capture is unsupported; use native source snapshots").into()) } else { Ok(()) }
        })
        .into_js_value(),
    )?;
    let window = web_sys::window().ok_or("no browser window")?;
    js_sys::Reflect::set(window.as_ref(), &JsValue::from_str("deckcraft"), &object)?;
    Ok(())
}
