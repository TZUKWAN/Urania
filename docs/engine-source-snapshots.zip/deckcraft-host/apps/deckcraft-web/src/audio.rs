//! Browser audio output for DeckCraft's real media mixer. The callback and
//! AudioContext belong to the web surface and are released when playback ends.
use deckcraft_engine::media::AudioOut;
use wasm_bindgen::JsCast as _;
use wasm_bindgen::closure::Closure;

type Process = Closure<dyn FnMut(web_sys::AudioProcessingEvent)>;
type Unlock = Closure<dyn FnMut(web_sys::Event)>;

#[derive(Default)]
pub struct WebAudioOut {
    context: Option<web_sys::AudioContext>,
    node: Option<web_sys::ScriptProcessorNode>,
    process: Option<Process>,
    unlock: Option<Unlock>,
}

impl AudioOut for WebAudioOut {
    fn start(&mut self, mut fill: Box<dyn FnMut(&mut [f32], usize, u32) + Send>) -> Result<(), String> {
        self.stop();
        let context = web_sys::AudioContext::new().map_err(|error| format!("audio context: {error:?}"))?;
        let mut staged = WebAudioOut::default();
        staged.context = Some(context.clone());
        let rate = context.sample_rate();
        if !rate.is_finite() || !(8_000.0..=192_000.0).contains(&rate) {
            return Err("browser audio sample rate is outside the supported budget".into());
        }
        let node = context.create_script_processor_with_buffer_size_and_number_of_input_channels_and_number_of_output_channels(4096, 0, 2)
            .map_err(|error| format!("audio output: {error:?}"))?;
        staged.node = Some(node.clone());
        let callback = Closure::<dyn FnMut(web_sys::AudioProcessingEvent)>::new(move |event: web_sys::AudioProcessingEvent| {
            let Ok(output) = event.output_buffer() else { return };
            let frames = output.length() as usize;
            let channels = output.number_of_channels() as usize;
            if frames == 0 || frames > 16_384 || channels == 0 || channels > 8 { return; }
            let mut samples = vec![0.0f32; frames * channels];
            fill(&mut samples, channels, rate as u32);
            for channel in 0..channels {
                let mut planar = vec![0.0f32; frames];
                for frame in 0..frames { planar[frame] = samples[frame * channels + channel]; }
                if output.copy_to_channel(&planar, channel as i32).is_err() { return; }
            }
        });
        node.set_onaudioprocess(Some(callback.as_ref().unchecked_ref()));
        staged.process = Some(callback);
        node.unchecked_ref::<web_sys::AudioNode>()
            .connect_with_audio_node(context.destination().unchecked_ref::<web_sys::AudioNode>())
            .map_err(|error| format!("connect audio output: {error:?}"))?;
        let window = web_sys::window().ok_or("no browser window for audio")?;
        let resume_context = context.clone();
        let unlock = Closure::<dyn FnMut(web_sys::Event)>::new(move |_| { let _ = resume_context.resume(); });
        staged.unlock = Some(unlock);
        let handler = staged.unlock.as_ref().ok_or("audio gesture handler missing")?;
        window.add_event_listener_with_callback("pointerdown", handler.as_ref().unchecked_ref()).map_err(|error| format!("audio gesture: {error:?}"))?;
        window.add_event_listener_with_callback("keydown", handler.as_ref().unchecked_ref()).map_err(|error| format!("audio gesture: {error:?}"))?;
        let _ = context.resume();
        *self = staged;
        Ok(())
    }

    fn stop(&mut self) {
        if let Some(node) = self.node.take() {
            node.set_onaudioprocess(None);
            let _ = node.unchecked_ref::<web_sys::AudioNode>().disconnect();
        }
        if let (Some(window), Some(unlock)) = (web_sys::window(), self.unlock.take()) {
            let _ = window.remove_event_listener_with_callback("pointerdown", unlock.as_ref().unchecked_ref());
            let _ = window.remove_event_listener_with_callback("keydown", unlock.as_ref().unchecked_ref());
        }
        self.process = None;
        if let Some(context) = self.context.take() { let _ = context.close(); }
    }

    fn failure(&mut self) -> Option<String> {
        self.context.as_ref().filter(|context| context.state() == web_sys::AudioContextState::Closed).map(|_| "browser audio context closed".into())
    }
}

impl Drop for WebAudioOut {
    fn drop(&mut self) { self.stop(); }
}
