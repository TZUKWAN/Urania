//! Source-owning embedding of the genuine Deck App and its native page/selection model.
use super::{ControlRequest, Outcome, err, ok};
use crate::{SlideApp, state::ViewMode, theme::Brightness};
use deckcraft_engine::{DocState, Target};
use deckcraft_model::{Shape, ShapeKind};
use serde_json::{Value, json};

#[derive(Default)]
pub(crate) struct HostState {
    pub embedded: bool,
    pub file_routing: bool,
    pub theme_override: Option<Brightness>,
    original_theme: Option<Brightness>,
    original_presenter: Option<bool>,
    next_context: u64,
    next_file: u64,
    pub pending_file: Option<Value>,
    pub opening: bool,
    pub open_error: Option<String>,
    pub open_warnings: Vec<String>,
}

fn pending(app: &SlideApp) -> bool {
    app.session.tool.dragging()
        || app.dialog.is_some()
        || app.opening.is_some()
        || app.palette.is_some()
        || app
            .session
            .active()
            .is_some_and(|doc| doc.interaction.is_some() || doc.composition.is_some() || (app.notes_buf.0 == doc.uid && app.notes_buf.2.edited))
}

fn summaries(shapes: &[Shape], depth: usize, left: &mut usize, limited: &mut bool) -> Vec<Value> {
    let count = 50.min(*left).min(shapes.len());
    *limited |= shapes.len() > count;
    let mut result = Vec::new();
    for shape in shapes.iter().take(count) {
        if *left == 0 {
            *limited = true;
            break;
        }
        *left -= 1;
        *limited |= shape.name.chars().count() > 200;
        let text = shape.text.as_ref().map(|text| text.text());
        let mut value = json!({"id":shape.id,"name":shape.name.chars().take(200).collect::<String>(),
            "kind":shape.kind_name(),"hidden":shape.hidden,"localTransform":shape.xfrm});
        if let Some(text) = text {
            let length = text.chars().count();
            value["textPreview"] = json!(text.chars().take(512).collect::<String>());
            value["textLength"] = json!(length);
            *limited |= length > 512;
        }
        if let ShapeKind::Group { children, .. } = &shape.kind {
            value["childCount"] = json!(children.len());
            if depth < 2 {
                value["children"] = json!(summaries(children, depth + 1, left, limited));
            } else {
                *limited |= !children.is_empty();
            }
        }
        result.push(value);
    }
    result
}

fn page(doc: &DocState) -> Value {
    let p = &doc.doc;
    let size = if doc.selection.target.is_page_master() { p.notes_size } else { p.slide_size };
    let identity = match doc.selection.target {
        Target::Slides => json!({"kind":"slide","id":doc.current_slide().map(|slide|slide.id),"index":doc.selection.slide}),
        Target::Master { master } => json!({"kind":"master","id":p.masters.get(master).map(|master|master.id),"index":master}),
        Target::Layout { master, layout } => json!({"kind":"layout","masterId":p.masters.get(master).map(|master|master.id),
            "id":p.masters.get(master).and_then(|master|master.layouts.get(layout)).map(|layout|layout.id),"master":master,"index":layout}),
        Target::Handout => json!({"kind":"handoutMaster","id":p.handout_master.as_ref().map(|master|master.id)}),
        Target::NotesMaster => json!({"kind":"notesMaster","id":p.notes_master.as_ref().map(|master|master.id)}),
    };
    json!({"target":doc.selection.target,"nativePage":identity,"width":size.width,"height":size.height})
}

fn document(app: &mut SlideApp) -> Result<Value, String> {
    let doc = app.session.active().ok_or("no native presentation open")?;
    let selection = serde_json::to_value(&doc.selection).map_err(|error| error.to_string())?;
    let tool = &app.session.tool;
    let tool = json!({"kind":tool.kind,"sticky":tool.sticky,"editPoints":tool.edit_points,"editVertex":tool.edit_vertex,
        "editSegment":tool.edit_segment,"editSegmentT":tool.edit_segment_t,"vertexKind":tool.vertex_kind,
        "view":app.ui.view,"notes":app.ui.notes,"formatTab":app.ui.format_tab,"smartartRow":app.ui.smartart_row});
    let mut page = page(doc);
    let notes_text = doc.selection.text.as_ref().is_some_and(|text| text.notes);
    if doc.selection.target == Target::Slides && (app.ui.view == ViewMode::NotesPage || notes_text) {
        page["nativePage"]["kind"] = json!(if notes_text { "slideNotes" } else { "notesPage" });
        page["width"] = json!(doc.doc.notes_size.width);
        page["height"] = json!(doc.doc.notes_size.height);
    }
    let stamp = serde_json::to_string(&json!({"selection":selection,"tool":tool,"page":page})).map_err(|error| error.to_string())?;
    if stamp.len() > 512 * 1024 {
        return Err("native presentation context exceeds budget".into());
    }
    let next = app.hosted.next_context.checked_add(1).ok_or("native context sequence exhausted")?;
    let mut limited = false;
    let layers = summaries(doc.shapes(), 0, &mut 200, &mut limited);
    let history: Vec<&str> = doc.history.undo.iter().map(|entry| entry.label.as_str()).collect();
    let redo: Vec<&str> = doc.history.redo.iter().map(|entry| entry.label.as_str()).collect();
    let slides: Vec<Value> = doc
        .doc
        .slides
        .iter()
        .enumerate()
        .take(100)
        .map(|(index, slide)| json!({"index":index,"id":slide.id,"title":slide.title().chars().take(200).collect::<String>(),"hidden":slide.hidden}))
        .collect();
    limited |= doc.doc.slides.len() > slides.len();
    let result = json!({"engine":"deckcraft","contextProtocol":2,"contextSequence":next,
        "uid":doc.uid,"identityKind":"native-document-instance-uid","revision":doc.revision,"title":doc.title(),
        "width":doc.doc.slide_size.width,"height":doc.doc.slide_size.height,"dirty":doc.is_dirty(),
        "objectIds":if notes_text {Vec::new()} else {doc.selection.shapes.clone()},"nativeSelection":{"kind":"deckcraft","data":{"selection":selection}},
        "selectionStamp":stamp,"toolContext":tool,"page":page,"coordinateSpace":if notes_text {"notes-text"} else {"page-points"},
        "layers":layers,"slides":slides,"slideCount":doc.doc.slides.len(),"history":history,"redo":redo,
        "summaryLimited":limited,"pendingInteraction":pending(app),"openWarnings":app.hosted.open_warnings});
    app.hosted.next_context = next;
    Ok(result)
}

fn base(app: &mut SlideApp, params: &Value) -> Result<Value, String> {
    if pending(app) {
        return Err("finish the native gesture, text composition, notes draft or dialog first".into());
    }
    let current = document(app)?;
    let before = params.get("base").ok_or("native action requires the complete current base")?;
    for field in ["uid", "revision", "engine", "selectionStamp"] {
        if before.get(field).is_none() || before.get(field) != current.get(field) {
            return Err(if crate::host_ui::is_embedded() { format!("原生内容冲突：{field} 已改变") } else { format!("native conflict: {field} changed") });
        }
    }
    Ok(current)
}

fn encoded(app: &SlideApp, format: &str) -> Result<Value, String> {
    if pending(app) {
        return Err("native interaction is still pending; no intermediate source was exported".into());
    }
    let doc = app.session.active().ok_or("no native presentation open")?;
    deckcraft_engine::embedded::model_admission(&doc.doc, Default::default())?;
    let bytes = match format {
        "deckcraft" | "pptx" => deckcraft_engine::cmd::file::save_bytes(&doc.doc, format).map_err(|error| error.to_string())?,
        "png" => {
            if doc.selection.target != Target::Slides
                || app.ui.view == ViewMode::NotesPage
                || doc.selection.text.as_ref().is_some_and(|text| text.notes)
            {
                return Err("select a slide before exporting its PNG".into());
            }
            if doc.current_slide().is_none() {
                return Err("this presentation has no current slide to export".into());
            }
            let width = doc.doc.slide_size.width.ceil();
            let height = doc.doc.slide_size.height.ceil();
            if width * height > 24_000_000.0 {
                return Err("slide PNG exceeds embedded canvas budget".into());
            }
            let (bytes, _, _) = deckcraft_engine::cmd::file::render_png(&doc.doc, doc.selection.slide, 1.0, false);
            if !bytes.starts_with(b"\x89PNG\r\n\x1a\n") {
                return Err("native slide rendering did not produce a PNG".into());
            }
            bytes
        }
        _ => return Err("this Deck host currently exports deckcraft, PPTX or slide PNG".into()),
    };
    if bytes.is_empty() || bytes.len() > 256 * 1024 * 1024 {
        return Err("native export exceeds embedded byte budget".into());
    }
    if format != "png" {
        deckcraft_engine::embedded::source_admission(format, &bytes, Default::default())?;
    }
    Ok(json!({"dataBase64":deckcraft_engine::cmd::base64_encode(&bytes),"warnings":Vec::<String>::new()}))
}

pub(crate) fn intercept(app: &mut SlideApp, id: &str, params: &Value) -> Option<Result<Value, String>> {
    if !app.hosted.file_routing {
        return None;
    }
    let action = match id {
        "app.recognizeInkText" => "local_ink_text",
        "app.recognizeInkMath" => "local_ink_math",
        "app.captureScreenshot" => "local_screenshot",
        "app.recordNarration" => "local_narration",
        "app.captureCamera" => "local_camera",
        "file.new" => "new",
        "file.open" | "file.openBytes" | "app.openDialog" => "open",
        "file.save" => "save",
        "file.saveAs" | "app.saveAsDialog" => "save_as",
        "file.saveCopy" => "save_copy",
        "file.close" | "file.closeAll" | "app.closePresentation" | "app.quit" => "close",
        "file.revert" => "revert",
        "app.home" => "works",
        "app.backstage" => match params.get("page").and_then(Value::as_str).unwrap_or("home") {
            "new" => "new",
            "open" => "open",
            "saveAs" => "save_as",
            "home" => "works",
            _ => return None,
        },
        "file.export" | "app.exportDialog" => return Some(Err("use the workspace Export menu, which saves the current source first".into())),
        "view.newWindow" => return Some(Err("additional native viewports are not admitted by this source-owning host yet".into())),
        // Audio/video use the bounded browser picker and the captured native
        // slide target, just like hosted picture insertion. Their decoded bytes
        // are admitted again before they can mutate the presentation.
        "app.reuseSlidesDialog" | "app.browseThemeDialog" | "app.compareDialog" => {
            return Some(Err("this advanced native input is not connected to the source-owning workspace yet".into()));
        }
        _ if id.starts_with("file.") => return Some(Err("this advanced file action is not connected to the source-owning workspace yet".into())),
        _ => return None,
    };
    if app.hosted.pending_file.is_some() {
        return Some(Err("finish the current workspace file action first".into()));
    }
    let next = match app.hosted.next_file.checked_add(1) {
        Some(next) => next,
        None => return Some(Err("native file request sequence exhausted".into())),
    };
    let doc = app.session.active();
    app.hosted.pending_file = Some(json!({"id":next,"action":action,"uid":doc.map(|doc|doc.uid),
        "revision":doc.map(|doc|doc.revision),"title":doc.map(|doc|doc.title()),"params":params}));
    app.hosted.next_file = next;
    Some(Ok(json!({"queued":true,"id":next})))
}

pub(super) fn handle(app: &mut SlideApp, _ctx: &egui::Context, request: &ControlRequest) -> Option<Outcome> {
    let p = &request.params;
    Some(match request.method.as_str() {
        "host.protocol" => ok(json!({"protocol":1,"engine":"deckcraft","nativeContext":2,"contextOrdering":true,
            "losslessJson":true,"selectionKind":"deckcraft","identityKind":"native-document-instance-uid",
            "guardedExecute":true,"atomicSnapshot":true,"atomicBundle":true,"saveAcknowledgement":true,"hostPresentation":true,"hostFileRouting":true,"localInkRecognition":true,"localCaptureInputs":true,"preservePictureReplacement":true,"atomicMaterialOrigins":true,"preparedSvgPictures":true,"preserveSvgPictureReplacement":true,"convertSimpleSvgToShapes":true,"brandColorIdentity":true,"brandFontIdentity":true,"fontLatinEastAsian":true})),
        "host.context" => match document(app) {
            Ok(doc) => ok(doc),
            Err(error) => err(error),
        },
        "host.configure" => {
            let Some(embedded) = p.get("embedded").and_then(Value::as_bool) else {
                return Some(err("embedded must be boolean"));
            };
            let brightness = match p.get("brightness").and_then(Value::as_str).unwrap_or("mediumDark") {
                "light" => Brightness::Light,
                "mediumDark" => Brightness::Dark,
                _ => return Some(err("unknown hosted brightness")),
            };
            let routing = match p.get("fileRouting") {
                Some(Value::Bool(value)) => *value && embedded,
                None => embedded,
                _ => return Some(err("fileRouting must be boolean")),
            };
            if app.hosted.pending_file.is_some() && !routing {
                return Some(err("finish the native file request first"));
            }
            if embedded && !app.hosted.embedded {
                // The embedded browser has one viewport. Start with the
                // audience slide visible; the person can still enable the
                // presenter view explicitly within this session.
                app.hosted.original_presenter = Some(app.ui.presenter_view);
                app.ui.presenter_view = false;
            } else if !embedded && app.hosted.embedded {
                if let Some(original) = app.hosted.original_presenter.take() { app.ui.presenter_view = original; }
            }
            if embedded && app.hosted.original_theme.is_none() {
                app.hosted.original_theme = Some(app.ui.brightness);
            }
            app.hosted.embedded = embedded;
            app.hosted.file_routing = routing;
            app.hosted.theme_override = embedded.then_some(brightness);
            app.ui.brightness = if embedded { brightness } else { app.hosted.original_theme.take().unwrap_or(brightness) };
            app.restyle = true;
            ok(json!({"embedded":embedded,"brightness":app.ui.brightness}))
        }
        "host.create" => {
            if !app.session.documents().is_empty() {
                return Some(err("this native App already owns a presentation"));
            }
            let width = p.get("width").and_then(Value::as_f64).unwrap_or(960.0);
            let height = p.get("height").and_then(Value::as_f64).unwrap_or(540.0);
            if !width.is_finite() || !height.is_finite() || width < 1.0 || height < 1.0 || width > 4000.0 || height > 4000.0 {
                return Some(err("native slide size exceeds its editable source range"));
            }
            let routing = app.hosted.file_routing;
            app.hosted.file_routing = false;
            let mut params = p.clone();
            params["size"] = json!([width, height]);
            let result = app.run("file.new", params);
            app.hosted.file_routing = routing;
            if let Err(error) = result {
                return Some(err(error));
            }
            if let Some(doc) = app.session.active_mut() {
                doc.title = p.get("name").and_then(Value::as_str).unwrap_or("New presentation").chars().take(200).collect();
            }
            app.backstage = None;
            match document(app) {
                Ok(doc) => ok(json!({"document":doc})),
                Err(error) => err(error),
            }
        }
        "host.execute" => {
            if let Err(error) = base(app, p) {
                return Some(err(error));
            }
            let Some(command) = p.get("command").and_then(Value::as_str).filter(|s| !s.is_empty() && s.len() <= 256) else {
                return Some(err("missing native command"));
            };
            if command.starts_with("file.") || command.starts_with("app.") {
                return Some(err("native document lifecycle belongs to the workspace"));
            }
            if matches!(command, "insert.audio" | "insert.video") {
                let Some(bytes) = p.get("params").and_then(|value| value.get("data")).and_then(Value::as_str).and_then(deckcraft_engine::cmd::base64_decode) else {
                    return Some(err("embedded media insertion requires actual inline media bytes"));
                };
                let Some(doc) = app.session.active() else { return Some(err("no native presentation open")); };
                if let Err(error) = deckcraft_engine::embedded::insert_media_admission(&doc.doc, &bytes, command == "insert.video") {
                    return Some(err(error));
                }
            }
            match app.run(command, p.get("params").cloned().unwrap_or_else(|| json!({}))) {
                Ok(value) => match document(app) {
                    Ok(doc) => ok(json!({"value":value,"document":doc})),
                    Err(error) => err(error),
                },
                Err(error) => err(error),
            }
        }
        "host.node" => {
            if let Err(error) = base(app, p) {
                return Some(err(error));
            }
            let Some(id) = p.get("id").and_then(Value::as_u64).and_then(|id| u32::try_from(id).ok()) else {
                return Some(err("Deck shape ids must fit their actual uint32 type"));
            };
            match app.run("shape.inspect", json!({"id":id})) {
                Ok(value) if value.to_string().len() <= 1024 * 1024 => ok(value),
                Ok(_) => err("native shape details exceed budget"),
                Err(error) => err(error),
            }
        }
        "host.snapshot" | "host.bundle" => {
            if request.method == "host.bundle" {
                if let Err(error) = base(app, p) {
                    return Some(err(error));
                }
            }
            let format = p.get("format").and_then(Value::as_str).unwrap_or("deckcraft");
            let before = match document(app) {
                Ok(doc) => doc,
                Err(error) => return Some(err(error)),
            };
            if request.method == "host.bundle" {
                if format != "png" {
                    return Some(err("Deck material snapshots currently use slide PNG"));
                }
                match encoded(app, "deckcraft").and_then(|source| {
                    encoded(app, format).map(|derivative| json!({"document":before,"source":source,"derivative":derivative,"format":format}))
                }) {
                    Ok(value) => ok(value),
                    Err(error) => err(error),
                }
            } else {
                match encoded(app, format) {
                    Ok(value) => ok(json!({"document":before,"encoded":value,"format":format})),
                    Err(error) => err(error),
                }
            }
        }
        "host.saved" => {
            if pending(app) {
                return Some(ok(json!({"acknowledged":false,"pendingInteraction":true})));
            }
            let Some(doc) = app.session.active_mut() else {
                return Some(err("no native presentation open"));
            };
            if p.get("uid").and_then(Value::as_u64) != Some(doc.uid) || p.get("revision").and_then(Value::as_u64) != Some(doc.revision) {
                ok(json!({"acknowledged":false,"newerEdits":true}))
            } else if !p.get("checkpoint").and_then(Value::as_str).is_some_and(|s| s.len() == 64 && s.bytes().all(|b| b.is_ascii_hexdigit())) {
                err("invalid durable checkpoint")
            } else {
                doc.saved_doc = doc.doc.clone();
                ok(json!({"acknowledged":true}))
            }
        }
        "host.file.pending" => ok(json!({"request":app.hosted.pending_file})),
        "host.file.finish" => {
            if app.hosted.pending_file.as_ref().is_some_and(|file| file.get("id") == p.get("id")) {
                app.hosted.pending_file = None;
                ok(json!({"completed":true}))
            } else {
                err("native file request receipt changed")
            }
        }
        _ => return None,
    })
}

impl SlideApp {
    /// Adopt only genuinely decoded/bounded bytes into this empty, source-owned App.
    pub fn open_hosted_bytes(&mut self, name: &str, bytes: &[u8]) -> Result<(), String> {
        if !self.hosted.embedded || !self.session.documents().is_empty() {
            return Err("open requires an empty source-owned native App".into());
        }
        self.hosted.open_error = None;
        self.hosted.opening = true;
        let imported = deckcraft_engine::embedded::import(name, bytes, Default::default());
        self.hosted.opening = false;
        let imported = match imported {
            Ok(imported) => imported,
            Err(error) => {
                self.hosted.open_error = Some(error.clone());
                self.set_status(error.clone());
                return Err(error);
            }
        };
        let title = std::path::Path::new(name).file_stem().and_then(|s| s.to_str()).unwrap_or("Presentation");
        deckcraft_engine::fonts::install_embedded_fonts(&imported.presentation);
        let missing_fonts = deckcraft_engine::fonts::missing_fonts(&imported.presentation);
        let mut warnings = imported.warnings;
        if !missing_fonts.is_empty() {
            warnings.push(if crate::host_ui::is_embedded() { format!("渲染缺少字体：{}", missing_fonts.join(", ")) } else { format!("Fonts unavailable for rendering: {}", missing_fonts.join(", ")) });
        }
        let mut doc = DocState::new(imported.presentation, None, title.chars().take(200).collect());
        doc.missing_fonts = missing_fonts;
        self.session.add_document(doc);
        self.hosted.open_warnings = warnings;
        self.backstage = None;
        self.ui.view = ViewMode::Normal;
        self.ui.zoom = None;
        Ok(())
    }
}

#[cfg(test)]
#[path = "hosted_tests.rs"]
mod tests;
