//! Actual selected ink inspection and undoable editable text/OMML insertion.
use deckcraft_geom::Xfrm;
use deckcraft_model::{ShapeId, ShapeKind};
use deckcraft_model::text::RunKind;
use quick_xml::events::Event;
use serde_json::{Value, json};
use super::{CommandSpec, NO_ID_SPACE, bad, bool_or, cmd, has_slide, str_param, targets};
use crate::{Result, Session};

pub fn specs() -> Vec<CommandSpec> {
    vec![
        cmd!(query "draw.inspectInk", "Inspect Selected Ink", [], None,
            "{ids?: [ink shape ids]} -> {ids,strokes,rect}; actual visible ink, no recognition or mutation", has_slide, inspect),
        cmd!("draw.inkToText", "Ink to Text", ["Draw", "Convert"], None,
            "{ids:[ink ids],text: actual recognized text,hideOriginal?:bool} preserves original ink and creates one editable text box", has_slide, apply_text),
        cmd!("draw.inkToMath", "Ink to Math", ["Draw", "Convert"], None,
            "{ids:[ink ids],text: linear expression,omml: validated Office Math XML,hideOriginal?:bool} preserves original ink and creates an editable equation run", has_slide, apply_math),
    ]
}
fn inspect(s: &mut Session, p: &Value) -> Result<Value> {
    let ids = targets(s, p)?;
    let state = s.doc()?;
    let shapes = state.shapes();
    let mut found = Vec::<u32>::new();
    let mut strokes = Vec::<Vec<[f64; 3]>>::new();
    let (mut min_x, mut min_y, mut max_x, mut max_y) = (f64::MAX, f64::MAX, f64::MIN, f64::MIN);
    let mut total = 0usize;
    for shape in shapes.iter().filter(|shape| ids.is_empty() || ids.contains(&shape.id)) {
        let ShapeKind::Ink { strokes: ink } = &shape.kind else { continue };
        if shape.hidden { continue; }
        if shape.locked { return Err(bad("draw.inspectInk", "unlock the selected ink before recognition")); }
        found.push(shape.id.0);
        for stroke in ink {
            if stroke.highlighter { continue; }
            if stroke.points.len() < 2 { continue; }
            total = total.checked_add(stroke.points.len()).ok_or_else(|| bad("draw.inspectInk", "ink point budget exceeded"))?;
            if total > 20_000 || strokes.len() >= 256 { return Err(bad("draw.inspectInk", "select at most 256 strokes and 20000 points")); }
            let mut points = Vec::with_capacity(stroke.points.len());
            for &(x, y, pressure) in &stroke.points {
                if !x.is_finite() || !y.is_finite() || x.abs() > 1_000_000.0 || y.abs() > 1_000_000.0 || !pressure.is_finite() {
                    return Err(bad("draw.inspectInk", "selected ink contains invalid coordinates"));
                }
                min_x = min_x.min(x); min_y = min_y.min(y); max_x = max_x.max(x); max_y = max_y.max(y);
                points.push([x, y, f64::from(pressure)]);
            }
            strokes.push(points);
        }
    }
    if strokes.is_empty() { return Err(bad("draw.inspectInk", "select visible handwriting strokes on the current slide")); }
    Ok(json!({"ids":found,"strokes":strokes,"rect":[min_x,min_y,(max_x-min_x).max(24.0),(max_y-min_y).max(24.0)]}))
}
fn validate_omml(value: &str) -> Result<()> {
    const CMD: &str = "draw.inkToMath";
    if value.is_empty() || value.len() > 200_000 || value.contains("<!") { return Err(bad(CMD, "invalid or oversized OMML")); }
    let mut reader = quick_xml::Reader::from_str(value);
    reader.config_mut().check_end_names = true;
    let mut depth = 0usize; let mut nodes = 0usize; let mut roots = 0usize;
    loop {
        let event = reader.read_event().map_err(|error| bad(CMD, error.to_string()))?;
        let opens = matches!(&event, Event::Start(_));
        match event {
            Event::Start(element) | Event::Empty(element) => {
                nodes += 1;
                let name = element.name();
                let full = std::str::from_utf8(name.as_ref()).map_err(|_| bad(CMD, "invalid math element"))?;
                let tag = full.strip_prefix("m:").ok_or_else(|| bad(CMD, "math elements must use the Office Math namespace"))?;
                if !matches!(tag, "oMath"|"oMathPara"|"r"|"t"|"f"|"fPr"|"num"|"den"|"sSup"|"sSub"|"sSubSup"|"e"|"sub"|"sup"|"rad"|"radPr"|"deg"|"degHide"|"nary"|"naryPr"|"chr"|"limLoc"|"m"|"mPr"|"mr"|"d"|"dPr"|"begChr"|"endChr"|"sepChr"|"acc"|"accPr"|"bar"|"barPr"|"pos"|"func"|"fName"|"lim"|"limLow"|"limUpp"|"borderBox"|"groupChr"|"groupChrPr"|"rPr"|"sty"|"scr"|"type") {
                    return Err(bad(CMD, format!("unsupported Office Math element {tag}")));
                }
                if depth == 0 { roots += 1; if roots > 1 || !matches!(tag,"oMath"|"oMathPara") { return Err(bad(CMD,"one Office Math root is required")); } }
                for attribute in element.attributes() {
                    let a = attribute.map_err(|_| bad(CMD,"invalid math attribute"))?;
                    if a.key.as_ref() == b"xmlns:m" {
                        if a.value.as_ref() != b"http://schemas.openxmlformats.org/officeDocument/2006/math" { return Err(bad(CMD,"invalid math namespace")); }
                    } else if a.key.as_ref() != b"m:val" && a.key.as_ref() != b"xml:space" { return Err(bad(CMD,"unsupported math attribute")); }
                }
                if opens { depth += 1; }
                if depth > 64 || nodes > 10000 { return Err(bad(CMD,"math structure exceeds budget")); }
            }
            Event::End(_) => { depth = depth.checked_sub(1).ok_or_else(|| bad(CMD,"unbalanced math XML"))?; }
            Event::Eof => break,
            Event::Text(text) => { if depth == 0 && !text.as_ref().iter().all(u8::is_ascii_whitespace) { return Err(bad(CMD,"text outside math root")); } }
            Event::Decl(_) | Event::PI(_) | Event::DocType(_) => return Err(bad(CMD,"math XML declarations are not admitted")),
            _ => {}
        }
    }
    if roots != 1 || depth != 0 { return Err(bad(CMD,"incomplete math root")); }
    Ok(())
}
fn apply_text(s: &mut Session, p: &Value) -> Result<Value> { apply(s,p,false) }
fn apply_math(s: &mut Session, p: &Value) -> Result<Value> { apply(s,p,true) }
fn apply(s: &mut Session, p: &Value, math: bool) -> Result<Value> {
    let command = if math { "draw.inkToMath" } else { "draw.inkToText" };
    let text = str_param(p,"text").filter(|text|!text.trim().is_empty() && text.len()<=40000).ok_or_else(|| bad(command,"actual recognized text is required"))?;
    let omml = if math { let xml = str_param(p,"omml").ok_or_else(|| bad(command,"recognized OMML is required"))?; validate_omml(xml)?; Some(xml.to_owned()) } else { None };
    let input = inspect(s,p)?;
    let ids: Vec<ShapeId> = input.get("ids").and_then(Value::as_array).ok_or_else(||bad(command,"ink selection missing"))?.iter().filter_map(|value|value.as_u64().and_then(|id|u32::try_from(id).ok()).map(ShapeId)).collect();
    let rect = input.get("rect").and_then(Value::as_array).ok_or_else(|| bad(command,"ink bounds missing"))?;
    let at = |index| rect.get(index).and_then(Value::as_f64).ok_or_else(||bad(command,"invalid ink bounds"));
    let mut shape = super::insert::new_text_box(Xfrm::new(at(0)?,at(1)?,at(2)?.max(120.0),at(3)?.max(36.0)),text);
    if let Some(xml)=omml { if let Some(run)=shape.text.as_mut().and_then(|body|body.paragraphs.first_mut()).and_then(|paragraph|paragraph.runs.first_mut()) { run.kind=RunKind::Math{omml:xml}; } }
    if let Some(mathml)=str_param(p,"sourceMathML") { if mathml.len()>200_000 || mathml.contains("<!") { return Err(bad(command,"invalid original MathML")); } shape.tags.push(("designcraft.sourceMathML".into(),mathml.into())); }
    shape.tags.push(("designcraft.inkSourceIds".into(),serde_json::to_string(&ids).map_err(|e|bad(command,e.to_string()))?));
    let hide = bool_or(p,"hideOriginal",true);
    let id = s.edit(|doc,sel| {
        let id = ShapeId(doc.alloc_id().ok_or_else(||bad(command,NO_ID_SPACE))?);
        let list=crate::shapes_mut(doc,sel).ok_or_else(||bad(command,"no slide"))?;
        for source_id in &ids { let source=list.iter_mut().find(|shape|shape.id==*source_id).ok_or_else(||bad(command,"source ink changed"))?; if source.locked || !matches!(source.kind,ShapeKind::Ink{..}) { return Err(bad(command,"source ink changed")); } if hide { source.hidden=true; } }
        shape.id=id;shape.name=if math {"Recognized equation".into()}else{"Recognized handwriting".into()};list.push(shape);sel.shapes=vec![id];sel.text=None;Ok(id)
    })?;
    Ok(json!({"id":id,"sourceInkIds":ids,"originalInkPreserved":true,"math":math}))
}
